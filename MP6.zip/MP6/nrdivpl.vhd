-- William Diehl 03-01-2026
-- Newton-Raphson floating point divider based on algorithm in:
-- https://en.wikipedia.org/wiki/Division_algorithm#Newton-Raphson_division
-- Retrieved 01-19-2026
-- Update 3-01-2026 for reduced latency and full pipelining
-- Latency 6 clock cycles; throughput 1 result per clock cycle after priming
-- "start" acts as input valid and "done" is the matching output valid delayed
-- through the 6 pipeline stages

library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.all;

entity nrdivpl is
generic(N : integer:=32);
port(
	clk : in std_logic;
	reset: in std_logic;
	start : in std_logic;
	div : in std_logic_vector(N-1 downto 0);
	d : in std_logic_vector(N-1 downto 0);
	q : out std_logic_vector(N-1 downto 0);
	done : out std_logic
	);

end nrdivpl;

architecture behavioral of nrdivpl is

constant ZEROES : std_logic_vector(N-1 downto 0):=(others => '0');
constant ITERATIONS : integer:=6;

signal m0 : std_logic_vector(22 downto 0);
signal m1 : std_logic_vector(22 downto 0);

signal fp0, fp1 : std_logic_vector(31 downto 0);

signal s0, s1, sout, sout_z1, sout_z2, sout_z3, sout_z4, sout_z5 : std_logic;
signal mout : std_logic_vector(22 downto 0);
	
signal exp0, exp0_z1, exp0_z2, exp0_z3, exp0_z4, exp0_z5 : std_logic_vector(7 downto 0);
signal exp1, exp1_z1, exp1_z2, exp1_z3, exp1_z4, exp1_z5 : std_logic_vector(7 downto 0);

signal expdiff, expout, expadj : std_logic_vector(7 downto 0);
signal dsqext, x0aext, x0bext : std_logic_vector(51 downto 0);
signal e0, e1, e2, x0a, x0b, dsq, dsq_z1, x0, x0_z1, x0_z2, x0_z3 : std_logic_vector(25 downto 0);
signal m1ext, m1ext_z1, m1ext_z2, m1ext_z3 : std_logic_vector(25 downto 0);
signal m0ext, m0ext_z1, m0ext_z2, m0ext_z3, m0ext_z4, m0ext_z5 : std_logic_vector(25 downto 0); 
signal m0zero, m0zero_z1, m0zero_z2, m0zero_z3, m0zero_z4, m0zero_z5 : std_logic:= '0';
signal m1zero, m1zero_z1, m1zero_z2, m1zero_z3, m1zero_z4, m1zero_z5 : std_logic:='0';
	
signal dx1ext, dx2ext : std_logic_vector(51 downto 0);
signal dx1, dx1_z1, dx2, dx2_z1 : std_logic_vector(25 downto 0);
signal oneext : std_logic_vector(25 downto 0);
signal one_m_dx1, one_m_dx2 : std_logic_vector(25 downto 0);
signal x1_t_1_m_dx1_ext, x2_t_1_m_dx2_ext : std_logic_vector(51 downto 0);
signal x1_t_1_m_dx1, x1_t_1_m_dx1_z1, x2_t_1_m_dx2, x2_t_1_m_dx2_z1 : std_logic_vector(25 downto 0);
signal x1, x1_z1, x1_z2, x2, x2_z1 : std_logic_vector(25 downto 0);

signal ndext : std_logic_vector(51 downto 0);
signal nd : std_logic_vector(25 downto 0);
signal ndresidual : std_logic_vector(1 downto 0);	

signal valid_pipe : std_logic_vector(ITERATIONS-1 downto 0) := (others => '0');

begin

-- Cycle 1
	
	e0 <= "10000111110000011111000000"; -- 140/33  -- constant
	e1 <= "10111010001011101000110000"; -- 64/11 -- constant
	e2 <= "01010010101111110101101000"; --256/99 -- constant
	oneext <= "00100000000000000000000000"; -- constant

	fp0 <= div; -- divisor
    fp1 <= d; -- dividend
	
	m0 <= fp0(22 downto 0); -- fp0 mantissa
	s0 <= fp0(31);
	exp0 <= fp0(30 downto 23); -- fp0 exponent
	m1 <= fp1(22 downto 0); -- fp1 mantissa
	s1 <= fp1(31);
	exp1 <= fp1(30 downto 23); -- fp1 exponent
	sout <= s0 xor s1; -- result sign calculation
	
	-- reattach 1 to MSB of mantissas
	
	m0zero <= '1' when (unsigned(m0) = 0) else '0';
	m0ext <= "01" & m0 & "0";
	m1zero <= '1' when (unsigned(m1) = 0) else '0';
	m1ext <= "01" & m1 & "0" when (m1zero = '1') else "001" & m1;
	
	-- quadratic estimate for chebyshev polynomial for denominator x[0] estimate
	
	dsqext <= std_logic_vector(unsigned(m1ext) * unsigned(m1ext));
	dsq <= dsqext(50 downto 25);

    -----------------------
    -- Cycle 2
    	
	x0aext <= std_logic_vector(unsigned(e1) * unsigned(m1ext_z1));
	x0a <= x0aext(49 downto 24);

	x0bext <= std_logic_vector(unsigned(e2) * unsigned(dsq_z1));
	x0b <= x0bext(48 downto 23);
	
	x0 <= std_logic_vector(unsigned(e0) - unsigned(x0a) + unsigned(x0b));
	
	----
	-- compute x[1] denominator estimate
	-- Cycle 3
	
	dx1ext <= std_logic_vector(unsigned(m1ext_z2) * unsigned(x0_z1));
	dx1 <= dx1ext(49 downto 24);
	
	one_m_dx1 <= std_logic_vector(unsigned(oneext) - unsigned(dx1));
	
	x1_t_1_m_dx1_ext <= std_logic_vector(signed(x0_z1) * signed(one_m_dx1));
	x1_t_1_m_dx1 <= x1_t_1_m_dx1_ext(48 downto 23);
	
	
	-- Cycle 4

	x1 <= std_logic_vector(signed(x0_z2) + signed(x1_t_1_m_dx1_z1));
	
	-- compute x[2] denominator estimate.  Final estimate for FP32 precision.
	
	dx2ext <= std_logic_vector(unsigned(m1ext_z3) * unsigned(x1));
	dx2 <= dx2ext(49 downto 24);
	
	-- Cycle 5
	
	one_m_dx2 <= std_logic_vector(unsigned(oneext) - unsigned(dx2_z1));
	x2_t_1_m_dx2_ext <= std_logic_vector(signed(x1_z1) * signed(one_m_dx2));
	x2_t_1_m_dx2 <= x2_t_1_m_dx2_ext(48 downto 23);
	
	-- Cycle 6
	
	x2 <= std_logic_vector(signed(x1_z2) + signed(x2_t_1_m_dx2_z1));
	
	--- adjust for final multiplication

	ndext <= std_logic_vector(unsigned(x2) * unsigned(m0ext_z5));
	
	nd <= ndext(50 downto 25) when ndext(48)='1' else ndext(49 downto 24); 
	ndresidual <= ndext(49 downto 48);
	expdiff <= std_logic_vector(signed(exp0_z5)-signed(exp1_z5));
	expadj <= std_logic_vector(127 + signed(expdiff)) when ((m0zero_z5 = '0') and (m1zero_z5 = '1')) else std_logic_vector(126 + signed(expdiff));
	expout <= std_logic_vector(unsigned(expadj) + unsigned(ndresidual));
	
	-- prepare fp out
	mout <= nd(22 downto 0);
	q <= ZEROES when (exp0_z5 = x"00") else (sout_z5 & expout & mout);
	done <= valid_pipe(ITERATIONS-1);

delay_process: process(clk)
begin
	if (rising_edge(clk)) then
		if (reset = '1') then
			valid_pipe <= (others => '0');
		else
			valid_pipe(0) <= start;
			for i in 1 to ITERATIONS-1 loop
				valid_pipe(i) <= valid_pipe(i-1);
			end loop;
		end if;
 
 -- cycle 1
        dsq_z1 <= dsq;
        exp0_z1 <= exp0;
        exp1_z1 <= exp1;
        sout_z1 <= sout;
        m0zero_z1 <= m0zero;
        m1zero_z1 <= m1zero;
        m0ext_z1 <= m0ext;
        m1ext_z1 <= m1ext;
        
-- cycle 2

		x0_z1 <= x0;
        exp0_z2 <= exp0_z1;
        exp1_z2 <= exp1_z1;
        sout_z2 <= sout_z1;
        m0zero_z2 <= m0zero_z1;
        m1zero_z2 <= m1zero_z1;
        m0ext_z2 <= m0ext_z1;
        m1ext_z2 <= m1ext_z1;

-- cycle 3		
		x0_z2 <= x0_z1; 
        exp0_z3 <= exp0_z2;
        exp1_z3 <= exp1_z2;
        sout_z3 <= sout_z2;
        m0zero_z3 <= m0zero_z2;
        m1zero_z3 <= m1zero_z2;
        m0ext_z3 <= m0ext_z2;
        m1ext_z3 <= m1ext_z2;

-- cycle 4
		x1_t_1_m_dx1_z1 <= x1_t_1_m_dx1;
		x1_z1 <= x1;
        exp0_z4 <= exp0_z3;
        exp1_z4 <= exp1_z3;
        sout_z4 <= sout_z3;
        m0zero_z4 <= m0zero_z3;
        m1zero_z4 <= m1zero_z3;
        m0ext_z4 <= m0ext_z3;
		dx2_z1 <= dx2;

-- cycle 5

		x2_t_1_m_dx2_z1 <= x2_t_1_m_dx2; 
		exp0_z5 <= exp0_z4;
		exp1_z5 <= exp1_z4;
		sout_z5 <= sout_z4;	
        m0zero_z5 <= m0zero_z4;
        m1zero_z5 <= m1zero_z4;
        m0ext_z5 <= m0ext_z4;
		x1_z2 <= x1_z1;
		
	end if;
end process delay_process;

end behavioral;

