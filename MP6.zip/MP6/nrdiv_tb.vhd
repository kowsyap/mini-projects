library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.all;

entity nrdiv_tb is

end nrdiv_tb;

architecture behavioral of nrdiv_tb is

constant N:integer:=32;
constant PERIOD:time:=10ns;

signal fp0, fp1, q: std_logic_vector(N-1 downto 0);
signal clk, rst, start, done : std_logic:='0';

begin

uut: entity work.nrdivpl(behavioral)
    generic map(N=>N)
	port map(
	clk => clk,
	reset => rst,
	start => start,
	done => done,
	div => fp0,
	d => fp1,
	q => q
	);

clk <= not clk after PERIOD/2;

    --x"3dcccccd"; -- 0.1
    --x"C0F80000"; -- -7.75
    --x"42c80000"; -- 100
	--x"bf800000"; -- -1
	--fp0 <= x"40800000"; --4
	--fp0 <= x"40000000"; --2
	
    --fp1 <= x"3dcccccd"; -- 0.1
    --x"bc23d70a"; -- -0.01
 
    --x"42480000"; -- 50
    --x"424c0000"; -- 51
    --x"bf800000"; -- -1
    --x"3f4ccccd"; -- 0.8
    --x"3b51b717"; -- 0.0032
	--fp1 <= x"40000000"; -- 2
	--x"bf800000"; -- -1


test_process: process
begin
	rst <= '1';
	wait for period;
	rst <= '0';
	start <= '1';
	wait for period;
	fp0 <= x"40000000"; --2
    fp1 <= x"42700000"; -- 60
    wait for period;
	fp0 <= x"40800000"; --4
	fp1 <= x"40000000"; -- 2
    wait for period;
    fp0 <= x"bf800000"; -- -1
    fp1 <= x"424c0000"; -- 51
    wait for period;
    fp0 <= x"3f4ccccd"; -- 0.8
    fp1 <= x"3b51b717"; -- 0.0032
	wait for period;
	start <= '0';
    
	wait;
end process;

end behavioral;