library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.all;
use ieee.std_logic_textio.all;

library std;
use std.textio.all;

entity fpnrdiv_tb is

end fpnrdiv_tb;

architecture behavioral of fpnrdiv_tb is

-- output values will depart through these files
--FILE outFile: TEXT OPEN WRITE_MODE is "lfmiqfile.txt";

constant period: time:= 4.1028 ns;
		-- User parameters ends
		-- Do not modify the parameters beyond this line

		-- Parameters of Axi Slave Bus Interface S00_AXI
constant C_S00_AXI_DATA_WIDTH : integer:= 32;
constant C_S00_AXI_ADDR_WIDTH : integer:= 5;

		-- User ports ends
		-- Do not modify the ports beyond this line
		-- Ports of Axi Slave Bus Interface S00_AXI
signal		irq, clk	: std_logic:='0';
signal		s00_axi_aresetn	: std_logic;
signal		s00_axi_awaddr	: std_logic_vector(C_S00_AXI_ADDR_WIDTH-1 downto 0);
signal		s00_axi_awprot	: std_logic_vector(2 downto 0);
signal		s00_axi_awvalid	: std_logic;
signal		s00_axi_awready	: std_logic;
signal		s00_axi_wdata	: std_logic_vector(C_S00_AXI_DATA_WIDTH-1 downto 0);
signal		s00_axi_wstrb	: std_logic_vector((C_S00_AXI_DATA_WIDTH/8)-1 downto 0);
signal		s00_axi_wvalid	: std_logic;
signal		s00_axi_wready	:  std_logic;
signal		s00_axi_bresp	:  std_logic_vector(1 downto 0);
signal		s00_axi_bvalid	:  std_logic;
signal		s00_axi_bready	: std_logic;
signal		s00_axi_araddr	:  std_logic_vector(C_S00_AXI_ADDR_WIDTH-1 downto 0);
signal		s00_axi_arprot	:  std_logic_vector(2 downto 0);
signal		s00_axi_arvalid	:  std_logic;
signal		s00_axi_arready	:  std_logic;
signal		s00_axi_rdata	:  std_logic_vector(C_S00_AXI_DATA_WIDTH-1 downto 0);
signal		s00_axi_rresp	:  std_logic_vector(1 downto 0);
signal		s00_axi_rvalid	:  std_logic;
signal		s00_axi_rready	:  std_logic;

begin

clk <= not clk after period/2;

uut: entity work.fpnrdivpl(arch_imp)

	generic map(
		-- Users to add parameters here
        

		-- User parameters ends
		-- Do not modify the parameters beyond this line

		-- Parameters of Axi Slave Bus Interface S00_AXI
		C_S00_AXI_DATA_WIDTH =>	C_S00_AXI_DATA_WIDTH,
		C_S00_AXI_ADDR_WIDTH =>	C_S00_AXI_ADDR_WIDTH

	)
	port map(
		-- Users to add ports here
		irq => irq,
		-- User ports ends
		-- Do not modify the ports beyond this line
		-- Ports of Axi Slave Bus Interface S00_AXI
		s00_axi_aclk	=> clk,
 		s00_axi_aresetn	=> s00_axi_aresetn,
		s00_axi_awaddr	=> s00_axi_awaddr,
		s00_axi_awprot	=> s00_axi_awprot,
		s00_axi_awvalid	=> s00_axi_awvalid,
		s00_axi_awready	=> s00_axi_awready,
		s00_axi_wdata	=> s00_axi_wdata,
		s00_axi_wstrb	=> s00_axi_wstrb,
		s00_axi_wvalid	=> s00_axi_wvalid,
		s00_axi_wready	=> s00_axi_wready,
		s00_axi_bresp	=> s00_axi_bresp,
		s00_axi_bvalid	=> s00_axi_bvalid,
		s00_axi_bready	=> s00_axi_bready,
		s00_axi_araddr	=> s00_axi_araddr,
		s00_axi_arprot	=> s00_axi_arprot,
		s00_axi_arvalid	=> s00_axi_arvalid,
		s00_axi_arready	=> s00_axi_arready,
		s00_axi_rdata	=> s00_axi_rdata,
		s00_axi_rresp	=> s00_axi_rresp,
		s00_axi_rvalid	=> s00_axi_rvalid,
		s00_axi_rready	=> s00_axi_rready
		
	);


test_process: process
begin
	s00_axi_aresetn <= '0';
	
	s00_axi_awvalid	<= '0';
	s00_axi_wvalid <= '0';
	s00_axi_awvalid	<= '0';
	s00_axi_wvalid <= '0';

	wait for period*2;
	s00_axi_aresetn <= '1';
	wait for period*4;

-- load accelerator 
    --s00_axi_wdata <= x"441A0F8D";
    --s00_axi_wdata <= x"3dcccccd"; -- 0.1
    --s00_axi_wdata <= x"C0F80000";
    --s00_axi_wdata <= x"42c80000"; -- 100
	--s00_axi_wdata <= x"bf800000"; -- -1
	--s00_axi_wdata <= x"40e00000"; -- 7
	--s00_axi_wdata <= x"00000000"; -- 0
	s00_axi_wdata <= x"40400000"; -- 3
	--s00_axi_wdata <= x"c0a00000"; -- -5
	--s00_axi_wdata <= x"40800000"; --4
	--s00_axi_wdata <= x"40000000"; --2
	--s00_axi_wdata <= x"41a122d1";
	
	s00_axi_awaddr <= "00000"; -- reg(0)  
	s00_axi_awvalid <= '1';
	s00_axi_wvalid <= '1';
	s00_axi_wstrb <= "1111";
	s00_axi_bready <= '1';
	wait for period*2;
	s00_axi_awvalid <= '0';
	s00_axi_wvalid <= '0';
	s00_axi_wstrb <= "0000";

	wait for period*2;
    
    --s00_axi_wdata <= x"c0266666";
    --s00_axi_wdata <= x"3dcccccd"; -- 0.1
    --s00_axi_wdata <= x"bc23d70a"; -- -0.01
    --s00_axi_wdata <= x"c0800000";
    --s00_axi_wdata <= x"42700000"; -- 60
    --s00_axi_wdata <= x"42480000"; -- 50
    --s00_axi_wdata <= x"424c0000"; -- 51
    --s00_axi_wdata <= x"40800000"; -- 4
    --s00_axi_wdata <= x"bf800000"; -- -1
   --s00_axi_wdata <= x"3f4ccccd"; -- 0.8
   --s00_axi_wdata <= x"40400000"; -- 3
   --s00_axi_wdata <= x"40c00000"; -- 6
   --s00_axi_wdata <= x"3b51b717"; -- 0.0032
   s00_axi_wdata <= x"c0a00000"; -- 5
	--s00_axi_wdata <= x"40000000"; -- 2
	--s00_axi_wdata <= x"bf800000"; -- -1
	
	s00_axi_awaddr <= "00100"; -- reg(1)  
	s00_axi_awvalid <= '1';
	s00_axi_wvalid <= '1';
	s00_axi_wstrb <= "1111";
	s00_axi_bready <= '1';
	wait for period*2;
	s00_axi_awvalid <= '0';
	s00_axi_wvalid <= '0';
	s00_axi_wstrb <= "0000";

	wait for period*12;

	--wait for period*16;
	
	-- read results

	s00_axi_araddr <= "10000"; -- read fp result
	s00_axi_arvalid <= '1';
    s00_axi_rready <= '1';
	wait for period*2;
	s00_axi_arvalid <= '0';
    s00_axi_rready <= '0';
    
	wait for period*2;
	
	--s00_axi_wdata <= x"441A0F8D";
    --s00_axi_wdata <= x"3dcccccd"; -- 0.1
    --s00_axi_wdata <= x"C0F80000";
    --s00_axi_wdata <= x"42c80000"; -- 100
	--s00_axi_wdata <= x"bf800000"; -- -1
	s00_axi_wdata <= x"40800000"; --4
	--s00_axi_wdata <= x"40000000"; --2
	--s00_axi_wdata <= x"41a122d1";
	
	s00_axi_awaddr <= "00000"; -- reg(0)  
	s00_axi_awvalid <= '1';
	s00_axi_wvalid <= '1';
	s00_axi_wstrb <= "1111";
	s00_axi_bready <= '1';
	wait for period*2;
	s00_axi_awvalid <= '0';
	s00_axi_wvalid <= '0';
	s00_axi_wstrb <= "0000";

	wait for period*2;
    
    --s00_axi_wdata <= x"c0266666";
    --s00_axi_wdata <= x"3dcccccd"; -- 0.1
    --s00_axi_wdata <= x"bc23d70a"; -- -0.01
    --s00_axi_wdata <= x"42700000"; -- 60
    --s00_axi_wdata <= x"42480000"; -- 50
    --s00_axi_wdata <= x"424c0000"; -- 51
    --s00_axi_wdata <= x"bf800000"; -- -1
   s00_axi_wdata <= x"3f4ccccd"; -- 0.8
   --s00_axi_wdata <= x"3b51b717"; -- 0.0032
	--s00_axi_wdata <= x"40000000"; -- 2
	--s00_axi_wdata <= x"bf800000"; -- -1
	
	s00_axi_awaddr <= "00100"; -- reg(1)  
	s00_axi_awvalid <= '1';
	s00_axi_wvalid <= '1';
	s00_axi_wstrb <= "1111";
	s00_axi_bready <= '1';
	wait for period*2;
	s00_axi_awvalid <= '0';
	s00_axi_wvalid <= '0';
	s00_axi_wstrb <= "0000";

	wait for period*12;

	-- read results

	s00_axi_araddr <= "10000"; -- read fp result
	s00_axi_arvalid <= '1';
    s00_axi_rready <= '1';
	wait for period*2;
	s00_axi_arvalid <= '0';
    s00_axi_rready <= '0';
    
	wait for period*2;

    wait;
	
end process test_process;	

--writeVec: PROCESS(clk)
--
--  VARIABLE VectorLine: LINE;

--BEGIN

-- if (rising_edge(clk)) then
--        if (m02_axis_tvalid = '1') then
--          hwrite(VectorLine, m02_axis_tdata);        
--          writeline(outFile, VectorLine);
--        end if;
--end if;

--ASSERT False
--Report "Writing Result"
--SEVERITY NOTE;
--wait for period/2;

--end process;

end behavioral;

