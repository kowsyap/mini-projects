library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity fpnrdivpl is
	generic (
		-- Users to add parameters here
        C_NUMFPINPUTS	: integer	:= 2;
		C_NUMFPOUTPUTS	: integer	:= 1;
		-- User parameters ends
		-- Do not modify the parameters beyond this line

		-- Parameters of Axi Slave Bus Interface S00_AXI
		C_S00_AXI_DATA_WIDTH	: integer	:= 32; 
		C_S00_AXI_ADDR_WIDTH	: integer	:= 5

		-- Parameters of Axi Slave Bus Interface S00_AXIS
		
	);
	port (
		-- Users to add ports here
		irq : out std_logic;
		-- User ports ends
		-- Do not modify the ports beyond this line
		-- Ports of Axi Slave Bus Interface S00_AXI
		s00_axi_aclk	: in std_logic;
		s00_axi_aresetn	: in std_logic;
		s00_axi_awaddr	: in std_logic_vector(C_S00_AXI_ADDR_WIDTH-1 downto 0);
		s00_axi_awprot	: in std_logic_vector(2 downto 0);
		s00_axi_awvalid	: in std_logic;
		s00_axi_awready	: out std_logic;
		s00_axi_wdata	: in std_logic_vector(C_S00_AXI_DATA_WIDTH-1 downto 0);
		s00_axi_wstrb	: in std_logic_vector((C_S00_AXI_DATA_WIDTH/8)-1 downto 0);
		s00_axi_wvalid	: in std_logic;
		s00_axi_wready	: out std_logic;
		s00_axi_bresp	: out std_logic_vector(1 downto 0);
		s00_axi_bvalid	: out std_logic;
		s00_axi_bready	: in std_logic;
		s00_axi_araddr	: in std_logic_vector(C_S00_AXI_ADDR_WIDTH-1 downto 0);
		s00_axi_arprot	: in std_logic_vector(2 downto 0);
		s00_axi_arvalid	: in std_logic;
		s00_axi_arready	: out std_logic;
		s00_axi_rdata	: out std_logic_vector(C_S00_AXI_DATA_WIDTH-1 downto 0);
		s00_axi_rresp	: out std_logic_vector(1 downto 0);
		s00_axi_rvalid	: out std_logic;
		s00_axi_rready	: in std_logic
		
	);
end fpnrdivpl;

architecture arch_imp of fpnrdivpl is

	-- AXI4LITE signals
	signal axi_awaddr	: std_logic_vector(C_S00_AXI_ADDR_WIDTH-1 downto 0);
	signal axi_awready	: std_logic;
	signal axi_wready	: std_logic;
	signal axi_bresp	: std_logic_vector(1 downto 0);
	signal axi_bvalid	: std_logic;
	signal axi_araddr	: std_logic_vector(C_S00_AXI_ADDR_WIDTH-1 downto 0);
	signal axi_arready	: std_logic;
	signal axi_rdata	: std_logic_vector(C_S00_AXI_DATA_WIDTH-1 downto 0);
	signal axi_rresp	: std_logic_vector(1 downto 0);
	signal axi_rvalid	: std_logic;

	------------------------------------------------
	---- Signals for user logic register space example
	--------------------------------------------------
	---- Number of Slave Registers Variable
	---- Number of Slave Registers Variable
	
	type regarray is array (0 to 2**(C_S00_AXI_ADDR_WIDTH-2)-1) of std_logic_vector(C_S00_AXI_DATA_WIDTH-1 downto 0);
	type enarray is array (0 to 2**(C_S00_AXI_ADDR_WIDTH-2)-1) of std_logic; 
   
    signal reg : regarray;
	signal reg_en : enarray;
	
	constant REGZEROES : std_logic_vector(C_S00_AXI_DATA_WIDTH-1 downto 0):=(others=>'0');
	
-- fp working signals
	signal fp0, fp1, fpout : std_logic_vector(31 downto 0);

    signal divide_rst, start : std_logic:='0';
         	
	signal slv_reg_rden	: std_logic;
	signal slv_reg_wren	: std_logic;
	signal reg_data_out	:std_logic_vector(C_S00_AXI_DATA_WIDTH-1 downto 0);
	signal aw_en	: std_logic;
	
begin
	-- I/O Connections assignments

	s00_AXI_AWREADY	<= axi_awready;
	s00_AXI_WREADY	<= axi_wready;
	s00_AXI_BRESP	<= axi_bresp;
	s00_AXI_BVALID	<= axi_bvalid;
	s00_AXI_ARREADY	<= axi_arready;
	s00_AXI_RDATA	<= axi_rdata;
	s00_AXI_RRESP	<= axi_rresp;
	s00_AXI_RVALID	<= axi_rvalid;
	-- Implement axi_awready generation
	-- axi_awready is asserted for one s00_AXI_ACLK clock cycle when both
	-- s00_AXI_AWVALID and s00_AXI_WVALID are asserted. axi_awready is
	-- de-asserted when reset is low.

	process (s00_AXI_ACLK)
	begin
	  if rising_edge(s00_AXI_ACLK) then 
	    if s00_AXI_ARESETN = '0' then
	      axi_awready <= '0';
	      aw_en <= '1';
	    else
	      if (axi_awready = '0' and s00_AXI_AWVALID = '1' and s00_AXI_WVALID = '1' and aw_en = '1') then
	        -- slave is ready to accept write address when
	        -- there is a valid write address and write data
	        -- on the write address and data bus. This design 
	        -- expects no outstanding transactions. 
	           axi_awready <= '1';
	           aw_en <= '0';
	        elsif (s00_AXI_BREADY = '1' and axi_bvalid = '1') then
	           aw_en <= '1';
	           axi_awready <= '0';
	      else
	        axi_awready <= '0';
	      end if;
	    end if;
	  end if;
	end process;

	-- Implement axi_awaddr latching
	-- This process is used to latch the address when both 
	-- s00_AXI_AWVALID and s00_AXI_WVALID are valid. 

	process (s00_AXI_ACLK)
	begin
	  if rising_edge(s00_AXI_ACLK) then 
	    if s00_AXI_ARESETN = '0' then
	      axi_awaddr <= (others => '0');
	    else
	      if (axi_awready = '0' and s00_AXI_AWVALID = '1' and s00_AXI_WVALID = '1' and aw_en = '1') then
	        -- Write Address latching
	        axi_awaddr <= s00_AXI_AWADDR;
	      end if;
	    end if;
	  end if;                   
	end process; 

	-- Implement axi_wready generation
	-- axi_wready is asserted for one s00_AXI_ACLK clock cycle when both
	-- s00_AXI_AWVALID and s00_AXI_WVALID are asserted. axi_wready is 
	-- de-asserted when reset is low. 

	process (s00_AXI_ACLK)
	begin
	  if rising_edge(s00_AXI_ACLK) then 
	    if s00_AXI_ARESETN = '0' then
	      axi_wready <= '0';
	    else
	      if (axi_wready = '0' and s00_AXI_WVALID = '1' and s00_AXI_AWVALID = '1' and aw_en = '1') then
	          -- slave is ready to accept write data when 
	          -- there is a valid write address and write data
	          -- on the write address and data bus. This design 
	          -- expects no outstanding transactions.           
	          axi_wready <= '1';
	      else
	        axi_wready <= '0';
	      end if;
	    end if;
	  end if;
	end process; 

	-- Implement memory mapped register select and write logic generation
	-- The write data is accepted and written to memory mapped registers when
	-- axi_awready, s00_AXI_WVALID, axi_wready and s00_AXI_WVALID are asserted. Write strobes are used to
	-- select byte enables of slave registers while writing.
	-- These registers are cleared when reset (active low) is applied.
	-- Slave register write enable is asserted when valid address and data are available
	-- and the slave is ready to accept the write address and write data.
	
	slv_reg_wren <= axi_wready and s00_AXI_WVALID and axi_awready and s00_AXI_AWVALID ;

		reg_0_process: process(s00_AXI_ACLK)
		begin
			if rising_edge(s00_AXI_ACLK) then
				if (s00_AXI_ARESETN = '0') then
					reg(0) <= REGZEROES;
				else
					if (reg_en(0) = '1') then
						reg(0) <= s00_AXI_WDATA; -- FP input
					end if;
				end if;    
			end if;
		end process;

		reg_1_process: process(s00_AXI_ACLK)
		begin
			if rising_edge(s00_AXI_ACLK) then
				if (s00_AXI_ARESETN = '0') then
					reg(1) <= REGZEROES;
				else
					if (reg_en(1) = '1') then
						reg(1) <= s00_AXI_WDATA; -- Fixed input and starts the conversion.  Input of 1 (identify) should have no effect.
						start <= '1';
					else
						start <= '0';
					end if;
				end if;    
			end if;
		end process;


        --decoder

		reg_en(0) <= '1' when ((to_integer(unsigned(s00_AXI_AWADDR(C_S00_AXI_ADDR_WIDTH-1 downto 2))) = 0) and slv_reg_wren = '1') else '0';
		reg_en(1) <= '1' when ((to_integer(unsigned(s00_AXI_AWADDR(C_S00_AXI_ADDR_WIDTH-1 downto 2))) = 1) and slv_reg_wren = '1') else '0';

	-- Implement write response logic generation2
	-- The write response and response valid 2ignals are5asserted by the slave 
	-- when axi_wready, s00_AXI_WVALID, axi_wrea2y and s00_AXI_WVALID are asserted. 
	-- Implement ready, s08_AXI_WVALID, axi_wrea2y and s00_AXI_WVALID are asserted. 
	-- This marks the acceptance of address and 2ndicates the status of2
	-- write transaction
	
	process (s00_AXI_ACLK)
	begin
	  if rising_edge(s00_AXI_ACLK) then 
	    if s00_AXI_ARESETN = '0' then
	      axi_bvalid  <= '0';
	      axi_bresp   <= "00"; --need to work more on the responses
	    else
	      if (axi_awready = '1' and s00_AXI_AWVALID = '1' and axi_wready = '1' and s00_AXI_WVALID = '1' and axi_bvalid = '0'  ) then
	        axi_bvalid <= '1';
	        axi_bresp  <= "00"; 
	      elsif (s00_AXI_BREADY = '1' and axi_bvalid = '1') then   --check if bready is asserted while bvalid is high)
	        axi_bvalid <= '0';                                 -- (there is a possibility that bready is always asserted high)
	      end if;
	    end if;
	  end if;                   
	end process; 

	-- Implement axi_arready generation
	-- axi_arready is asserted for one s00_AXI_ACLK clock cycle when
	-- s00_AXI_ARVALID is asserted. axi_awready is 
	-- de-asserted when reset (active low) is asserted. 
	-- The read address is also latched when s00_AXI_ARVALID is 
	-- asserted. axi_araddr is reset to zero on reset assertion.

	process (s00_AXI_ACLK)
	begin
	  if rising_edge(s00_AXI_ACLK) then 
	    if s00_AXI_ARESETN = '0' then
	      axi_arready <= '0';
	      axi_araddr  <= (others => '1');
	    else
	      if (axi_arready = '0' and s00_AXI_ARVALID = '1') then
	        -- indicates that the slave has acceped the valid read address
	        axi_arready <= '1';
	        -- Read Address latching 
	        axi_araddr  <= s00_AXI_ARADDR;           
	      else
	        axi_arready <= '0';
	      end if;
	    end if;
	  end if;                   
	end process; 

	-- Implement axi_arvalid generation
	-- axi_rvalid is asserted for one s00_AXI_ACLK clock cycle when both 
	-- s00_AXI_ARVALID and axi_arready are asserted. The slave registers 
	-- data are available on the axi_rdata bus at this instance. The 
	-- assertion of axi_rvalid marks the validity of read data on the 
	-- bus and axi_rresp indicates the status of read transaction.axi_rvalid 
	-- is deasserted on reset (active low). axi_rresp and axi_rdata are 
	-- cleared to zero on reset (active low).  
	process (s00_AXI_ACLK)
	begin
	  if rising_edge(s00_AXI_ACLK) then
	    if s00_AXI_ARESETN = '0' then
	      axi_rvalid <= '0';
	      axi_rresp  <= "00";
	    else
	      if (axi_arready = '1' and s00_AXI_ARVALID = '1' and axi_rvalid = '0') then
	        -- Valid read data is available at the read data bus
	        axi_rvalid <= '1';
	        axi_rresp  <= "00"; -- 'OKAY' response
	      elsif (axi_rvalid = '1' and s00_AXI_RREADY = '1') then
	        -- Read data is accepted by the master
	        axi_rvalid <= '0';
	      end if;            
	    end if;
	  end if;
	end process;

	-- Implement memory mapped register select and read logic generation
	-- Slave register read enable is asserted when valid address is available
	-- and the slave is ready to accept the read address.
	slv_reg_rden <= axi_arready and s00_AXI_ARVALID and (not axi_rvalid) ;
   -- reader
    
	-- Output register or memory read data
	process( s00_AXI_ACLK ) is
	begin
	  if (rising_edge (s00_AXI_ACLK)) then
	    if ( s00_AXI_ARESETN = '0' ) then
	      axi_rdata  <= (others => '0');
	    else
	      if (slv_reg_rden = '1') then
	        -- When there is a valid read address (s00_AXI_ARVALID) with 
	        -- acceptance of read address by the slave (axi_arready), 
	        -- output the read dada 
	        -- Read address mux
			
			
	          axi_rdata <= reg_data_out;     -- register read data
	      end if;   
	    end if;
	  end if;
	end process;


	-- Add user logic here

	-- output selector
	
	reg_data_out <=	fpout;
					
	
	fp0 <= reg(0);
    fp1 <= reg(1);
	divide_rst <= not(s00_axi_aresetn);

 entity_divide: entity work.nrdivpl(behavioral)
    generic map(N=>32)
	port map(
	clk => s00_axi_aclk,
	reset => divide_rst,
	start => start,
	done => irq,
	div => fp0,
	d => fp1,
	q => fpout
	);

	        
	-- User logic ends

end arch_imp;

