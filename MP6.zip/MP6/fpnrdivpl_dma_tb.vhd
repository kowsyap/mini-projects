library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity fpnrdivpl_dma_tb is
end fpnrdivpl_dma_tb;

architecture behavioral of fpnrdivpl_dma_tb is

	constant N          : integer := 32;
	constant LATENCY    : integer := 5;
	constant FIFO_DEPTH : integer := 8;
	constant PERIOD     : time := 10 ns;

	signal aclk          : std_logic := '0';
	signal aresetn       : std_logic := '0';
	signal s_axis_tvalid : std_logic := '0';
	signal s_axis_tready : std_logic;
	signal s_axis_tdata  : std_logic_vector(2*N-1 downto 0) := (others => '0');
	signal s_axis_tlast  : std_logic := '0';
	signal m_axis_tvalid : std_logic;
	signal m_axis_tready : std_logic := '0';
	signal m_axis_tdata  : std_logic_vector(2*N-1 downto 0);
	signal m_axis_tlast  : std_logic;
	signal m_axis_tkeep  : std_logic_vector((2*N/8)-1 downto 0);

begin

	uut: entity work.fpnrdivpl_dma(rtl)
		generic map(
			N => N,
			LATENCY => LATENCY,
			FIFO_DEPTH => FIFO_DEPTH
		)
		port map(
			aclk => aclk,
			aresetn => aresetn,
			s_axis_tvalid => s_axis_tvalid,
			s_axis_tready => s_axis_tready,
			s_axis_tdata => s_axis_tdata,
			s_axis_tlast => s_axis_tlast,
			m_axis_tvalid => m_axis_tvalid,
			m_axis_tready => m_axis_tready,
			m_axis_tdata => m_axis_tdata,
			m_axis_tlast => m_axis_tlast,
			m_axis_tkeep => m_axis_tkeep
		);

	aclk <= not aclk after PERIOD/2;

	stimulus_process: process
		procedure send_word(
			constant div_word  : in std_logic_vector(N-1 downto 0);
			constant d_word    : in std_logic_vector(N-1 downto 0);
			constant last_word : in std_logic
		) is
		begin
			s_axis_tdata <= div_word & d_word;
			s_axis_tlast <= last_word;
			s_axis_tvalid <= '1';
			loop
				wait until rising_edge(aclk);
				exit when s_axis_tready = '1';
			end loop;
			s_axis_tvalid <= '0';
			s_axis_tlast <= '0';
		end procedure;
	begin
		aresetn <= '0';
		s_axis_tvalid <= '0';
		s_axis_tlast <= '0';
		s_axis_tdata <= (others => '0');

		wait for 3*PERIOD;
		wait until rising_edge(aclk);
		aresetn <= '1';
		wait until rising_edge(aclk);

		report "Phase 1: ideal sink, m_axis_tready held high";

		send_word(x"40000000", x"42700000", '0'); -- 2 and 60
		send_word(x"40800000", x"40000000", '0'); -- 4 and 2
		send_word(x"BF800000", x"424C0000", '0'); -- -1 and 51
		send_word(x"3F4CCCCD", x"3B51B717", '1'); -- 0.8 and 0.0032, packet end

		wait for 16*PERIOD;

		report "Phase 2: non-ideal sink, m_axis_tready periodically stalls";

		send_word(x"40400000", x"40C00000", '0'); -- 3 and 6
		send_word(x"40800000", x"40400000", '0'); -- 4 and 3
		send_word(x"40A00000", x"40000000", '0'); -- 5 and 2
		send_word(x"40E00000", x"40400000", '1'); -- 7 and 3, packet end

		wait for 30*PERIOD;
		report "Simulation finished";
		wait;
	end process;

	ready_process: process
	begin
		wait until aresetn = '1';

		-- Phase 1: ideal sink
		m_axis_tready <= '1';
		wait for 22*PERIOD;

		-- Phase 2: periodic stalls on the output sink
		while true loop
			m_axis_tready <= '1';
			wait for 3*PERIOD;
			m_axis_tready <= '0';
			wait for 2*PERIOD;
		end loop;
	end process;

	monitor_process: process(aclk)
		variable out_count : integer := 0;
	begin
		if rising_edge(aclk) then
			if m_axis_tvalid = '1' and m_axis_tready = '1' then
				out_count := out_count + 1;
				report "Output " & integer'image(out_count) &
				       " data_lo=0x" & to_hstring(m_axis_tdata(N-1 downto 0)) &
				       " tlast=" & std_logic'image(m_axis_tlast);
			end if;
		end if;
	end process;

end behavioral;
