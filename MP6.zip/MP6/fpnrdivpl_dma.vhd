library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity fpnrdivpl_dma is
	generic (
		N          : integer := 32;
		LATENCY    : integer := 5;
		FIFO_DEPTH : integer := 8
	);
	port (
		aclk           : in  std_logic;
		aresetn        : in  std_logic;

		-- Input AXI-Stream: each beat carries two FP32 operands packed into 64 bits.
		s_axis_tvalid  : in  std_logic;
		s_axis_tready  : out std_logic;
		s_axis_tdata   : in  std_logic_vector(2*N-1 downto 0);
		s_axis_tlast   : in  std_logic;

		-- Output AXI-Stream: each beat carries one FP32 result in the low half.
		m_axis_tvalid  : out std_logic;
		m_axis_tready  : in  std_logic;
		m_axis_tdata   : out std_logic_vector(2*N-1 downto 0);
		m_axis_tlast   : out std_logic;
		m_axis_tkeep   : out std_logic_vector((2*N/8)-1 downto 0)
	);
end fpnrdivpl_dma;

architecture rtl of fpnrdivpl_dma is

	type data_fifo_t is array (0 to FIFO_DEPTH-1) of std_logic_vector(2*N-1 downto 0);
	type last_fifo_t is array (0 to FIFO_DEPTH-1) of std_logic;

	signal divide_rst : std_logic;

	signal in_fire    : std_logic;
	signal out_fire   : std_logic;
	signal start_core : std_logic;
	signal done_core  : std_logic;
	signal q_core     : std_logic_vector(N-1 downto 0);
	signal tready, tavalid : std_logic;

	signal last_pipe  : std_logic_vector(LATENCY-1 downto 0) := (others => '0');

	signal fifo_data  : data_fifo_t := (others => (others => '0'));
	signal fifo_last  : last_fifo_t := (others => '0');
	signal wr_ptr     : integer range 0 to FIFO_DEPTH-1 := 0;
	signal rd_ptr     : integer range 0 to FIFO_DEPTH-1 := 0;
	signal fifo_count : integer range 0 to FIFO_DEPTH := 0;

	signal outstanding_count : integer range 0 to FIFO_DEPTH := 0;

begin
-- bm3fu

	divide_rst <= not aresetn;

	tready <= '1' when outstanding_count < FIFO_DEPTH else '0';
	s_axis_tready <= tready;
	tavalid <= '1' when fifo_count > 0 else '0';
	m_axis_tvalid <= tavalid;
	m_axis_tdata  <= fifo_data(rd_ptr) when fifo_count > 0 else (others => '0');
	m_axis_tlast  <= fifo_last(rd_ptr) when fifo_count > 0 else '0';
	m_axis_tkeep  <= (others => '1');

	in_fire    <= s_axis_tvalid and tready;
	out_fire   <= tavalid and m_axis_tready;
	start_core <= in_fire;

	entity_divide: entity work.nrdivpl(behavioral)
		generic map(N => N)
		port map(
			clk   => aclk,
			reset => divide_rst,
			start => start_core,
			done  => done_core,
			div   => s_axis_tdata(N-1 downto 0),
			d     => s_axis_tdata(2*N-1 downto N),
			q     => q_core
		);

	stream_process: process(aclk)
		variable next_wr_ptr        : integer range 0 to FIFO_DEPTH-1;
		variable next_rd_ptr        : integer range 0 to FIFO_DEPTH-1;
		variable next_fifo_count    : integer range 0 to FIFO_DEPTH;
		variable next_outstanding   : integer range 0 to FIFO_DEPTH;
	begin
		if rising_edge(aclk) then
			if aresetn = '0' then
				last_pipe <= (others => '0');
				wr_ptr <= 0;
				rd_ptr <= 0;
				fifo_count <= 0;
				outstanding_count <= 0;
			else
				last_pipe(0) <= in_fire and s_axis_tlast;
				for i in 1 to LATENCY-1 loop
					last_pipe(i) <= last_pipe(i-1);
				end loop;

				next_wr_ptr      := wr_ptr;
				next_rd_ptr      := rd_ptr;
				next_fifo_count  := fifo_count;
				next_outstanding := outstanding_count;

				if in_fire = '1' then
					next_outstanding := next_outstanding + 1;
				end if;

				if out_fire = '1' then
					if rd_ptr = FIFO_DEPTH-1 then
						next_rd_ptr := 0;
					else
						next_rd_ptr := rd_ptr + 1;
					end if;

					next_fifo_count := next_fifo_count - 1;
					next_outstanding := next_outstanding - 1;
				end if;

				if done_core = '1' then
					fifo_data(wr_ptr)(2*N-1 downto N) <= (others => '0');
					fifo_data(wr_ptr)(N-1 downto 0) <= q_core;
					fifo_last(wr_ptr) <= last_pipe(LATENCY-1);

					if wr_ptr = FIFO_DEPTH-1 then
						next_wr_ptr := 0;
					else
						next_wr_ptr := wr_ptr + 1;
					end if;

					next_fifo_count := next_fifo_count + 1;
				end if;

				wr_ptr <= next_wr_ptr;
				rd_ptr <= next_rd_ptr;
				fifo_count <= next_fifo_count;
				outstanding_count <= next_outstanding;
			end if;
		end if;
	end process;

end rtl;
