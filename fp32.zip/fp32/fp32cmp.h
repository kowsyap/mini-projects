/* fp32cmp.h */

#include "xparameters.h"
#include "xil_types.h"

#ifndef FP32CMP_H
#define FP32CMP_H
#endif

#define FP32CMP_BASEADDR  XPAR_FP32_COMPARE_0_BASEADDR
#define FP32CMP_A_REG        FP32CMP_BASEADDR + 0
#define FP32CMP_B_REG        FP32CMP_BASEADDR + 4
#define FP32CMP_STATUS_REG   FP32CMP_BASEADDR + 8
#define FP32CMP_EXPDIFF_REG  FP32CMP_BASEADDR + 12

#define FP32CMP_STATUS_A_GT_B      (1U << 0)
#define FP32CMP_STATUS_A_LT_B      (1U << 1)
#define FP32CMP_STATUS_ABS_A_GT_B  (1U << 2)
#define FP32CMP_STATUS_ABS_A_LT_B  (1U << 3)
#define FP32CMP_STATUS_A_EQ_B      (1U << 4)
#define FP32CMP_STATUS_ABS_A_EQ_B  (1U << 5)
#define FP32CMP_STATUS_A_IS_ZERO   (1U << 6)
#define FP32CMP_STATUS_B_IS_ZERO   (1U << 7)

void fp32cmp_set_a(u32 a);
void fp32cmp_set_b(u32 b);
void fp32cmp_set_inputs(u32 a, u32 b);

u32 fp32cmp_get_a(void);
u32 fp32cmp_get_b(void);
u32 fp32cmp_get_status(void);
u32 fp32cmp_get_exp_diff(void);

void fp32cmp_float(float a, float b, u32* status, u32* exp_diff);