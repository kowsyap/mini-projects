/*
 * fp32cmp_test.c: simple test application for fp32_compare_ip
 */

#include <stdio.h>
#include "fp32cmp.h"

static void fp32_compare(float a, float b)
{
    uint32_t *aptr = &a;
    uint32_t *bptr = &b;

    unsigned int status = 0;
    unsigned int exp_diff = 0;

    fp32cmp_float(a, b, &status, &exp_diff);

    printf("a decimal: %.6f\r\n", a);
    printf("FP Hex: %08X\r\n", *aptr);
    printf("b decimal: %.6f\r\n", b);
    printf("FP Hex: %08X\r\n", *bptr);
    printf("a > b: %u\r\n", (status & FP32CMP_STATUS_A_GT_B) ? 1U : 0U);
    printf("b > a: %u\r\n", (status & FP32CMP_STATUS_A_LT_B) ? 1U : 0U);
    printf("|a| > |b|: %u\r\n", (status & FP32CMP_STATUS_ABS_A_GT_B) ? 1U : 0U);
    printf("|b| > |a|: %u\r\n", (status & FP32CMP_STATUS_ABS_A_LT_B) ? 1U : 0U);
    printf("a = b: %u\r\n", (status & FP32CMP_STATUS_A_EQ_B) ? 1U : 0U);
    printf("|a| = |b|: %u\r\n", (status & FP32CMP_STATUS_ABS_A_EQ_B) ? 1U : 0U);
    printf("a = 0: %u\r\n", (status & FP32CMP_STATUS_A_IS_ZERO) ? 1U : 0U);
    printf("b = 0: %u\r\n", (status & FP32CMP_STATUS_B_IS_ZERO) ? 1U : 0U);
    printf("Exp diff: %u\r\n\n", exp_diff);
}

int main(void)
{

    fp32_compare(0.0f, 51.0f);
    fp32_compare(0.0f, 0.0f);
    fp32_compare(0.1f, 4.0f);
    fp32_compare(0.1f, -0.01f);

    return 0;
}
