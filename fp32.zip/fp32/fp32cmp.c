/* fp32cmp.c */
#ifndef FP32CMP_H
#include "fp32cmp.h"
#endif
#include "xil_io.h"

void fp32cmp_set_a(u32 a)
{
    Xil_Out32(FP32CMP_A_REG, a);
}

void fp32cmp_set_b(u32 b)
{
    Xil_Out32(FP32CMP_B_REG, b);
}

void fp32cmp_set_inputs(u32 a, u32 b)
{
    Xil_Out32(FP32CMP_A_REG, a);
    Xil_Out32(FP32CMP_B_REG, b);
}

u32 fp32cmp_get_a(void)
{
    return Xil_In32(FP32CMP_A_REG);
}

u32 fp32cmp_get_b(void)
{
    return Xil_In32(FP32CMP_B_REG);
}

u32 fp32cmp_get_status(void)
{
    return Xil_In32(FP32CMP_STATUS_REG);
}

u32 fp32cmp_get_exp_diff(void)
{
    return Xil_In32(FP32CMP_EXPDIFF_REG);
}

void fp32cmp_float(float a, float b, u32* status, u32* exp_diff)
{
    union {
        float f;
        u32 u;
    } a_bits, b_bits;

    a_bits.f = a;
    b_bits.f = b;

    fp32cmp_set_inputs(a_bits.u, b_bits.u);

    if (status != 0) {
        *status = fp32cmp_get_status();
    }
    if (exp_diff != 0) {
        *exp_diff = fp32cmp_get_exp_diff();
    }

}
