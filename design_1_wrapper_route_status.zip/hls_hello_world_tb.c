#include <stdlib.h>
#include <stdio.h>
#include <math.h>

/* Variable definition section */

#define N 16

/* User functions */

float sqrt_classic(float);

float hls_sqrt(float);

void dumpresults(float [N]);

/* Main application */

int main(void)
{
    float input[N], classicoutput[N], hlsoutput[N];

    printf("Initialize arrays\n\r");
    for (int i = 0; i<N; i++)
        input[i] = (float)i;

    printf("Start Classic Implementation\n\r");
    for (int i = 0; i<N; i++)
        classicoutput[i] =  sqrt_classic(input[i]);
   
    dumpresults(classicoutput);

    printf("Start HLS Implementation\n\r");

    for (int i = 0; i<N; i++)
        hlsoutput[i] =  hls_sqrt(input[i]);
   

    dumpresults(hlsoutput);

    return 0;
}


float sqrt_classic(float input){
    return pow(input,0.5);
}

void dumpresults(float result[N]){
    for (int i = 0; i < N; i++)
        printf("Input %.2f Square Root %.8f \n\r", (float)i, result[i]);
}


