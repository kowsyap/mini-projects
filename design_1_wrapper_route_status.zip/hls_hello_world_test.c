#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xhls_sqrt.h"
#include "xil_io.h"

static XHls_sqrt Hls_sqrt_0; /* The Instance of the Square Root Driver */

#include "xil_exception.h"

/* This section allows for SGUGIC or AXI Interrupt Controller */

#ifdef XPAR_INTC_0_DEVICE_ID
 #include "xintc.h"
 #include <stdio.h>
#else
 #include "xscugic.h"
 #include "xil_printf.h"
#endif

#ifdef XPAR_INTC_0_DEVICE_ID
 #define INTC_DEVICE_ID	XPAR_INTC_0_DEVICE_ID
 #define INTC		XIntc
 #define INTC_HANDLER	XIntc_InterruptHandler
#else
 #define INTC_DEVICE_ID	XPAR_SCUGIC_SINGLE_DEVICE_ID
 #define INTC		XScuGic
 #define INTC_HANDLER	XScuGic_InterruptHandler
#endif /* XPAR_INTC_0_DEVICE_ID */

#define XHLS_SQRT_0_INTR 61U

static INTC Intc;

int ConfigureInterrupts(INTC* IntcInstancePtr);

int HlsSqrtSetupIntrSystem(INTC *IntcInstancePtr, XHls_sqrt *InstancePtr,
			u16 IntrId, void *Handler);

void SetupExceptions(INTC *IntcInstancePtr);

void Hls_sqrt_0_Handler(void);

volatile int finished;

#define BIT0 1
#define BIT1 2

#define ITERATIONS 10

int main()
{
    init_platform();

    print("Start HLS Square Root Demo\n\r");

	XHls_sqrt_Config *Config;

	Config = XHls_sqrt_LookupConfig(XPAR_HLS_SQRT_0_BASEADDR);
	if (!Config) {
		xil_printf("No config found for HLS Square Root\r\n");

		return XST_FAILURE;
	} else xil_printf("Config found for HLS Square Root\r\n");

	int Status = XHls_sqrt_CfgInitialize(&Hls_sqrt_0, Config);
	
	XHls_sqrt_EnableAutoRestart(&Hls_sqrt_0);

	Status = ConfigureInterrupts(&Intc);
	if (Status != XST_SUCCESS) {
		xil_printf("Configuration Fail\r\n");
		return XST_FAILURE;
	} else xil_printf("Configuration Success\r\n");

	Status = HlsSqrtSetupIntrSystem(&Intc, &Hls_sqrt_0, 
			XHLS_SQRT_0_INTR, Hls_sqrt_0_Handler);
	if (Status != XST_SUCCESS) {
		xil_printf("Interrupt Hls Sqrt Setup Fail\r\n");
		return XST_FAILURE;
	} else xil_printf("Interrupt Hls Sqrt Setup Success\r\n");

	SetupExceptions(&Intc);

	float testval;
	uint32_t *testvalptr = (u32 *)&testval;
	uint32_t result;
	float *resultptr = (float *) &result;
		
	/* Main Loop */
	for (int i = 0; i<ITERATIONS; i++){
	
		testval = (float)i;

		XHls_sqrt_Set_input_r(&Hls_sqrt_0, *testvalptr);
		
		XHls_sqrt_Start(&Hls_sqrt_0);
		
		while (!finished){  }
			result =  XHls_sqrt_Get_return(&Hls_sqrt_0);
		finished = 0;
		
		printf("The square root of %.8f is %.8f\n\r", testval, *resultptr);
	
	}

    cleanup_platform();
    return 0;
}

int ConfigureInterrupts(INTC* IntcInstancePtr){
	XScuGic_Config *IntcConfig;

	/*
	 * Initialize the interrupt controller driver so that it is ready to
	 * use.
	 */
	IntcConfig = XScuGic_LookupConfig(INTC_DEVICE_ID);
	if (NULL == IntcConfig) {
		return XST_FAILURE;
	}

	int Result = XScuGic_CfgInitialize(IntcInstancePtr, IntcConfig,
					IntcConfig->CpuBaseAddress);
	if (Result != XST_SUCCESS) {
		return XST_FAILURE;
	}
	return XST_SUCCESS;
}


int HlsSqrtSetupIntrSystem(INTC *IntcInstancePtr, XHls_sqrt *InstancePtr,
			u16 IntrId, void *Handler)
{

	XScuGic_SetPriorityTriggerType(IntcInstancePtr, IntrId,
					0xA0, 0x3);

	int Result;
	
	/*
	 * Connect the interrupt handler that will be called when an
	 * interrupt occurs for the device.
	 */

	Result = XScuGic_Connect(IntcInstancePtr, IntrId,
				 Handler, InstancePtr);
	if (Result != XST_SUCCESS) {
		return Result;
	}

	/* Enable the interrupt for the GPIO device.*/
	XScuGic_Enable(IntcInstancePtr, IntrId);

	/*
	 * Enable the GPIO channel interrupts so that push button can be
	 * detected and enable interrupts for the GPIO device
	 */
	XHls_sqrt_InterruptEnable(InstancePtr, BIT0);
	XHls_sqrt_InterruptGlobalEnable(InstancePtr);
	return XST_SUCCESS;

}

void SetupExceptions(INTC *IntcInstancePtr){
/*
 * Initialize the exception table and register the interrupt
 * controller handler with the exception table
 */
	Xil_ExceptionInit();

	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
		 (Xil_ExceptionHandler)INTC_HANDLER, IntcInstancePtr);

	/* Enable non-critical exceptions */
	Xil_ExceptionEnable();
}

void Hls_sqrt_0_Handler(void){
	u32 Status = XHls_sqrt_InterruptGetStatus(&Hls_sqrt_0);
	XHls_sqrt_InterruptDisable(&Hls_sqrt_0, Status);
	XHls_sqrt_InterruptClear(&Hls_sqrt_0, Status);
	XHls_sqrt_InterruptEnable(&Hls_sqrt_0, Status);
	finished=1;
}