#include <stdlib.h>
#include <stdio.h>
#include <math.h>

/* Variable definition section */


/* User functions */

float hls_sqrt(float);

float hls_sqrt(float input){
#pragma HLS INTERFACE s_axilite port=input bundle=A
#pragma HLS INTERFACE s_axilite port=return bundle=A
#pragma HLS PIPELINE off

    return pow(input,0.5);

}
