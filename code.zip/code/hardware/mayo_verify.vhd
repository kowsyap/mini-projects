library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use work.mayo_pkg.all;

entity mayo_verify is
    generic (
        round  : positive := 2;
        w      : positive := MAYO_W;
        nibble : positive := MAYO_NIBBLE
    );
    port (
        clk_i : in  std_logic;
        reset_i : in std_logic;

        esk_calc_i : in std_logic;
        sig_dec_calc_i : in std_logic;
        qa_calc_i : in std_logic;

        tdata_i : in  std_logic_vector(16*MAYO_NIBBLE-1 downto 0);
        tvalid_i : in std_logic;
        tlast_i : in std_logic;
        tready_o : out std_logic;

        esk_done_o : out std_logic;
        sig_dec_done_o : out std_logic;
        qa_done_o : out std_logic;

        tdata_o : out std_logic_vector(16*MAYO_NIBBLE-1 downto 0);
        tvalid_o : out std_logic;
        tlast_o  : out std_logic;
        tready_i : in  std_logic
    );
end entity mayo_verify;

architecture behavioral of mayo_verify is

    constant P        : mayo_params_t := get_mayo_params(round);
    constant param_m  : positive := P.m;
    constant param_n  : positive := P.n;
    constant param_o  : positive := P.o;
    constant param_k  : positive := P.k;
    constant param_d  : positive := P.n - P.o;

    constant m_read_bits : positive := param_m * nibble;

    -- esk_decoder <-> data_storage
    signal ps_load     : std_logic;
    signal ps_mem_load : std_logic;
    signal ps_wr       : std_logic;
    signal mem_wr      : std_logic;
    signal p_reg       : std_logic_vector(param_m*nibble-1 downto 0);
    signal ps_col_idx  : std_logic_vector(clog2(param_n)-1 downto 0);
    signal ps_row_idx  : std_logic_vector(clog2(param_n)-1 downto 0);
    signal mem_ram_addr: std_logic_vector(clog2(param_n)-1 downto 0);

    -- sig_decoder <-> data_storage
    signal s_data       : std_logic_vector(param_n*nibble-1 downto 0);
    signal s_wr_addr    : std_logic_vector(nibble-1 downto 0);
    signal s_wr         : std_logic;
    signal s_addr       : std_logic_vector(nibble-1 downto 0);

    -- data_storage <-> quad_accumulator
    signal u_reg   : std_logic_vector(2*m_read_bits-1 downto 0);

    signal sk_input_ready_o, sig_input_ready_o  : std_logic;

begin

    tready_o <= (sk_input_ready_o and esk_calc_i) or (sig_input_ready_o and sig_dec_calc_i);

    esk_decode : entity work.esk_decoder
        generic map (
            w        => w,
            nibble   => nibble,
            param_m  => param_m,
            param_n  => param_n,
            param_o  => param_o,
            param_d  => param_d
        )
        port map (
            clk            => clk_i,
            reset          => reset_i,
            calc           => esk_calc_i,

            vector_input_ready => sk_input_ready_o,
            vector_input       => tdata_i,
            vector_tlast       => tlast_i,
            vector_input_valid => tvalid_i,

            p_data         => p_reg,
            col_idx        => ps_col_idx,
            row_idx        => ps_row_idx,
            ps_load        => ps_load,
            ps_mem_load    => ps_mem_load,
            ps_wr          => ps_wr,
            mem_wr         => mem_wr,
            done           => esk_done_o
        );

    sig_decoder_inst : entity work.sig_decoder
        generic map (
            w        => w,
            nibble   => nibble,
            param_n  => param_n,
            param_k  => param_k
        )
        port map (
            clk                => clk_i,
            reset              => reset_i,
            calc               => sig_dec_calc_i,
            vector_input_ready => sig_input_ready_o,
            vector_input       => tdata_i,
            vector_tlast       => tlast_i,
            vector_input_valid => tvalid_i,
            s_data             => s_data,
            s_addr             => s_wr_addr,
            s_wr               => s_wr,
            done               => sig_dec_done_o
        );

    memory_bank : entity work.data_storage
        generic map (
            w        => w,
            nibble   => nibble,
            param_m  => param_m,
            param_n  => param_n,
            param_o  => param_o,
            param_k  => param_k
        )
        port map (
            clk         => clk_i,
            reset       => reset_i,
            calc        => esk_calc_i,
            s_wr        => s_wr,
            s_in        => s_data,
            s_wr_addr   => s_wr_addr,
            s_addr      => s_addr,
            ps_load     => ps_load,
            ps_mem_load => ps_mem_load,
            ps_wr       => ps_wr,
            mem_wr      => mem_wr,
            input_data  => p_reg,
            col_idx     => ps_col_idx,
            row_idx     => ps_row_idx,
            ps_addr     => mem_ram_addr,
            u_out       => u_reg
        );

    quad_accum_inst : entity work.quad_accumulator
        generic map (
            w        => w,
            nibble   => nibble,
            param_m  => param_m,
            param_n  => param_n,
            param_o  => param_o,
            param_k  => param_k
        )
        port map (
            clk          => clk_i,
            reset        => reset_i,
            calc         => qa_calc_i,
            u_data       => u_reg,
            s_addr       => s_addr,
            mem_ram_addr => mem_ram_addr,

            y            => tdata_o,
            y_valid      => tvalid_o,
            y_last       => tlast_o,
            y_ready      => tready_i,

            done         => qa_done_o
        );

end behavioral;