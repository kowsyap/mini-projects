library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.mayo_pkg.all;

-- AXI-Lite register map (byte-addressed, 32-bit registers):
--   0x00  CALC   (RW)  [2]=qa_calc  [1]=esk_calc  [0]=sig_dec_calc
--   0x04  STATUS (RO)  [2]=qa_done  [1]=esk_done  [0]=sig_dec_done
--
-- AXI Stream Slave  (S_AXIS): sig / sk data from DMA
-- AXI Stream Master (M_AXIS): y result to DMA

entity mayo_verify_accelerator is
    generic (
        round  : positive := 2;
        w      : positive := MAYO_W;
        nibble : positive := MAYO_NIBBLE
    );
    port (
        -- ── AXI-Lite slave ──────────────────────────────────────────────────
        s_axi_aclk    : in  std_logic;
        s_axi_aresetn : in  std_logic;

        s_axi_awaddr  : in  std_logic_vector(3 downto 0);
        s_axi_awvalid : in  std_logic;
        s_axi_awready : out std_logic;

        s_axi_wdata   : in  std_logic_vector(31 downto 0);
        s_axi_wvalid  : in  std_logic;
        s_axi_wready  : out std_logic;

        s_axi_bresp   : out std_logic_vector(1 downto 0);
        s_axi_bvalid  : out std_logic;
        s_axi_bready  : in  std_logic;

        s_axi_araddr  : in  std_logic_vector(3 downto 0);
        s_axi_arvalid : in  std_logic;
        s_axi_arready : out std_logic;

        s_axi_rdata   : out std_logic_vector(31 downto 0);
        s_axi_rresp   : out std_logic_vector(1 downto 0);
        s_axi_rvalid  : out std_logic;
        s_axi_rready  : in  std_logic;

        -- ── AXI Stream slave (sig / sk in from DMA) ─────────────────────────
        s_axis_tdata  : in  std_logic_vector(16*nibble-1 downto 0);
        s_axis_tvalid : in  std_logic;
        s_axis_tlast  : in  std_logic;
        s_axis_tready : out std_logic;

        -- ── AXI Stream master (y out to DMA) ────────────────────────────────
        m_axis_tdata  : out std_logic_vector(16*nibble-1 downto 0);
        m_axis_tvalid : out std_logic;
        m_axis_tlast  : out std_logic;
        m_axis_tready : in  std_logic
    );
end entity mayo_verify_accelerator;

architecture behavioral of mayo_verify_accelerator is

    -- internal reset (active high)
    signal reset : std_logic;

    -- AXI-Lite register storage
    signal calc_reg   : std_logic_vector(2 downto 0) := (others => '0');

    -- AXI-Lite write channel
    signal aw_ready   : std_logic := '0';
    signal w_ready    : std_logic := '0';
    signal b_valid    : std_logic := '0';
    signal aw_addr_r  : std_logic_vector(3 downto 0);

    -- AXI-Lite read channel
    signal ar_ready   : std_logic := '0';
    signal r_valid    : std_logic := '0';
    signal r_data     : std_logic_vector(31 downto 0) := (others => '0');

    -- core control/status
    signal sig_dec_calc : std_logic;
    signal esk_calc     : std_logic;
    signal qa_calc      : std_logic;
    signal sig_dec_done : std_logic;
    signal esk_done     : std_logic;
    signal qa_done      : std_logic;
    signal sk_ready     : std_logic;
    signal sig_ready    : std_logic;

    -- y stream from core
    signal y_data  : std_logic_vector(16*nibble-1 downto 0);
    signal y_valid : std_logic;
    signal y_last  : std_logic;

begin

    reset <= not s_axi_aresetn;

    -- ── Register bit assignments ─────────────────────────────────────────────
    sig_dec_calc <= calc_reg(0);
    esk_calc     <= calc_reg(1);
    qa_calc      <= calc_reg(2);

    -- ── mayo_verify core ─────────────────────────────────────────────────────
    core : entity work.mayo_verify
        generic map (
            round  => round,
            w      => w,
            nibble => nibble
        )
        port map (
            clk_i             => s_axi_aclk,
            reset_i           => reset,
            sig_dec_calc_i    => sig_dec_calc,
            esk_calc_i        => esk_calc,
            qa_calc_i         => qa_calc,
            tdata_i           => s_axis_tdata,
            tvalid_i          => s_axis_tvalid,
            tlast_i           => s_axis_tlast,
            tready_o          => s_axis_tready,
            sig_dec_done_o    => sig_dec_done,
            esk_done_o        => esk_done,
            qa_done_o         => qa_done,
            tdata_o           => m_axis_tdata,
            tvalid_o          => m_axis_tvalid,
            tlast_o           => m_axis_tlast,
            tready_i          => m_axis_tready
        );

    -- ── AXI-Lite write logic ─────────────────────────────────────────────────
    axi_write : process(s_axi_aclk, s_axi_aresetn)
    begin
        if s_axi_aresetn = '0' then
            aw_ready  <= '0';
            w_ready   <= '0';
            b_valid   <= '0';
            calc_reg  <= (others => '0');
            aw_addr_r <= (others => '0');
        elsif rising_edge(s_axi_aclk) then

            -- address handshake
            if s_axi_awvalid = '1' and aw_ready = '0' then
                aw_ready  <= '1';
                aw_addr_r <= s_axi_awaddr;
            else
                aw_ready <= '0';
            end if;

            -- data handshake + register write
            if s_axi_wvalid = '1' and w_ready = '0' then
                w_ready <= '1';
                if aw_addr_r(3 downto 2) = "00" then   -- 0x00 CALC
                    calc_reg <= s_axi_wdata(2 downto 0);
                end if;
                -- 0x04 STATUS is read-only, writes ignored
            else
                w_ready <= '0';
            end if;

            -- write response
            if w_ready = '1' and s_axi_wvalid = '1' then
                b_valid <= '1';
            elsif s_axi_bready = '1' then
                b_valid <= '0';
            end if;

        end if;
    end process;

    s_axi_awready <= aw_ready;
    s_axi_wready  <= w_ready;
    s_axi_bvalid  <= b_valid;
    s_axi_bresp   <= "00";  -- OKAY

    -- ── AXI-Lite read logic ──────────────────────────────────────────────────
    axi_read : process(s_axi_aclk, s_axi_aresetn)
    begin
        if s_axi_aresetn = '0' then
            ar_ready <= '0';
            r_valid  <= '0';
            r_data   <= (others => '0');
        elsif rising_edge(s_axi_aclk) then

            if s_axi_arvalid = '1' and ar_ready = '0' then
                ar_ready <= '1';
                if s_axi_araddr(3 downto 2) = "00" then  -- 0x00 CALC
                    r_data <= (31 downto 3 => '0') & calc_reg;
                else                                      -- 0x04 STATUS
                    r_data <= (31 downto 3 => '0') & qa_done & esk_done & sig_dec_done;
                end if;
                r_valid <= '1';
            else
                ar_ready <= '0';
            end if;

            if r_valid = '1' and s_axi_rready = '1' then
                r_valid <= '0';
            end if;

        end if;
    end process;

    s_axi_arready <= ar_ready;
    s_axi_rvalid  <= r_valid;
    s_axi_rdata   <= r_data;
    s_axi_rresp   <= "00";  -- OKAY

end behavioral;
