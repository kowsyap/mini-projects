LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.all;
USE IEEE.std_logic_textio.all;

LIBRARY std;
USE std.textio.all;
USE work.mayo_tb_pkg.all;

ENTITY mayo_verify_tb IS
END mayo_verify_tb;

ARCHITECTURE behavior OF mayo_verify_tb IS

    constant w: integer := 8;
    constant nibble: integer := 4;

    --ROUND 1
--     constant version : integer := 1;

    --ROUND 2
    constant version : integer := 2;

    --mayo1
    constant set : integer := 1;

    --mayo2
    -- constant set : integer := 2;

    --mayo3
    -- constant set : integer := 3;

    --mayo5
    -- constant set : integer := 5;



    FILE cpk_inpFile: TEXT OPEN READ_MODE IS cpk_file(version, set);
    FILE msg_inpFile: TEXT OPEN READ_MODE IS msg_file(version, set);
    FILE sig_inpFile: TEXT OPEN READ_MODE IS sig_file(version, set);


    constant nibble_count : integer := 16;

    signal clk : std_logic := '0';
    signal reset : std_logic := '0';
    signal calc : std_logic := '0';
    signal msg_bytes : std_logic_vector(2*w-1 downto 0) := (others => '0');

    signal sk_data_i : std_logic_vector(16*nibble-1 downto 0) := (others => '0');
    signal msg_i : std_logic_vector(16*nibble-1 downto 0) := (others => '0');
    signal sig_verify_data_i : std_logic_vector(16*nibble-1 downto 0) := (others => '0');

    signal sk_input_ready_o : std_logic;
    signal msg_input_ready_o : std_logic;
    signal sig_input_ready_o : std_logic;

    signal sig_out_ready_i : std_logic := '0';
    signal sig_out_read_o : std_logic;
    signal sig_valid_o : std_logic;
    signal sig_gen_data_o : std_logic_vector(16*nibble-1 downto 0);
    signal done_o : std_logic;

    constant clk_period : time := 10 ns;
    constant initial_delay : time := 100 ns;

    signal cpk_done : std_logic := '0';
    signal msg_done : std_logic := '0';
    signal sig_done : std_logic := '0';

BEGIN

    clk <= not clk after clk_period/2;
    reset <= '1' after initial_delay, '0' after initial_delay + clk_period;

    dut: ENTITY work.mayo
    GENERIC MAP (
        round => version,
        set => set
    )
    PORT MAP (
        clk_i => clk,
        reset_i => reset,

        msg_bytes_i => msg_bytes,
        mode_i => '1',

        msg_data_i => msg_i,
        msg_input_ready_o => msg_input_ready_o,

        sk_data_i => sk_data_i,
        sk_input_ready_o => sk_input_ready_o,

        sig_verify_data_i => sig_verify_data_i,
        sig_input_ready_o => sig_input_ready_o,

        sig_out_ready_i => '0',
        sig_out_read_o => open,
        sig_valid_o => sig_valid_o,
        sig_gen_data_o => open,

        calc_i => calc,
        done_o => done_o
    );

    stim_sk : process
        variable bit_vec : std_logic_vector(16*nibble-1 downto 0);
        variable VectorLine : LINE;
        variable VectorValid : BOOLEAN;
    begin
        wait until reset = '0';
        while not endfile(cpk_inpFile) loop
            wait until rising_edge(clk);
            if sk_input_ready_o = '1' then
                readline(cpk_inpFile, VectorLine);
                hread(VectorLine, bit_vec, good => VectorValid);
                next when not VectorValid;
                sk_data_i <= bit_vec;
            end if;
        end loop;
        cpk_done <= '1';
        wait;
    end process;

    stim_msg : process
        variable bit_vec : std_logic_vector(16*nibble-1 downto 0);
        variable VectorLine : LINE;
        variable VectorValid : BOOLEAN;
    begin
        wait until reset = '0';
        while not endfile(msg_inpFile) loop
            wait until rising_edge(clk);
            if msg_input_ready_o = '1' then
                readline(msg_inpFile, VectorLine);
                hread(VectorLine, bit_vec, good => VectorValid);
                next when not VectorValid;
                msg_i <= bit_vec;
            end if;
        end loop;
        msg_done <= '1';
        wait;
    end process;

    stim_sig : process
        variable bit_vec : std_logic_vector(nibble_count*nibble-1 downto 0);
        variable VectorLine : LINE;
        variable VectorValid : BOOLEAN;
    begin
        wait until reset = '0';
        while not endfile(sig_inpFile) loop
            wait until rising_edge(clk);
            if sig_input_ready_o = '1' then
                readline(sig_inpFile, VectorLine);
                hread(VectorLine, bit_vec, good => VectorValid);
                next when not VectorValid;
                sig_verify_data_i <= bit_vec;
            end if;
        end loop;
        sig_done <= '1';
        wait;
    end process;

    control_proc : process
        variable start_time : time;
        variable end_time : time;
    begin
        wait until reset = '0';
        msg_bytes <= "0000000000100000";
        calc <= '1';
        start_time := now;
        report "verify calc=1 at " & time'image(start_time) severity note;

        wait until done_o = '1';
        end_time := now;
        report "verify done=1 at " & time'image(end_time) severity note;
        report "verify execution time = " & time'image(end_time - start_time) severity note;

        if sig_valid_o = '1' then
            report "Verification SUCCESS" severity note;
        else
            report "Verification FAIL" severity warning;
        end if;

        wait for clk_period;
        calc <= '0';
        assert false report "Simulation complete" severity note;
        wait;
    end process;

END behavior;
