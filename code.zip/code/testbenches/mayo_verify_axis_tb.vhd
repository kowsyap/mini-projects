library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use IEEE.STD_LOGIC_TEXTIO.ALL;

library std;
use std.textio.all;

use work.mayo_tb_pkg.all;

entity mayo_verify_axis_tb is
end entity mayo_verify_axis_tb;

architecture behavior of mayo_verify_axis_tb is

    constant round : positive := 2;
    constant w : positive := 8;
    constant nibble : positive := 4;
    constant stream_width : positive := 16 * nibble;

    file sig_inpFile : text open read_mode is sig_file(round);
    file epk_inpFile : text open read_mode is epk_file(round);

    signal clk : std_logic := '0';
    signal reset : std_logic := '1';

    signal esk_calc : std_logic := '0';
    signal sig_dec_calc : std_logic := '0';
    signal qa_calc : std_logic := '0';

    signal tdata_i : std_logic_vector(stream_width-1 downto 0) := (others => '0');
    signal tvalid_i : std_logic := '0';
    signal tlast_i : std_logic := '0';
    signal tready_o : std_logic;

    signal esk_done_o : std_logic;
    signal sig_dec_done_o : std_logic;
    signal qa_done_o : std_logic;

    signal tdata_o : std_logic_vector(stream_width-1 downto 0);
    signal tvalid_o : std_logic;
    signal tlast_o : std_logic;
    signal tready_i : std_logic := '1';

    constant clk_period : time := 10 ns;

    procedure drive_stream_file(
        file vec_file : text;
        signal clk_s : in std_logic;
        signal tready_s : in std_logic;
        signal tdata_s : out std_logic_vector(stream_width-1 downto 0);
        signal tvalid_s : out std_logic;
        signal tlast_s : out std_logic
    ) is
        variable vector_line : line;
        variable bit_vec : std_logic_vector(stream_width-1 downto 0);
        variable vector_valid : boolean;
        variable is_last : boolean;
    begin
        tvalid_s <= '0';
        tlast_s <= '0';
        tdata_s <= (others => '0');
        wait until rising_edge(clk_s);

        while not endfile(vec_file) loop
            readline(vec_file, vector_line);
            hread(vector_line, bit_vec, good => vector_valid);
            next when not vector_valid;

            is_last := endfile(vec_file);
            tdata_s <= bit_vec;
            tvalid_s <= '1';
            if is_last then
                tlast_s <= '1';
            else
                tlast_s <= '0';
            end if;

            loop
                wait until rising_edge(clk_s);
                exit when tready_s = '1';
            end loop;
        end loop;

        tvalid_s <= '0';
        tlast_s <= '0';
        tdata_s <= (others => '0');
    end procedure;

begin

    clk <= not clk after clk_period / 2;

    dut : entity work.mayo_verify
        generic map (
            round => round,
            w => w,
            nibble => nibble
        )
        port map (
            clk_i => clk,
            reset_i => reset,
            esk_calc_i => esk_calc,
            sig_dec_calc_i => sig_dec_calc,
            qa_calc_i => qa_calc,
            tdata_i => tdata_i,
            tvalid_i => tvalid_i,
            tlast_i => tlast_i,
            tready_o => tready_o,
            esk_done_o => esk_done_o,
            sig_dec_done_o => sig_dec_done_o,
            qa_done_o => qa_done_o,
            tdata_o => tdata_o,
            tvalid_o => tvalid_o,
            tlast_o => tlast_o,
            tready_i => tready_i
        );

    stimulus_proc : process
    begin
        reset <= '1';
        wait for 100 ns;
        wait until rising_edge(clk);
        reset <= '0';
        wait until rising_edge(clk);

        sig_dec_calc <= '1';
        report "sig_dec_calc asserted" severity note;
        drive_stream_file(sig_inpFile, clk, tready_o, tdata_i, tvalid_i, tlast_i);
        wait until rising_edge(clk) and sig_dec_done_o = '1';
        sig_dec_calc <= '0';
        report "sig_dec_done observed" severity note;
        wait until rising_edge(clk);

        esk_calc <= '1';
        report "esk_calc asserted" severity note;
        drive_stream_file(epk_inpFile, clk, tready_o, tdata_i, tvalid_i, tlast_i);
        wait until rising_edge(clk) and esk_done_o = '1';
        esk_calc <= '0';
        report "esk_done observed" severity note;
        wait until rising_edge(clk);

        qa_calc <= '1';
        report "qa_calc asserted" severity note;
        wait until rising_edge(clk) and qa_done_o = '1';
        qa_calc <= '0';
        report "qa_done observed" severity note;

        wait for clk_period;
        assert false report "Simulation complete" severity failure;
    end process;

    sink_proc : process
        variable l : line;
    begin
        wait until reset = '0';
        loop
            wait until rising_edge(clk);
            if tvalid_o = '1' and tready_i = '1' then
                hwrite(l, tdata_o);
                if tlast_o = '1' then
                    write(l, string'(" LAST"));
                end if;
                writeline(output, l);

                if tlast_o = '1' then
                    report "Observed output tlast" severity note;
                end if;
            end if;
        end loop;
    end process;

end architecture behavior;
