/* mytimer.h */

#include "xparameters.h"
#include "xscugic.h"

#ifndef MYTIMER_H
#define MYTIMER_H
#endif

#define MYTIMER_BASEADDR  XPAR_MYTIMER_V1_0_0_BASEADDR
#define MYTIMER_CTRL_REG MYTIMER_BASEADDR + 0
#define MYTIMER_COUNTER_REG MYTIMER_BASEADDR + 4
#define MYTIMER_START 1
#define MYTIMER_STOP 0
#define MYTIMER_IRQ_INTR XPAR_FABRIC_MYTIMER_V1_0_0_IRQ_INTR

void mytimer_set_counter(int);

int mytimer_get_counter();

void mytimer_start_counter();

void mytimer_stop_counter();

int mytimer_init(XScuGic*, int, int);

void mytimer_isr();


