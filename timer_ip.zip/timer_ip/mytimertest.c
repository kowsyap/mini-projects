
/*
 * mytimertest.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xparameters.h"
#include "mytimer.h"

#ifndef XPAR_SCUGIC_0_DEVICE_ID
#define XPAR_SCUGIC_0_DEVICE_ID 0
#endif

volatile int timerfinished = 0;
XScuGic Intc; /* Processor GIC interrupt controller */

int main()
{
    init_platform();
    print("Timer Test\n\r");

    int Status = mytimer_init(&Intc, XPAR_SCUGIC_0_DEVICE_ID, MYTIMER_IRQ_INTR);
	if (Status != XST_SUCCESS) {
		xil_printf("Interrupt Initialization Failed\r\n");
		return XST_FAILURE;
	} else xil_printf("Interrupt Initialization Success\r\n");

	int testcounter = 0;
	mytimer_set_counter(50000);
	mytimer_start_counter();
	while(1)
		if (timerfinished == 1){
			xil_printf("Timer Finished\n\r");
			xil_printf("Testcounter: %d\n\r",testcounter);
			break;
		} else testcounter++;


	timerfinished = 0; // reset timer interrupt
	testcounter = 0;
	mytimer_set_counter(100000);
	mytimer_start_counter();
	while(1)
		if (timerfinished == 1){
			xil_printf("Timer Finished\n\r");
			xil_printf("Testcounter: %d\n\r",testcounter);
			break;
		} else testcounter++;

	cleanup_platform();
    return 0;
}
