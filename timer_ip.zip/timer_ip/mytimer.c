/* mytimer.c */

#ifndef MYTIMER_H
#include "mytimer.h"
#endif
#include "xscugic.h"
#include "xil_io.h"

extern volatile int timerfinished;

void mytimer_set_counter(int setcounter){
		Xil_Out32(MYTIMER_COUNTER_REG, setcounter);
}

int mytimer_get_counter(){
		return Xil_In32(MYTIMER_COUNTER_REG);
}

void mytimer_start_counter(){
		Xil_Out32(MYTIMER_CTRL_REG, MYTIMER_START);
}

void mytimer_stop_counter(){
		Xil_Out32(MYTIMER_CTRL_REG, MYTIMER_STOP);
}

int mytimer_init(XScuGic* p_intc_inst, int intc_device_id, int mytimer_intr_id){
	// Local variables
	int           status = 0;
	XScuGic_Config* cfg_ptr;

	// Look up hardware configuration for device
	cfg_ptr = XScuGic_LookupConfig(intc_device_id);
	if (!cfg_ptr)
	{
		xil_printf("ERROR! No hardware configuration found for Interrupt Controller with device id %d.\r\n", intc_device_id);
		return -1;
	}

	// Initialize driver
	status = XScuGic_CfgInitialize(p_intc_inst, cfg_ptr, cfg_ptr->CpuBaseAddress);
	if (status != XST_SUCCESS)
	{
		xil_printf("ERROR! Initialization of Interrupt Controller failed with %d.\r\n", status);
		return -1;
	}

	// Set interrupt priorities and trigger type
	XScuGic_SetPriorityTriggerType(p_intc_inst, mytimer_intr_id, 0xA0, 0x3);
	// edge triggered interrupt

	// Connect handlers
	status = XScuGic_Connect(p_intc_inst, mytimer_intr_id, (Xil_InterruptHandler)mytimer_isr, 0);
	if (status != XST_SUCCESS)
	{
		xil_printf("ERROR! Failed to connect handler to the interrupt controller.\r\n", status);
		return -1;
	}

	// Enable all interrupts
	XScuGic_Enable(p_intc_inst, mytimer_intr_id);
	
	// Initialize exception table and register the interrupt controller handler with exception table
	Xil_ExceptionInit();
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT, (Xil_ExceptionHandler)XScuGic_InterruptHandler, p_intc_inst);

	// Enable non-critical exceptions
	Xil_ExceptionEnable();

	return 0;

}


void mytimer_isr(){

		timerfinished = 1;
}


