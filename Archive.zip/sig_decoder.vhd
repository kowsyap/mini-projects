library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

use work.util_pkg.all;
use work.mayo_pkg.all;

entity sig_decoder is
    generic (
        w : positive := 8;
        nibble : positive := 4;
        param_n : positive := 66;
        param_k : positive := 9;
        sha_bits : positive := w*w;
        salt_bytes : positive := 24;
        digest_bytes : positive := 32;
        digest_addr_width : positive := 5
    );
    port (
        clk                 : in  std_logic;
        reset               : in  std_logic;
        calc                : in  std_logic;
        vector_input_ready  : out  std_logic;
        vector_input_valid  : in  std_logic;
        vector_input        : in  std_logic_vector(16*nibble-1 downto 0);
        s_data              : out std_logic_vector(param_n*nibble-1 downto 0);
        s_addr              : out std_logic_vector(nibble-1 downto 0);
        s_wr                : out std_logic;
        salt_wr_addr        : out std_logic_vector(digest_addr_width-1 downto 0);
        salt_wr_data        : out std_logic_vector(sha_bits-1 downto 0);
        salt_wr             : out std_logic;
        done                : out std_logic
    );
end sig_decoder;

architecture Behavioral of sig_decoder is

    constant salt_words: integer := salt_bytes/w;
    constant digest_words: integer := digest_bytes/w;
    constant x_width : integer := calc_width16(param_n);  -- 86->3 -- 81->4 -- 118->3 -- 154->3
    constant nibble_count : positive := sha_bits / nibble; 
    constant word_count : positive := ceil_div(param_n, nibble_count); -- 86/16=6 -- 81/16=6 -- 118/16=8 -- 154/16=10 -- 66/16=5 -- 78/16=5 -- 99/16=7 -- 133/16=9
    constant final_out_size : positive := (word_count + 1) * w * w;
    constant sig_words : positive := ceil_div(param_n*param_k, 16); -- 86*10/16=54 -- 81*10/16=51 -- 118*10/16=74 -- 154*10/16=97
    constant salt_shift_add : integer := is_odd(param_k*param_n);
    
    type state_type is (IDLE, S1, S2, S3, S4, S5, S6, OK);
    signal state, next_state : state_type := IDLE;

    constant shift_rom : shift_rom16_type(0 to 2**x_width-1) := get_shift_rom16(param_n, x_width);
    constant load_rom : shift_rom16_type(0 to 2**x_width-1) := get_load_rom16(param_n, word_count, x_width);
    
    signal fifo_reg, shifted_fifo: std_logic_vector(final_out_size-1 downto 0);
    signal partial_decoded_vector: std_logic_vector(sha_bits-1 downto 0);
    signal decoded_vector : std_logic_vector(param_n*nibble-1 downto 0);
    signal salt_fifo, shifted_salt : std_logic_vector((salt_words+1)*sha_bits-1 downto 0);

    signal s: unsigned(digest_addr_width - 1 downto 0);
    signal i: unsigned(nibble-1 downto 0);
    signal x : unsigned(x_width-1 downto 0);
    signal y : unsigned(7 downto 0);  -- max 97 for param_n=154 and param_k=10
    signal expected_k_limit, k : unsigned(nibble-1 downto 0);

    signal Lx, Ex : std_logic;
    signal Lk, Ek : std_logic;
    signal Li, Ei : std_logic;
    signal Ls, Es : std_logic;
    signal Ly, Ey : std_logic;

    signal zk, zs, zi, zy : std_logic;

    signal Efifo, k_init, salt_fifo_wr, salt_ld : std_logic;
    signal k_set, k_reset, k_init_reg : std_logic := '0';

begin

    shifted_fifo <= std_logic_vector(shift_right(unsigned(fifo_reg), nibble*shift_rom(to_integer(x))));
    shifted_salt <= std_logic_vector(shift_left(unsigned(salt_fifo), nibble*(shift_rom(to_integer(x)) + salt_shift_add)));
    s_data <= decoded_vector;
    s_addr <= std_logic_vector(i);
    salt_wr_addr <= std_logic_vector(to_unsigned(digest_words, digest_addr_width) + s);

    sreg_reverse_inst1 : entity work.reverse_reg
    generic map(
        nibble => nibble,
        nibble_count => param_n
    )
    port map(
        din => shifted_fifo(param_n*nibble-1 downto 0),
        dout => decoded_vector
    );

    counterI: process(clk)
    begin
        if rising_edge(clk) then
            if Li = '1' then
                i <= (others => '0');
            elsif Ei = '1' then
                i <= i + 1;
            end if;
        end if;
    end process;

    counterS: process(clk)
    begin
        if rising_edge(clk) then
            if Ls = '1' then
                s <= (others => '0');
            elsif Es = '1' then
                s <= s + 1;
            end if;
        end if;
    end process;

    counterY: process(clk)
    begin
        if rising_edge(clk) then
            if Ly = '1' then
                y <= (others => '0');
            elsif Ey = '1' then
                y <= y + 1;
            end if;
        end if;
    end process;

    counterX: process(clk)
    begin
        if rising_edge(clk) then
            if Lx = '1' then
                x <= (others => '0');
            elsif Ex = '1' then
                x <= x + 1;
            end if;
        end if;
    end process;

    counterK: process(clk)
    begin
        if rising_edge(clk) then
            if Lk = '1' then
                k <= (others => '0');
            elsif Ek = '1' then
                k <= k + 1;
            end if;
        end if;
    end process;

    state_reg : process(clk, reset)
    begin
        if reset = '1' then
            state <= IDLE;
        elsif rising_edge(clk) then
            state <= next_state;
            if k_reset = '1' then
                k_init_reg <= '0';
            elsif k_set = '1' then
                k_init_reg <= '1';
            end if;
        end if;
    end process;

    decode_vector_inst: entity work.decode_vector
    generic map(
        nibble_count => nibble_count,
        nibble => nibble,
        reverse => true
    )
    port map(
        a => vector_input,
        result => partial_decoded_vector
    );

    esk_fifo_inst: entity work.SIPO_FIFO
        generic map(LEFT_SHIFT=>false,INPUT_WIDTH=>nibble_count*nibble,OUTPUT_WIDTH=>final_out_size)
        port map(
            clk => clk,
            reset => reset,
            serial_in => partial_decoded_vector,
            parallel_in => (others=>'0'),
            serial_out => open,
            load => Efifo,
            load_parallel => '0',
            parallel_out => fifo_reg
        );

    salt_fifo_inst: entity work.SIPO_FIFO
        generic map(LEFT_SHIFT=>true,INPUT_WIDTH=>nibble_count*nibble,OUTPUT_WIDTH=>(salt_words+1)*sha_bits)
        port map(
            clk => clk,
            reset => reset,
            serial_in => vector_input,
            parallel_in => shifted_salt,
            serial_out => salt_wr_data,
            load => salt_fifo_wr,
            load_parallel => salt_ld,
            parallel_out => salt_fifo
        );


    fsm_next : process(state, calc, zk, zs, zi, zy, k_init_reg, vector_input_valid)
    begin
        vector_input_ready <= '0';
        done <= '0';
        salt_wr <= '0';
        salt_fifo_wr <= '0';
        s_wr <= '0';
        Efifo <= '0';
        salt_ld <= '0';
        Lx <= '0';
        Ex <= '0';
        Lk <= '0';
        Ek <= '0';
        Li <= '0';
        Ei <= '0';
        Ls <= '0';
        Es <= '0';
        Ly <= '0';
        Ey <= '0';

        k_set <= '0';
        k_reset <= '0';
        k_init <= '0';
        next_state <= state;

        case state is
        when IDLE =>
            if calc = '1' then
                k_reset <= '1';
                Ls <= '1';
                Lk <= '1';
                Lx <= '1';
                Li <= '1';
                Ly <= '1';
                next_state <= S1;
            end if;

        when S1 =>
            if k_init_reg = '0' then
                k_init <= '1';
            end if;
            if zy = '1' then
                Es <= '1';
                salt_fifo_wr <= '1';
            end if;
            if zk = '0' then
                vector_input_ready <= '1';
                if vector_input_valid = '1' then
                    Ey <= '1';
                    Efifo <= '1';
                    Ek <= '1';
                end if;
            else
                Lk <= '1';
                k_set <= '1';
                next_state <= S2;
            end if;

        when S2 =>
            s_wr <= '1';
            next_state <= S3;

        when S3 =>
            Ex <= '1';
            if zi = '0' then
                Ei <= '1';
                next_state <= S1;
            else
                vector_input_ready <= '1';
                if vector_input_valid = '1' then
                    Li <= '1';
                    next_state <= S4;
                end if;
            end if;
        
        when S4 =>
            vector_input_ready <= '1';
            if vector_input_valid = '1' then
                if zs = '0' then
                    Es <= '1';
                    salt_fifo_wr <= '1';
                else
                    salt_fifo_wr <= '1';
                    next_state <= S5;
                end if;
            end if;
        
        when S5 =>
            salt_ld <= '1';
            Ls <= '1';
            next_state <= S6;
        
        when S6 =>
            if zs = '0' then
                Es <= '1';
                salt_fifo_wr <= '1';
                salt_wr <= '1';
                next_state <= S6;
            else
                next_state <= OK;
            end if;

        when OK =>
            done <= '1';
            if calc = '0' then
                next_state <= IDLE;
            end if;

        when others =>
            next_state <= IDLE;
        end case;
    end process;

    expected_k_limit <= to_unsigned(word_count, nibble) when k_init = '1' else to_unsigned(load_rom(to_integer(x)), nibble);

    zk <= '1' when k = expected_k_limit else '0';
    zs <= '1' when s = to_unsigned(salt_words, digest_addr_width) else '0';
    zi <= '1' when i = to_unsigned(param_k - 1, clog2(param_k)) else '0';
    zy <= '1' when y > to_unsigned(sig_words - 2, y'length) else '0';


end Behavioral;
