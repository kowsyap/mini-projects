library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.all;

use work.util_pkg.all;
use work.AES_pkg.all;
use work.mayo_pkg.all;

entity mayo_datapath is
    generic(
        w : positive := 8;
        nibble : positive := 4;
        round : positive := 1;
        set : positive := 1
    );
    port (
        clk: in std_logic;
        reset: in std_logic;
        sig_ready : in std_logic;
        done : in std_logic;

        sk : in  std_logic_vector(16*nibble-1 downto 0);
        msg : in  std_logic_vector(16*nibble-1 downto 0); 
        signature_i : in std_logic_vector(16*nibble-1 downto 0);
        msg_bytes : in std_logic_vector(2*w-1 downto 0);
        
        sk_input_valid : in std_logic;
        msg_input_valid : in std_logic;
        sig_input_valid : in std_logic;
        sk_input_ready : out std_logic;
        msg_input_ready : out std_logic;
        sig_input_ready : out std_logic;
        signature : out std_logic_vector(16*nibble-1 downto 0);
        valid : out std_logic;

        esk_calc : in std_logic;
        esk_vcalc : in std_logic;
        m_init_calc : in std_logic;
        a_init_calc : in std_logic;
        qa_calc : in std_logic;
        cfl_calc : in std_logic;
        solution_calc : in std_logic;
        sig_calc : in std_logic;
        sig_dec_calc : in std_logic;
        t_calc : in std_logic;
        t_decode_calc : out std_logic;
        rref_reset : in std_logic;
        seq_input : in std_logic:= '0';

        Lc : in std_logic;
        Li : in std_logic;
        Lr : in std_logic;
        Ec : in std_logic;
        Ei : in std_logic;
        Er : in std_logic;
        wr_perm : in std_logic;
        rd_en : in std_logic;
        reg_load : in std_logic;

        t_done : out std_logic;
        cfl_done : out std_logic;
        store_done : out std_logic;
        init_done : out std_logic;
        qa_done : out std_logic;
        rref_done : out std_logic;
        solution_done : out std_logic;
        sig_done : out std_logic;
        sig_dec_done : out std_logic;
        solution_valid : out std_logic;

        verify : in std_logic;
        signing : in std_logic;

        zc: out std_logic;
        zi: out std_logic;
        zr: out std_logic
    );
end mayo_datapath;

architecture structural of mayo_datapath is

    constant P : mayo_params_t := get_mayo_params(round, set);

    constant param_m : positive := P.m;
    constant param_n : positive := P.n;
    constant param_o : positive := P.o;
    constant param_k : positive := P.k;
    constant param_d : positive := P.n - P.o;
    constant pk_seed_bytes : positive := P.pk_seed_bytes;
    constant salt_bytes : positive := P.salt_bytes;
    constant digest_bytes : positive := P.digest_bytes;
    constant r_bytes : positive := (param_k*param_o)/2;

    constant parallel_factor : positive := w;
    constant sha_bits: positive := w*w;
    constant salt_words: positive := salt_bytes/w; -- 1 word = 8 bytes (64 bits)
    constant digest_words: positive := digest_bytes/w;
    constant pk_seed_words: positive := pk_seed_bytes/w;
    constant rref_cols : integer := param_o*param_k+1;
    constant rref_rows : integer := is_power_of_2(param_m);
    constant NUM_GROUPS : integer := ceil_div(param_m, parallel_factor);

    constant digest_mem_depth : positive := digest_words + salt_words + salt_words + pk_seed_words;
    constant rref_mem_chunks : integer := ceil_div(param_k*param_o+1,5);
    constant rref_mem_depth : integer := ((param_m + 4) / 5) * 5;
    constant sig_locs : positive := (param_n*param_k + 2*salt_bytes + 15) / 16;

    constant a_addr_width : positive := clog2(param_o); -- k * o
    constant digest_addr_width : positive := clog2(digest_mem_depth);
    constant rref_mem_addr_width : positive := clog2(rref_mem_depth);
    constant rref_addr_width : positive := rref_mem_chunks*rref_mem_addr_width;
    
    signal ctr: unsigned(w-1 downto 0);
    signal i: unsigned(clog2(sig_locs)-1 downto 0);
    signal rref_idx: unsigned(clog2(rref_cols)-1 downto 0);

    signal seed_done, t_run: std_logic;
    signal t_decode_calc_i : std_logic;

    signal reg_wr, seed_wr, salt_wr, sig_salt_wr: std_logic;
    signal a_wr, mem_init1, mem_init2 : std_logic;
    signal v_wr, pv_wr, lv_wr, l_wr, mem_wr, sv_wr, s_wr : std_logic;
    signal pv_load, lv_load, pv_mem_load, m_mode, l_mode, po_mode, duo, a_decode : std_logic;
    signal a_reduce, a_reduce_calc, a_reduce_done : std_logic;
    signal o_wr : std_logic_vector(param_o-1 downto 0);
    signal vr_calc, vr_done : std_logic;

    signal cfl_out_valid, cfl_load, cfl_extra, cfl_out_valid_d, cfl_done_i : std_logic;
    signal cfl_grp : std_logic_vector(clog2(NUM_GROUPS)-1 downto 0);
    signal cfl_idx : std_logic_vector(clog2(parallel_factor)-1 downto 0);

    signal salt_read_addr: std_logic_vector(digest_addr_width-1 downto 0);
    signal salt_read_data: std_logic_vector(sha_bits-1 downto 0);
    signal salt_wr_addr, sig_salt_wr_addr: std_logic_vector(digest_addr_width-1 downto 0);
    signal salt_wr_data, sig_salt_wr_data: std_logic_vector(sha_bits-1 downto 0);
    signal seed_wr_addr, seed_rd_addr: std_logic_vector(digest_addr_width-1 downto 0);
    signal seed_wr_data: std_logic_vector(sha_bits-1 downto 0);
    signal reg_wr_addr: std_logic_vector(digest_addr_width-1 downto 0);
    signal reg_wr_data: std_logic_vector(sha_bits-1 downto 0);
    signal v_wr_addr, sv_wr_addr, v_addr, sig_v_addr, qa_v_addr, s_addr : std_logic_vector(nibble-1 downto 0);
    signal v_wr_data, v_out, o_reg : std_logic_vector(param_d*nibble-1 downto 0);    
    signal sv_wr_data, s_data : std_logic_vector(param_n*nibble-1 downto 0);
    signal mem_ram_addr: std_logic_vector(clog2(param_n)-1 downto 0);
    signal pv_col_idx, pv_row_idx, p3_col_idx, p3_row_idx, mem_init_addr: std_logic_vector(clog2(param_n)-1 downto 0);
    signal o_addr: std_logic_vector(clog2(param_o)-1 downto 0);
    signal a_addr, qa_a_addr, cfl_a_addr : std_logic_vector(a_addr_width-1 downto 0);
    signal clf_m_addr : std_logic_vector(clog2(param_k*param_o)-1 downto 0);
    signal u_reg : std_logic_vector((param_m + param_k - 1)*nibble - 1 downto 0);
    signal a_row_end_data, y_chunk, a_chunk: std_logic_vector(nibble-1 downto 0);
    signal r_reg, r_reg_rev, a_row_data: std_logic_vector(r_bytes*w-1 downto 0);
    signal t_reg, y_temp, p_reg, p3_reg :  std_logic_vector(param_m*nibble-1 downto 0);
    signal y_reg : std_logic_vector(rref_rows*nibble-1 downto 0);
    signal salt_reg: std_logic_vector(salt_bytes*w-1 downto 0);
    signal x_reg : std_logic_vector(param_k*param_o*nibble-1 downto 0);
    signal s_reg : std_logic_vector(16*nibble-1 downto 0);
    signal o_in : std_logic_vector(nibble-1 downto 0);

    signal sha_src_ready: std_logic; 
    signal sha_src_read: std_logic;
    signal sha_dst_write: std_logic;
    signal sha_dst_ready: std_logic;
    signal sha_din: std_logic_vector(sha_bits-1 downto 0);
    signal sha_dout: std_logic_vector(sha_bits-1 downto 0);
    signal vr_sha_src_ready, t_sha_src_ready, esk_sha_src_ready : std_logic;
    signal vr_sha_dst_ready, t_sha_dst_ready, esk_sha_dst_ready : std_logic;
    signal vr_sha_din, t_sha_din, esk_sha_din : std_logic_vector(sha_bits-1 downto 0);
    signal vr_salt_read_addr, t_salt_read_addr : std_logic_vector(digest_addr_width-1 downto 0);

    signal rref_we : std_logic_vector((param_k*param_o+1)-1 downto 0);
    signal rref_data_i : std_logic_vector(((param_k*param_o+1)*nibble)-1 downto 0);
    signal rref_data_i_d : std_logic_vector(((param_k*param_o+1)*nibble)-1 downto 0);
    signal rref_row_rd_addr : std_logic_vector(rref_mem_addr_width-1 downto 0);
    signal rref_rd_addr : std_logic_vector(rref_addr_width-1 downto 0);
    signal rref_data_o : std_logic_vector(((param_k*param_o+1)*nibble)-1 downto 0);
    signal rref_col_tbl_we, rref_rd_en : std_logic;
    signal rref_done_i : std_logic;
    signal pivot_col_list_raw : std_logic_vector(rref_cols-1 downto 0);
    signal pivot_col_list_reg : std_logic_vector(rref_cols-1 downto 0);

    signal rref_rst : std_logic;
    attribute MAX_FANOUT : integer;
    attribute MAX_FANOUT of rref_rst : signal is 256;

begin

    rref_rst <= reset or rref_reset;

    salt_read_addr <= t_salt_read_addr when t_run = '1' else vr_salt_read_addr when vr_calc = '1' else seed_rd_addr;

    -- reg store signals
    reg_wr_addr <= salt_wr_addr when t_run = '1' else seed_wr_addr when signing='1' else sig_salt_wr_addr;
    reg_wr_data <= salt_wr_data when t_run = '1' else seed_wr_data when signing='1' else sig_salt_wr_data;
    reg_wr <= salt_wr when t_run = '1' else seed_wr when signing='1' else sig_salt_wr;
    rref_col_tbl_we <= wr_perm;

    -- vr signals
    v_addr <= qa_v_addr when qa_calc = '1' else sig_v_addr;
    t_decode_calc_i <= (seed_done and (not seq_input)) or t_calc;
    t_decode_calc <= t_decode_calc_i;

    sv_wr_data <= s_data when verify = '1' else v_wr_data & (param_o*nibble-1 downto 0 => '0');
    sv_wr_addr <= s_addr when verify = '1' else v_wr_addr;
    sv_wr <= s_wr when verify = '1' else v_wr;

    --ma signals
    a_addr <= cfl_a_addr when cfl_calc = '1' else qa_a_addr;

    -- sha256 signals
    sha_src_ready <= t_sha_src_ready and vr_sha_src_ready and esk_sha_src_ready;
    sha_dst_ready <= t_sha_dst_ready and vr_sha_dst_ready and esk_sha_dst_ready;
    sha_din <= vr_sha_din when vr_calc = '1' else t_sha_din when t_run = '1' else esk_sha_din;

    y_chunk <= y_reg((to_integer(unsigned(clf_m_addr))+1)*nibble-1 downto (to_integer(unsigned(clf_m_addr))*nibble));
    
    gen_n64: if param_m=64 or param_m=128 generate
        y_reg <= y_temp & (y_reg'length - y_temp'length-1 downto 0 => '0');   
        a_chunk <= (others=>'0') when unsigned(clf_m_addr)=0 else (a_row_end_data xor y_chunk);
    end generate;
    gen_64: if param_m/=64 and param_m/=128 generate
        y_reg <= y_temp;
        a_chunk <= (a_row_end_data xor y_chunk);
    end generate;

    process(clk)
    begin
        if rising_edge(clk) then
            if reset = '1' then
                rref_data_i_d <= (others => '0');
                cfl_out_valid_d <= '0';
                cfl_done <= '0';
            else
                rref_data_i_d <= a_chunk & a_row_data;
                cfl_out_valid_d <= cfl_out_valid;
                cfl_done <= cfl_done_i;
            end if;
        end if;
    end process;
    
    rref_data_i <= rref_data_i_d; -- [ A | y-A*r]
    rref_we <= (others => cfl_out_valid_d);
    rref_rd_en <= rd_en;
    rref_done <= rref_done_i;

    zc <= '1' when ctr = to_unsigned(255, w) else '0';
    zi <= '1' when i = to_unsigned(sig_locs-1, clog2(sig_locs)) else '0';
    zr <= '1' when rref_idx = to_unsigned(rref_cols-1, clog2(rref_cols)) else '0';

    -- Instantiate Keccak for SHAKE-256
    shake_256_inst : entity work.keccak_top
        port map (
            clk        => clk,
            rst        => reset,
            src_ready  => sha_src_ready,
            src_read   => sha_src_read,
            dst_ready  => sha_dst_ready,
            dst_write  => sha_dst_write,
            din        => sha_din,
            dout       => sha_dout
        );

    repeat_rref_addr_inst : entity work.repeat_bus
        generic map(
            SLICE_WIDTH => rref_mem_addr_width,
            REPEAT_COUNT => rref_mem_chunks
        )
        port map(
            din => rref_row_rd_addr,
            dout => rref_rd_addr
        );

    -- Instantiate RREF top module
    rref : entity work.rref_top(structural)
        generic map(
            N            => rref_cols,
            K            => rref_rows,
            Q            => 16,
            -- only the identity mapping is ever written to the column table
            -- (col_tbl_addr_i = col_tbl_data_i = rref_idx), so the permutation
            -- crossbar is hardwired off; set true to restore the table lookup
            USE_COL_PERM => false
        )
        port map(
            clk_i            => clk,
            rst_i            => rref_rst,
            vld_i            => cfl_out_valid_d,
            we_i             => rref_we,
            data_i           => rref_data_i,
            last_i           => cfl_out_valid_d,
            col_tbl_addr_i   => std_logic_vector(rref_idx),
            col_tbl_we_i     => rref_col_tbl_we,
            col_tbl_data_i   => std_logic_vector(rref_idx),
            rd_addr_i        => rref_rd_addr,
            rd_en_i          => rref_rd_en,
            data_o           => rref_data_o,
            done_o           => rref_done_i,
            pivot_col_list_o => pivot_col_list_raw
        );

    -- Instantiate ESK decode memory
    esk_decode: entity work.esk_decoder
        generic map (
            w => w,
            nibble => nibble,
            param_m => param_m,
            param_n => param_n,
            param_o => param_o,
            param_d => param_d,
            salt_bytes => salt_bytes,
            digest_bytes => digest_bytes,
            pk_seed_bytes => pk_seed_bytes,
            digest_addr_width => digest_addr_width
        )
        port map (
            clk => clk,
            reset => reset,
            calc => esk_calc,
            vcalc => esk_vcalc,
            verify => verify,
            pv_load => pv_load,
            lv_load => lv_load,
            pv_mem_load => pv_mem_load,
            pv_wr => pv_wr,
            lv_wr => lv_wr,
            o_wr => o_wr,
            mem_wr => mem_wr,
            l_wr => l_wr,
            m_mode => m_mode,
            l_mode => l_mode,
            po_mode => po_mode,
            sk => sk,
            seed_wr_data => seed_wr_data,
            seed_wr_addr => seed_wr_addr,
            seed_rd_addr => seed_rd_addr,
            seed_rd_data => salt_read_data,
            seed_wr => seed_wr,
            sha_src_read => sha_src_read,
            sha_src_ready => esk_sha_src_ready,
            sha_dst_ready => esk_sha_dst_ready,
            sha_dst_write => sha_dst_write,
            sha_din => esk_sha_din,
            sha_dout => sha_dout,
            p_data => p_reg,
            p3_data => p3_reg,
            o_data => o_in,
            col_idx => pv_col_idx,
            row_idx => pv_row_idx,
            p3_col_idx => p3_col_idx,
            p3_row_idx => p3_row_idx,
            sk_input_ready => sk_input_ready,
            sk_input_valid => sk_input_valid,
            vr_calc => vr_calc,
            vr_done => vr_done,
            t_done => t_done,
            seed_done => seed_done,
            done => store_done
        );

    -- Instantiate digest memory (M_digest, salt, seed_sk(csk) )
    register_bank : entity work.reg_store
        generic map (
            DATA_WIDTH => sha_bits,
            ADDR_WIDTH => digest_addr_width
        )
        port map (
            clk => clk,
            reset => reset,
            ld => reg_load,
            we => reg_wr,
            waddr => reg_wr_addr,
            wdata => reg_wr_data,
            raddr => salt_read_addr,
            rdata => salt_read_data
        );

    -- Instantiate T decode memory
    t_storage: entity work.t_decoder
        generic map (
            w => w,
            nibble => nibble,
            param_m => param_m,
            digest_bytes => digest_bytes,
            salt_bytes => salt_bytes,
            digest_addr_width => digest_addr_width
        )
        port map (
            clk => clk,
            reset => reset,
            calc => t_decode_calc_i,
            verify => verify,
            t_run => t_run,
            vector_input_ready => msg_input_ready,
            vector_input_valid => msg_input_valid,
            msg => msg,

            salt_read_addr => t_salt_read_addr,
            salt_read_data => salt_read_data,
            salt_wr => salt_wr,
            salt_wr_addr => salt_wr_addr,
            salt_wr_data => salt_wr_data,

            sha_src_read => sha_src_read,
            sha_src_ready => t_sha_src_ready,
            sha_dst_write => sha_dst_write,
            sha_dst_ready => t_sha_dst_ready,
            sha_din => t_sha_din,
            sha_dout => sha_dout,

            salt => salt_reg,
            target => t_reg,
            msg_bytes => msg_bytes,
            done => t_done
        );

    -- Instantiate sig decoder
    sig_decoder_inst : entity work.sig_decoder
        generic map (
            w => w,
            nibble => nibble,
            param_n => param_n,
            param_k => param_k,
            salt_bytes => salt_bytes,
            digest_bytes => digest_bytes,
            digest_addr_width => digest_addr_width
        )
        port map (
            clk => clk,
            reset => reset,
            calc => sig_dec_calc,
            vector_input_ready => sig_input_ready,
            vector_input_valid => sig_input_valid,
            vector_input => signature_i,
            s_data => s_data,
            s_addr => s_addr,
            s_wr => s_wr,
            salt_wr_data => sig_salt_wr_data,
            salt_wr_addr => sig_salt_wr_addr,
            salt_wr => sig_salt_wr,
            done => sig_dec_done
        );

    -- Instantiate VR expand memory
    vr_expand_inst : entity work.vr_expand
        generic map (
            w           => w,
            nibble      => nibble,
            param_n     => param_n,
            param_o     => param_o,
            param_k     => param_k,
            digest_bytes=> digest_bytes,
            salt_bytes  => salt_bytes,
            digest_addr_width => digest_addr_width
        )
        port map (
            clk             => clk,
            reset           => reset,
            calc            => vr_calc,
            wr              => v_wr,
            v_addr          => v_wr_addr,
            v_out           => v_wr_data,
            r_out           => r_reg,
            sha_src_ready   => vr_sha_src_ready,
            sha_src_read    => sha_src_read,
            sha_dst_ready   => vr_sha_dst_ready,
            sha_dst_write   => sha_dst_write,
            sha_din         => vr_sha_din,
            sha_dout        => sha_dout,
            salt_read_data  => salt_read_data,
            salt_read_addr  => vr_salt_read_addr,
            ctr             => std_logic_vector(ctr),
            done            => vr_done
        );

    -- Instantiate PV memory
    memory_bank : entity work.data_storage
        generic map(
            w => w,
            nibble => nibble,
            param_m => param_m,
            param_n => param_n,
            param_o => param_o,
            param_k => param_k,
            parallel_factor => parallel_factor,
            NUM_GROUPS => NUM_GROUPS
        )
        port map(
            clk => clk,
            reset => reset,
            calc => esk_calc,
            signing => signing,

            v_wr => sv_wr,
            v_in => sv_wr_data,
            v_out => v_out,
            v_wr_addr => sv_wr_addr,
            v_addr => v_addr,

            o_in => o_in,
            o_out => o_reg,
            o_addr => o_addr,
            o_wr => o_wr,
            
            a_addr => a_addr,
            a_wr => a_wr,
            a_reduce => a_reduce,
            a_reduce_calc => a_reduce_calc,
            a_reduce_done => a_reduce_done,
            a_cfl => cfl_calc,

            cfl_load => cfl_load,
            cfl_grp => cfl_grp,
            cfl_idx => cfl_idx,
            cfl_extra => cfl_extra,

            mem_init_addr => mem_init_addr,
            m_mem_init => mem_init1,
            a_mem_init => mem_init2,

            m_mode => m_mode,
            l_mode => l_mode,
            pv_load => pv_load,
            lv_load => lv_load,
            pv_mem_load => pv_mem_load,
            pv_wr => pv_wr,
            lv_wr => lv_wr,
            mem_wr => mem_wr,
            l_wr => l_wr,
            duo => duo,
            po_mode => po_mode,
            a_decode => a_decode,

            input_data => p_reg,
            input_data2 => p3_reg,
            col_idx => pv_col_idx,
            row_idx => pv_row_idx,
            col_idx2 => p3_col_idx,
            row_idx2 => p3_row_idx,
            pv_addr => mem_ram_addr,

            u_out => u_reg,
            cfl_out => a_row_data
        );

    -- Instantiate MA decode memory
    init_mem: entity work.init_memory
        generic map (
            w => w,
            nibble => nibble,
            param_n => param_n,
            param_o => param_o,
            param_k => param_k
        )
        port map (
            clk => clk,
            reset => reset,
            calc1 => m_init_calc,
            calc2 => a_init_calc,
            done => init_done,

            mem_init1 => mem_init1,
            mem_init2 => mem_init2,
            mem_addr => mem_init_addr
        );

    -- Instantiate quad accumulator
    quad_accum_inst : entity work.quad_accumulator
        generic map (
            w => w,
            nibble => nibble,
            param_m => param_m,
            param_n => param_n,
            param_o => param_o,
            param_k => param_k
        )
        port map (
            clk => clk,
            reset => reset,
            calc => qa_calc,
            done => qa_done,
            verify => verify,
            duo => duo,
            a_decode => a_decode,
            a_reduce => a_reduce,
            a_reduce_calc => a_reduce_calc,
            a_reduce_done => a_reduce_done,
            
            u_data => u_reg,

            v_addr => qa_v_addr,
            mem_ram_addr => mem_ram_addr,
            
            wra => a_wr,
            a_addr => qa_a_addr,
            
            target => t_reg,
            y => y_temp
        );

    -- Instantiate column FIFO loader ( m -> ko )
    column_loader_inst : entity work.column_fifo_loader
        generic map (
            nibble => nibble,
            param_o => param_o,
            param_k => param_k,
            param_m => param_m,
            addr_width => a_addr_width,
            rows => rref_rows,
            parallel_factor => parallel_factor,
            NUM_GROUPS => NUM_GROUPS
        )
        port map (
            clk => clk,
            reset => reset,
            calc => cfl_calc,
            done => cfl_done_i,
            addr_out => cfl_a_addr,
            a_addr_out => clf_m_addr,
            cfl_load => cfl_load,
            extra => cfl_extra,
            cfl_grp => cfl_grp,
            cfl_idx => cfl_idx,
            out_valid => cfl_out_valid
        );

    -- Instantiate sample_solution to get solution x
    sample_solution_inst : entity work.sample_solution
        generic map(
            nibble => nibble,
            w => w,
            param_k => param_k,
            param_o => param_o,
            param_m => param_m,
            addr_width => rref_mem_addr_width
        )
        port map(
            clk => clk,
            reset => reset,
            calc => solution_calc,
            done => solution_done,
            valid => solution_valid,
            addr_out => rref_row_rd_addr,
            data_in => rref_data_o(rref_cols*nibble-1 downto (rref_cols-1)*nibble),
            pivot_col_list => pivot_col_list_reg(rref_cols-2 downto 0),
            r => r_reg,
            x => x_reg
        );

    -- reverse nibble order of r_reg for downstream use
    rreg_reverse_inst : entity work.reverse_reg
        generic map(
            nibble => nibble,
            nibble_count => param_k*param_o
        )
        port map(
            din => r_reg,
            dout => r_reg_rev
        );

    -- Instantiate partial multiplier ( ko x ko ) to get A*r
    partial_mul_inst1: entity work.partial_arr_mul_gf16
        generic map(n=>param_k*param_o)
        port map(
            a => r_reg_rev,
            s => a_row_data,
            result => a_row_end_data
        );

    -- Instantiate signature generation module
    sig_gen_inst : entity work.sig_gen(lutram)
        generic map(
            w => w,
            nibble => nibble,
            param_n => param_n,
            param_o => param_o,
            param_k => param_k,
            salt_bytes => salt_bytes,
            WR_NIBBLES => 16
        )
        port map(
            clk => clk,
            reset => reset,
            calc => sig_calc,
            done => sig_done,
            o_addr => o_addr,
            o_data => o_reg,
            x_data => x_reg,
            v_addr => sig_v_addr,
            v_data => v_out,
            salt => salt_reg,
            sig_addr => std_logic_vector(i),
            sig_data => s_reg
        );

    -- ctr Counter -> (0 to 255)
    counterCTR : process(clk)
    begin
        if rising_edge(clk) then
            if Lc = '1' then
                ctr <= (others => '0');
            elsif Ec = '1' then
                ctr <= ctr + 1;
            end if;    
        end if;
    end process;

    -- i Counter -> (0 to param_k-1)
    counterI : process(clk)
    begin
        if rising_edge(clk) then
            if Li = '1' then
                i <= (others => '0');
            elsif Ei = '1' then
                i <= i + 1;
            end if;    
        end if;
    end process;

    -- rref idx Counter -> (0 to rref_cols-1)
    counterRREF : process(clk)
    begin
        if rising_edge(clk) then
            if Lr = '1' then
                rref_idx <= (others => '0');
            elsif Er = '1' then
                rref_idx <= rref_idx + 1;
            end if;    
        end if;
    end process;

    -- pivot column list
    process(clk)
    begin
        if rising_edge(clk) then
            if rref_reset = '1' then
                pivot_col_list_reg <= (others => '0');
            elsif (rref_done_i = '1') then
                pivot_col_list_reg <= pivot_col_list_raw;
            end if;
        end if;
    end process;

    signature <= s_reg when (done = '1' and signing = '1') else (others => '0');
    valid <= '1' when (done = '1' and y_temp = t_reg and verify = '1') else '0';
   
end structural;
