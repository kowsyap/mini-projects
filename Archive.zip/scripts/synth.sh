#!/usr/bin/env bash

NTFY_TOPIC="mayo-synth-done"
DESIGN="mayo.toml"
XEDAPROJECT="xedaproject.toml"
FLOW="vivado_synth"

TYPE=synth
ROUND=1
SET=2
FREQ=100
FREQ_LOW=50
FREQ_HIGH=125
WORKERS=4
PART=""

usage() {
    echo "Usage: $0 [--type synth|dse] [--round 1|2] [--set 1|2|3|5] [--freq <MHz>] [--freq-low <MHz>] [--freq-high <MHz>] [--workers <n>] [--part <fpga-part>]"
    exit 1
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --type)      TYPE="$2";      shift 2 ;;
        --round)     ROUND="$2";     shift 2 ;;
        --set)       SET="$2";       shift 2 ;;
        --freq)      FREQ="$2";      shift 2 ;;
        --freq-low)  FREQ_LOW="$2";  shift 2 ;;
        --freq-high) FREQ_HIGH="$2"; shift 2 ;;
        --workers)   WORKERS="$2";   shift 2 ;;
        --part)      PART="$2";      shift 2 ;;
        *) usage ;;
    esac
done

cd "$(dirname "$0")/.."

# override fpga.part in both toml files if --part was given
if [ -n "$PART" ]; then
    python3 - <<EOF
import re
for path in ["$DESIGN", "$XEDAPROJECT"]:
    with open(path) as f:
        content = f.read()
    content = re.sub(r'fpga\.part\s*=\s*"[^"]*"', 'fpga.part = "$PART"', content)
    with open(path, "w") as f:
        f.write(content)
EOF
fi

# update parameters in mayo.toml
python3 - <<EOF
import re
with open("$DESIGN") as f:
    content = f.read()
content = re.sub(
    r'parameters\s*=\s*\{[^}]*\}',
    'parameters = {round = $ROUND, set = $SET}',
    content
)
with open("$DESIGN", "w") as f:
    f.write(content)
EOF

source /shared/bash_64_vivado20242.sh

if [ "$TYPE" = "dse" ]; then
    xeda dse --design "$DESIGN" --xedaproject "$XEDAPROJECT" \
        --init_freq_low "$FREQ_LOW" --init_freq_high "$FREQ_HIGH" \
        --max-workers "$WORKERS" "$FLOW"
    STATUS=$?
    INFO="round=$ROUND set=$SET freq=${FREQ_LOW}-${FREQ_HIGH}MHz workers=$WORKERS${PART:+ part=$PART}"
else
    xeda run "$FLOW" "$DESIGN" \
        -s clocks.main_clock.freq="$FREQ"
    STATUS=$?
    INFO="round=$ROUND set=$SET freq=${FREQ}MHz${PART:+ part=$PART}"
fi

if [ $STATUS -eq 0 ]; then
    curl -s -H "Title: Vivado" -d "Synthesis DONE ✓ ($INFO)" "https://ntfy.sh/$NTFY_TOPIC"
else
    curl -s -H "Title: Vivado" -d "Synthesis FAILED ✗ ($INFO)" "https://ntfy.sh/$NTFY_TOPIC"
fi

exit $STATUS
