#!/usr/bin/env bash

PID_FILE="$(dirname "$0")/../logs/synth.pid"

if [ ! -f "$PID_FILE" ]; then
    echo "No synth.pid found — nothing to kill."
    exit 1
fi

PID=$(cat "$PID_FILE")

if ! kill -0 "$PID" 2>/dev/null; then
    echo "PID $PID is not running."
    rm -f "$PID_FILE"
    exit 1
fi

# kill the whole process group so Vivado children die too
kill -- -$(ps -o pgid= -p "$PID" | tr -d ' ')
echo "Killed synthesis (PID $PID) and its children."
rm -f "$PID_FILE"

curl -s -H "Title: Vivado" -d "Synthesis KILLED ✋" "https://ntfy.sh/mayo-synth-done"
