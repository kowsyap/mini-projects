#!/usr/bin/env bash

TRIGGER_TOPIC="mayo-synth-trigger2"
SCRIPT_DIR="$(dirname "$0")"
LOG_DIR="$SCRIPT_DIR/../logs"
LISTENER_LOG="$LOG_DIR/listener.log"

mkdir -p "$LOG_DIR"

echo "Listening for trigger on https://ntfy.sh/$TRIGGER_TOPIC ..."

curl -s --no-buffer "https://ntfy.sh/${TRIGGER_TOPIC}/json" | while read -r event; do
    # only handle actual messages, skip open/keepalive events
    EVENT_TYPE=$(echo "$event" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('event',''))" 2>/dev/null)
    [ "$EVENT_TYPE" != "message" ] && continue

    # extract cmd and args from message (handles nested JSON from iOS shortcut)
    read CMD ARGS <<< $(echo "$event" | python3 -c "
import sys, json
d = json.load(sys.stdin)
msg = d.get('message', '')
args = []
try:
    inner = json.loads(msg)
    msg = inner.get('message', msg)
    if inner.get('type'):      args += ['--type',      str(inner['type'])]
    if inner.get('freq'):      args += ['--freq',      str(inner['freq'])]
    if inner.get('round'):     args += ['--round',     str(inner['round'])]
    if inner.get('set'):       args += ['--set',       str(inner['set'])]
    if inner.get('freq_low'):  args += ['--freq-low',  str(inner['freq_low'])]
    if inner.get('freq_high'): args += ['--freq-high', str(inner['freq_high'])]
    if inner.get('workers'):   args += ['--workers',   str(inner['workers'])]
    if inner.get('part'):      args += ['--part',      str(inner['part'])]
except Exception:
    pass
print(msg.strip().lower(), ' '.join(args))
" 2>/dev/null)

    case "$CMD" in
        go*)
            SYNTH_LOG="$LOG_DIR/synth_$(date +%Y%m%d_%H%M%S).log"
            echo "GO received -> running synth.sh $ARGS (log: $SYNTH_LOG)"
            setsid bash "$SCRIPT_DIR/synth.sh" $ARGS > "$SYNTH_LOG" 2>&1 &
            echo $! > "$LOG_DIR/synth.pid"
            echo "PID: $!"
            ;;
        kill)
            echo "KILL received -> running synth_kill.sh"
            bash "$SCRIPT_DIR/synth_kill.sh"
            ;;
        *)
            echo "Ignoring unknown message: '$MSG'"
            ;;
    esac
done
