library ieee;
use ieee.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;

use work.util_pkg.all;
use work.mayo_pkg.all;

entity vr_expand is
    generic (
        w : positive := 8;
        nibble : positive := 4;
        param_n : positive := 66;
        param_o : positive := 8;
        param_k : positive := 9;
        param_d : positive := param_n-param_o;
        v_bytes : positive := ceil_div(param_d, 2);
        r_bytes : positive := (param_k*param_o)/2;
        sha_bits : positive := w*w;
        digest_bytes : positive := 32;
        salt_bytes : positive := 24;
        digest_addr_width : positive := 5
    );
    port (
        clk : in std_logic;
        reset : in std_logic;
        calc : in std_logic;

        wr : out std_logic;
        v_addr : out std_logic_vector(nibble-1 downto 0);
        v_out : out std_logic_vector(param_d*nibble-1 downto 0);
        
        r_out : out std_logic_vector(r_bytes*w-1 downto 0);

        sha_src_ready : out std_logic;
        sha_src_read : in std_logic;
        sha_dst_ready : out std_logic;
        sha_dst_write : in std_logic;
        sha_din : out std_logic_vector(sha_bits-1 downto 0);
        sha_dout : in std_logic_vector(sha_bits-1 downto 0);

        salt_read_data : in std_logic_vector(sha_bits-1 downto 0);
        salt_read_addr : out std_logic_vector(digest_addr_width-1 downto 0);

        ctr : in std_logic_vector(w-1 downto 0);
        done : out std_logic
    );
end vr_expand;

architecture rtl of vr_expand is

    constant salt_words: integer := salt_bytes/w;
    constant digest_words: integer := digest_bytes/w;
    constant nibble_count : positive := 16; 
    constant word_count : positive := ceil_div(2*v_bytes, nibble_count); -- 78/16 = 5  -- 64/16 =4 -- 108/16=7 -- 142/16=9 -- 58/16=4 -- 60/16=4 -- 89/16=6 -- 121/16=8
    constant r_word_count : positive := ceil_div(2*r_bytes, nibble_count); -- 80/16=5 -- 68/16=5 -- 110/16=7 -- 144/16=9 -- 72/16=5 -- 72/16=5 -- 110/16=7 -- 144/16=9
    constant word_count_mismatch : integer := boolean'pos(word_count /= r_word_count);
    constant not_param_d_64 : integer := boolean'pos(param_d /= 64);
    constant x_width : integer := calc_width16(2*v_bytes);  -- 78->3, 64->2, 108->2, 142->3, 58->3, 60->3, 89->4, 121->4

    constant final_out_size : positive := (word_count + not_param_d_64 + word_count_mismatch) * w * w; -- for 78=6*8*8=384, for 64=5*8*8=320, for 108=8*8*8=512, for 142=10*8*8=640

    constant shift_rom : shift_rom16_type(0 to 2**x_width-1) := get_shift_rom16(2*v_bytes, x_width);
    constant load_rom : shift_rom16_type(0 to 2**x_width-1) := get_load_rom16(2*v_bytes, word_count, x_width);

    constant mode_val : unsigned(3 downto 0) := to_unsigned(14, 4);

    signal command_word : std_logic_vector(sha_bits-1 downto 0);
    signal fifo_reg, shifted_fifo: std_logic_vector(final_out_size-1 downto 0);
    signal partial_decoded_vector: std_logic_vector(sha_bits-1 downto 0);
    signal fifo_in: std_logic_vector(sha_bits-1 downto 0);
    signal r_temp: std_logic_vector(r_bytes*w-1 downto 0);
    signal r_reg: std_logic_vector(r_bytes*w-1 downto 0);
    signal decoded_vector : std_logic_vector(param_d*nibble-1 downto 0);
    signal ctr64 : std_logic_vector(63 downto 0);

    type state_type is (IDLE, LOADCMD, LOADMSG, LOADCTR, WORDREAD, WAITER, RWRITE, OK);
    signal state, next_state : state_type;

    signal k, expected_k_limit: unsigned(nibble - 1 downto 0);
    signal s: unsigned(digest_addr_width - 1 downto 0);
    signal x : unsigned(x_width-1 downto 0);

    signal Lc, Lctr, Li, Ei, Ls, Es, Lx, Ex, Lk, Ek, Lo, Eo, zs, zk, zo, zi, wr_r, ld_r : std_logic;

    signal output_bits : unsigned(27 downto 0);
    signal output_words, o  : unsigned(6 downto 0);
    signal input_bits  : unsigned(31 downto 0);

    signal i : unsigned(nibble-1 downto 0);

begin
    
    output_bits <= to_unsigned(((param_k*v_bytes)+r_bytes)*w, 28);
    output_words <= to_unsigned(ceil_div((param_k*v_bytes)+r_bytes,w), 7);
    input_bits  <= to_unsigned((digest_bytes+salt_bytes+salt_bytes+1)*w, 32);
    command_word <= std_logic_vector(mode_val & output_bits & input_bits);

    salt_read_addr <= std_logic_vector(s);
    ctr64 <= ctr & (55 downto 0 => '0');
    sha_din <= command_word when Lc = '1' else ctr64 when Lctr='1' else salt_read_data;

    fifo_in <= partial_decoded_vector when sha_dst_write='1' else (others => '0'); 

    zs <= '1' when s = to_unsigned(digest_words+salt_words+salt_words-1, s'length) else '0';
    zk <= '1' when k = expected_k_limit-1 else '0';
    zo <= '1' when o = output_words-1 else '0';
    zi <= '1' when i = to_unsigned(param_k,i'length) else '0';

    gen_v_64 : if param_d = 64 generate
    begin
        expected_k_limit <= to_unsigned(word_count, nibble);
        decoded_vector <= fifo_reg(param_d*nibble-1 downto 0);
        r_temp <= fifo_reg(final_out_size-1 downto final_out_size-r_bytes*w);
    end generate;

    gen_v_not_64_r2 : if param_d /= 64 and word_count_mismatch = 0 generate
    begin
        shifted_fifo <= std_logic_vector(shift_left(unsigned(fifo_reg), nibble*shift_rom(to_integer(x))));
        expected_k_limit <= to_unsigned(word_count, nibble) when (i = 0 and x = 0) else  to_unsigned(load_rom(to_integer(x)), nibble);
        decoded_vector <= shifted_fifo(final_out_size-1 downto final_out_size-param_d*nibble);
        r_temp <= shifted_fifo(final_out_size-1 downto final_out_size-r_bytes*w);
    end generate;

    gen_v_not_64_r1 : if param_d /= 64 and word_count_mismatch = 1 generate
    begin
        shifted_fifo <= std_logic_vector(shift_left(unsigned(fifo_reg), nibble*shift_rom(to_integer(x))));
        expected_k_limit <= to_unsigned(word_count, nibble) when (i = 0 and x = 0) else  to_unsigned(load_rom(to_integer(x)), nibble);
        decoded_vector <= shifted_fifo(final_out_size-nibble_count*nibble-1 downto final_out_size-nibble_count*nibble-param_d*nibble);
        r_temp <= shifted_fifo(final_out_size-1 downto final_out_size-r_bytes*w);
    end generate;

    decode_vector_inst: entity work.decode_vector
    generic map(
        nibble_count => nibble_count,
        nibble => nibble,
        reverse => false
    )
    port map(
        a => sha_dout,
        result => partial_decoded_vector
    );

    fifo_out_inst: entity work.SIPO_FIFO
        generic map(LEFT_SHIFT=>true,INPUT_WIDTH=>sha_bits,OUTPUT_WIDTH=>final_out_size)
        port map(
            clk => clk,
            reset => reset,
            serial_in => fifo_in,
            parallel_in => (others=>'0'),
            serial_out => open,
            load => sha_dst_write and calc,
            load_parallel => '0',
            parallel_out => fifo_reg 
        );

    counterS : process(clk)
    begin
        if rising_edge(clk) then
            if Ls = '1' then
                s <= (others=>'0');
            elsif Es = '1' then
                s <= s + 1;
            end if;
        end if;
    end process;

    counterX: process(clk)
    begin
        if rising_edge(clk) then
            if Lx = '1' then
                x <= (others => '0');
            elsif Ex = '1' then
                x <= x + 1;
            end if;
        end if;
    end process;

    counterK: process(clk)
    begin
        if rising_edge(clk) then
            if Lk = '1' then
                k <= (others => '0');
            elsif Ek = '1' then
                k <= k + 1;
            end if;
        end if;
    end process;

    counterO: process(clk)
    begin
        if rising_edge(clk) then
            if Lo = '1' then
                o <= (others => '0');
            elsif Eo = '1' then
                o <= o + 1;
            end if;
        end if;
    end process;

    counterI: process(clk)
    begin
        if rising_edge(clk) then
            if Li = '1' then
                i <= (others => '0');
            elsif Ei = '1' then
                i <= i + 1;
            end if;
        end if;
    end process;

    data_store_proc : process(clk)
        variable idx : integer;
    begin
        if rising_edge(clk) then
            if ld_r = '1' then
                r_reg <= (others => '0');
            elsif wr_r = '1' then
                r_reg <= r_temp;
            end if;
        end if;
    end process;
    
    fsm_proc : process(clk, reset)
    begin
        if reset = '1' then
            state <= IDLE;
        elsif rising_edge(clk) then
            state <= next_state;
        end if;
    end process;

    fsm_next : process(state, calc, sha_src_read, zs, zk, zo, zi, sha_dst_write)
    begin
        Ls <= '0';
        Es <= '0';
        Lx <= '0';
        Ex <= '0';
        Lk <= '0';
        Ek <= '0';
        Lc <= '0';
        Lctr <= '0';
        Li <= '0';
        Ei <= '0';
        Lo <= '0';
        Eo <= '0';
        wr <= '0';
        ld_r <= '0';
        wr_r <= '0';
        sha_src_ready <= '1';
        sha_dst_ready <= '1';
        done <= '0';
        next_state <= state;
        case state is
            when IDLE =>
                if calc = '1' then
                    Ls <= '1';
                    Lx <= '1';
                    Li <= '1';
                    Lk <= '1';
                    Lo <= '1';
                    ld_r <= '1';
                    next_state <= LOADCMD;
                else
                    next_state <= IDLE;
                end if;

            when LOADCMD =>
                Lc <= '1';
                sha_src_ready <= '0';
                next_state <= LOADMSG;

            when LOADMSG =>
                sha_src_ready <= '0';
                if sha_src_read = '1' then
                    if (zs = '1') then
                        next_state <= LOADCTR;
                    else
                        Es <= '1';
                        next_state <= LOADMSG;
                    end if;
                end if;

            when LOADCTR =>
                sha_src_ready <= '0';
                Lctr <= '1';
                if sha_src_read = '1' then
                    next_state <= WAITER;
                end if;
            
            when WAITER =>
                Ls <= '1';
                sha_dst_ready <= '0';
                if sha_dst_write = '1' then
                    next_state <= WORDREAD;
                else
                    next_state <= WAITER;
                end if;

            when WORDREAD =>
                sha_dst_ready <= '0';
                if zo = '1' then
                    next_state <= RWRITE;
                elsif sha_dst_write = '1' then
                    Eo <= '1';
                    if zk = '0' then
                        Ek <= '1';
                    elsif zi = '0' then
                        Lk <= '1';
                        Ex <= '1';
                        wr <= '1';
                        Ei <= '1';
                    end if;
                    next_state <= WORDREAD;
                end if;
            
            when RWRITE =>
                wr_r <= '1';
                next_state <= OK;

            when OK =>
                done <= '1';
                if( calc='0') then
                    next_state <= IDLE;
                end if;
        end case;
    end process;

    v_out <= decoded_vector;
    v_addr <= std_logic_vector(i) when i<to_unsigned(param_k,i'length) else (others=>'0');

    r_out <= r_reg;

end rtl;
