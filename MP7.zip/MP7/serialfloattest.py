import numpy as np
import random
import serial
import struct

ser = serial.Serial(
    port='COM8',
    baudrate=115200,
    parity=serial.PARITY_NONE,
    stopbits=serial.STOPBITS_ONE,
    bytesize=serial.EIGHTBITS
)

ser.isOpen()
ser.reset_input_buffer()

readbyte = 0
readstring = ""
rawbyte = ""
print("Waiting for synchronization")
while (rawbyte != b'\n'):
    rawbyte = ser.read(1)
    readbyte = rawbyte.decode("utf-8")
    readstring = readstring + readbyte

print(readstring)
ser.reset_input_buffer()

N = 1024
MAXRAND = 100.0
testarray = np.zeros(N*2, dtype=np.float32)

print("Initialization array")
for i in range(0, N):
    testarray[2*i]   = random.random()*MAXRAND - random.random()*MAXRAND
    testarray[2*i+1] = random.random()*MAXRAND - random.random()*MAXRAND
    print(testarray[2*i], testarray[2*i+1])

for i in range(0, N*2):
    newpack = struct.pack('f', testarray[i])
    ser.write(newpack)

print("Samples sent")
ser.reset_output_buffer()

receivearray = np.zeros(N, dtype=np.float32)
for i in range(0, N):
    receivepack = ser.read(4)
    data = struct.unpack('f', receivepack)
    receivearray[i] = float(list(data)[0])

ser.close()

print("Division results")
for i in range(0, N):
    hw_result = receivearray[i]
    sw_result = testarray[2*i] / testarray[2*i+1]
    print(hw_result, sw_result)
