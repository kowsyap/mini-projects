# serialtest.py
# This program illustrates basic serial function using Python pyserial class and Zybo UART

import numpy as np
import serial
import struct

# configure the serial connections (the parameters differs on the device you are connecting to)
ser = serial.Serial(
    port = 'COM8',
    baudrate=115200,
    parity=serial.PARITY_NONE,
    stopbits=serial.STOPBITS_ONE,
    bytesize=serial.EIGHTBITS
)

#initialize serial port
ser.isOpen()
ser.reset_input_buffer()

# wait for UART synchronization)
readbyte = 0
readstring = ""
rawbyte = ""
print("Waiting for synchronization")
while (rawbyte != b'\n'):
    rawbyte = ser.read(1)
    readbyte = rawbyte.decode("utf-8")
    readstring = readstring + readbyte
    
print(readstring)
ser.reset_input_buffer()

N = 16
testarray = np.zeros(N, dtype=int)

# initialize array

print("Initialization array")
for i in range(0, N):
    testarray[i] = i
    print(testarray[i])

# send samples to Zybo
for i in range(0, N): 
    newpack = struct.pack('h', testarray[i])
    #print(newpack)
    ser.write(newpack)

print("Samples sent")
ser.reset_output_buffer()

receivearray = np.zeros(N, dtype = int)

# Receive rotated results from Zybo
for i in range(0, N):
    #print("Receiving: " + str(i))
    receivepack = ser.read(2)   
    data = struct.unpack('h', receivepack)
    receivearray[i] = int(list(data)[0])

ser.close()

print("Received array")
for i in range(0, N):
    print(receivearray[i])
