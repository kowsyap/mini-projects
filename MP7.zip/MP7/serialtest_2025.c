//serialtest.c
//William Diehl 03272022
// Test sending data between Python and C using UART 

/***************************** Include Files *********************************/

#include "xparameters.h"
#include "xdebug.h"
#include "xuartps_hw.h"
#include "xuartps.h"

#ifdef XPAR_UARTNS550_0_BASEADDR
#include "xuartns550_l.h"       /* to use uartns550 */
#endif


/**************************** Type Definitions *******************************/


/***************** Macros (Inline Functions) Definitions *********************/


/************************** Function Prototypes ******************************/
#ifndef DEBUG
extern void xil_printf(const char *format, ...);
#endif

#ifdef XPAR_UARTNS550_0_BASEADDR
static void Uart550_Setup(void);
#endif


/************************** Variable Definitions *****************************/
/*
 * Device instance definitions
 */

static XUartPs myUart;


#define N 16 // # of test elements

short testarray[16];

int main(void)
{

	/* Initial setup for Uart16550 */
#ifdef XPAR_UARTNS550_0_BASEADDR

	Uart550_Setup();

#endif

	/* Uart synchronization */

	XUartPs_Config *myUartConfig;

	myUartConfig = XUartPs_LookupConfig(XPAR_UART1_BASEADDR);

	XUartPs_CfgInitialize(&myUart, myUartConfig, myUartConfig->BaseAddress);
	XUartPs_EnableUart(&myUart);

	char newchar;
    u8 testbuffer[18] = "UART Synchronized\n";
    u8 *tptr = &testbuffer;
    int index = 0;
    while (index < 18)
    	if (XUartPs_IsTransmitEmpty(&myUart)){
    		XUartPs_Send(&myUart, tptr+index, 1);
    		index++;
    	}

    /* Receive data over UART from PC */

    u8 *ReceivePtr = (u8*) testarray;

    for (int i = 0; i<N; i++)
    	for (int j = 0; j<2; j++)
    		*(ReceivePtr+2*i+j) = XUartPs_RecvByte(myUartConfig->BaseAddress);

	/* Manipulate Data */
	
	for (int i = 0; i<N; i++)
		testarray[i]+=2;

    /* Uart send to PC */

    u8 *SendPtr = (u8*) testarray;
    for (int i = 0; i<N; i++){
     	while (!XUartPs_IsTransmitEmpty(&myUart)) { }
       	XUartPs_Send(&myUart, SendPtr+2*i, 2);
    }

	return 0;
}

#ifdef XPAR_UARTNS550_0_BASEADDR
/*****************************************************************************/
/*
*
* Uart16550 setup routine, need to set baudrate to 9600 and data bits to 8
*
* @param	None
*
* @return	None
*
* @note		None.
*
******************************************************************************/
static void Uart550_Setup(void)
{

	XUartNs550_SetBaud(XPAR_UARTNS550_0_BASEADDR,
			XPAR_XUARTNS550_CLOCK_HZ, 9600);

	XUartNs550_SetLineControlReg(XPAR_UARTNS550_0_BASEADDR,
			XUN_LCR_8_DATA_BITS);
}
#endif
