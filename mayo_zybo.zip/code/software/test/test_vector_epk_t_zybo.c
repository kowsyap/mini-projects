/* test_vector_epk_t_zybo.c
 * Zybo Z7-10 version of test_vector_epk_t.c
 *
 * Computes T and EPK from hardcoded MAYO Round-1 Set-2 test vectors,
 * then prints T (32 bytes) and the first 64 bytes of EPK via xil_printf.
 * No file I/O, no dynamic allocation.
 */

#include "xil_printf.h"
#include "../mayo_verify_support.h"
#include "test_vectors_zybo.h"

/* How many bytes of EPK to print (full EPK is 98592 bytes) */
#define EPK_PRINT_BYTES 64

static unsigned char epk[MAYO_R1S2_epk_bytes];
static unsigned char t[MAYO_R1S2_m_bytes];

static void print_hex(const char *label, const unsigned char *buf, int len)
{
    int i;
    xil_printf("%s (%d bytes):\r\n", label, len);
    for (i = 0; i < len; i++) {
        xil_printf("%02X", buf[i]);
        if ((i + 1) % 16 == 0)
            xil_printf("\r\n");
    }
    if (len % 16 != 0)
        xil_printf("\r\n");
}

int main(void)
{
    int ret;

    xil_printf("\r\n=== MAYO R1 Set-2 Vector Test (Zybo) ===\r\n\r\n");

    /* --- Expand compact public key to full EPK --- */
    ret = mayo_expand_pk(&MAYO_R1_2, r1_cpk, epk);
    if (ret != 0) {
        xil_printf("ERROR: mayo_expand_pk failed (%d)\r\n", ret);
        return 1;
    }
    xil_printf("mayo_expand_pk: OK\r\n");

    /* --- Derive target vector T from msg + sig --- */
    ret = deriveT(&MAYO_R1_2, r1_msg, (unsigned long long)R1_MSG_LEN, r1_sig, t);
    if (ret != 0) {
        xil_printf("ERROR: deriveT failed (%d)\r\n", ret);
        return 1;
    }
    xil_printf("deriveT: OK\r\n\r\n");

    /* --- Print T (32 bytes) --- */
    print_hex("T", t, MAYO_R1S2_m_bytes);
    xil_printf("\r\n");

    /* --- Print first EPK_PRINT_BYTES bytes of EPK --- */
    xil_printf("EPK first %d bytes:\r\n", EPK_PRINT_BYTES);
    print_hex("EPK[0..63]", epk, EPK_PRINT_BYTES);

    xil_printf("\r\n=== Done ===\r\n");
    return 0;
}
