# Constraints for MAYO PQC core
# Device: xc7k480tffg901-2 (Kintex-7)
# Target: 125 MHz

# ---- Clock ----------------------------------------------------------------
create_clock -period 8.000 -name clk_i [get_ports clk_i]

# ---- Input delays ---------------------------------------------------------
# All inputs are driven by on-chip logic (no external IO timing required)
set_input_delay -clock clk_i 0.0 [get_ports {
    reset_i
    calc_i
    mode_i
    seq_i
    msg_bytes_i
    msg_data_i
    msg_valid_i
    sk_data_i
    sk_valid_i
    sig_verify_data_i
    sig_verify_valid_i
    sig_gen_ready_i
}]

# ---- Output delays --------------------------------------------------------
set_output_delay -clock clk_i 0.0 [get_ports {
    msg_ready_o
    sk_ready_o
    sig_verify_ready_o
    sig_gen_data_o
    sig_gen_valid_o
    sig_gen_last_o
    verify_ok_o
    done_o
    module_status_o
}]

# ---- Timing exceptions ----------------------------------------------------
# reset_i is asynchronous - no timing requirement
set_false_path -from [get_ports reset_i]
