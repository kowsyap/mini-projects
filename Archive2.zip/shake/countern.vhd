-- =====================================================================
-- Copyright © 2010-2012 by Cryptographic Engineering Research Group (CERG),
-- ECE Department, George Mason University
-- Fairfax, VA, U.S.A.
-- =====================================================================

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use ieee.std_logic_unsigned.all;
use work.sha3_pkg.all;

-- up counter

entity countern is
	generic ( 
		N 	: integer := 2;
		step	:integer  :=1
	);
	port ( 	  
		clk : in std_logic;
		rst : in std_logic;
	    load : in std_logic;
	    en : in std_logic; 
        output : out std_logic_vector(N-1 downto 0)
	);
end countern;

architecture countern of countern is
   signal temp 		: std_logic_vector(N-1 downto 0);
   signal value 	: std_logic_vector(N-1 downto 0);
   signal init_value 	: std_logic_vector(N-1 downto 0);

begin
	
	gen : process( clk )
	begin
		if rising_edge( clk ) then
			if ( rst = '1' ) then
				temp <= (others => '0');
			elsif (load = '1' ) then
				temp <= (others => '0');
			elsif ( en = '1' ) then
				temp <= temp + std_logic_vector(to_unsigned(step, N));
			end if;
		end if;
	end process;  

	output <= temp;
	
end countern;

