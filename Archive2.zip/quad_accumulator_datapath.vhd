library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use work.util_pkg.all;
use work.mayo_pkg.all;

entity quad_accumulator_datapath is
    generic (
        w          : positive := 8;
        nibble     : positive := 4;
        param_m    : positive := 78;
        param_n    : positive := 86;
        param_o    : positive := 8;
        param_k    : positive := 10;
        param_d    : positive := param_n - param_o;
        m_read_bits: positive := param_m*nibble;
        r_bytes    : positive := (param_k*param_o)/2;
        a_addr_width : positive := 7
    );
    port (
        clk     : in  std_logic;
        reset   : in  std_logic;
        verify   : in  std_logic;

        v_addr     : out std_logic_vector(nibble-1 downto 0);
        mem_ram_addr : out std_logic_vector(clog2(param_n)-1 downto 0);
        a_addr       : out std_logic_vector(a_addr_width-1 downto 0);
        u_data       : in std_logic_vector((param_m + param_k - 1)*nibble - 1 downto 0);
        target       : in  std_logic_vector(m_read_bits-1 downto 0);
        y            : out std_logic_vector(m_read_bits-1 downto 0);

        reduce_calc   : in  std_logic;
        arr      : in  std_logic;
        a_decode : in  std_logic;

        Ei      : in  std_logic;
        Ea      : in  std_logic;
        Eo      : in  std_logic;
        Ey      : in  std_logic;
        Li      : in  std_logic;
        La      : in  std_logic;
        Lo      : in  std_logic;
        Ly      : in  std_logic;
        Lt      : in  std_logic;
        
        zi    : out std_logic; 
        za    : out std_logic; 
        zo    : out std_logic; 
        reduce_done : out std_logic
    );
end quad_accumulator_datapath;

architecture rtl of quad_accumulator_datapath is

    constant U_ACC_NIBBLES : positive := param_m + (param_k * (param_k + 1)) / 2 - 1;
    constant U_ACC_WIDTH : positive := U_ACC_NIBBLES * nibble;
    constant U_ACC_LOW_BITS : natural := 2*m_read_bits - U_ACC_WIDTH;
    constant U_ACC_TARGET_ZERO_BITS : positive := U_ACC_WIDTH - m_read_bits;
    constant TRI_LUT : int_lut_t(0 to param_k-1) := make_tri_lut(param_k);

    signal i, i_d: unsigned(nibble-1 downto 0) := (others => '0');
    signal a, a_limit: unsigned (clog2(param_n)-1 downto 0);
    signal o: unsigned(clog2(param_o)-1 downto 0);

    signal reduce_dout, y_reg: std_logic_vector(m_read_bits-1 downto 0);
    signal y_long_reg, u_reg : std_logic_vector(U_ACC_WIDTH-1 downto 0);
    signal y_temp, y_temp_d : std_logic_vector(U_ACC_WIDTH-1 downto 0);
    signal arr_d, arr_d2, arr_d3 : std_logic := '0';
    signal reduce_calc_d : std_logic := '0';
    signal u_data_full : std_logic_vector(U_ACC_WIDTH-1 downto 0);

begin

    u_data_full <= std_logic_vector(resize(unsigned(u_data), u_data_full'length));

    process(all)
        variable temp : std_logic_vector(U_ACC_WIDTH-1 downto 0);
    begin
        temp := u_reg;

        for j in 1 to param_k-1 loop
            if to_integer(i_d) = j then
                temp := shn(u_reg, TRI_LUT(j), nibble);
            end if;
        end loop;

        y_temp <= temp;
    end process;
    
    v_addr <= std_logic_vector(resize(i, v_addr'length));
    
    mem_ram_addr <= std_logic_vector(resize(to_unsigned(param_d, mem_ram_addr'length)+o, mem_ram_addr'length)) when a_decode = '1' else std_logic_vector(resize(a,mem_ram_addr'length));
    
    a_addr <= std_logic_vector(o);

    y <= y_reg;

    ureg_reverse_inst : entity work.reverse_reg
    generic map(
        nibble => nibble,
        nibble_count => U_ACC_NIBBLES
    )
    port map(
        din => u_data_full,
        dout => u_reg
    );

    mod_fx_inst: entity work.reduce_mod_fx(Ctrl)
        generic map(param_m=>param_m,param_k=>param_k,nibble=>nibble)
        port map(
            clk => clk,
            reset => reset,
            a => y_long_reg,
            result => reduce_dout,
            start => reduce_calc_d,
            done => reduce_done
        );

    counterI: process(clk)
    begin
        if rising_edge(clk) then
            if Li = '1' then
                i <= (others => '0');
            elsif Ei = '1' then
                i <= i + 1;
            end if;    
        end if;
    end process;

    counterA: process(clk)
    begin
        if rising_edge(clk) then
            if La = '1' then
                a <= (others => '0');
            elsif Ea = '1' then
                a <= a + 1;
            end if;          
        end if;
    end process;
    
    counterO: process(clk)
    begin
        if rising_edge(clk) then
            if Lo = '1' then
                o <= (others => '0');
            elsif Eo = '1' then
                o <= o + 1;
            end if;    
        end if;
    end process;

    y_reg_inst : process(clk)
    begin
        if rising_edge(clk) then
            y_temp_d <= y_temp;
            i_d <= i;
            arr_d <= arr;
            arr_d2 <= arr_d;
            arr_d3 <= arr_d2;
            reduce_calc_d <= reduce_calc;
            if Ey = '1' then
                y_reg <= reduce_dout;
            end if;
        end if;
    end process;
    
    y_long_reg_inst : process(clk)
        variable acc_zeroes : std_logic_vector(U_ACC_TARGET_ZERO_BITS - 1 downto 0) := (others => '0');
    begin
        if rising_edge(clk) then
            if Ly = '1' then
                y_long_reg <= (others => '0');
            elsif Lt = '1' then
                y_long_reg <= target & acc_zeroes;
            elsif arr_d3 = '1' then
                y_long_reg <= y_long_reg xor y_temp_d;
            end if;
        end if;
    end process;

    a_limit <= to_unsigned(param_n-1, clog2(param_n)) when verify = '1' else to_unsigned(param_d-1, clog2(param_n));
    
    zi <= '1' when i = to_unsigned(param_k-1, nibble) else '0';
    za <= '1' when a = a_limit else '0';
    zo <= '1' when o = to_unsigned(param_o-1, clog2(param_o)) else '0';

end rtl;
