-- utility package containing useful operations that should exist by default
package util_pkg is
  function clog2(n: integer) return integer;
  function ceil_div(a: integer; b: integer) return integer;
  function max(L, R : integer) return integer;
  function min(L, R : integer) return integer;
end package util_pkg;

package body util_pkg is
  -- this function does exactly what you expect it to
  function clog2(n: integer) return integer is
    variable m, p: integer;
  begin
    m := 0;
    p := 1;
    while p < n loop
      m := m + 1;
      p := p * 2;
    end loop;
    return m;
  end clog2;

  function ceil_div(a: integer; b: integer) return integer is
  begin
    return (a + b - 1) / b;
  end ceil_div;

  function max(L, R : integer) return integer is
  begin
    if L > R then
      return L;
    else
      return R;
    end if;
  end;

  function min(L, R : integer) return integer is
  begin
    if L < R then
      return L;
    else
      return R;
    end if;
  end;

end package body util_pkg;
