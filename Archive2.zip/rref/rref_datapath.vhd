----------------------------------------------------------------------------------------------------
--
-- Entity: rref_datapath
--
-- Description:
--
----------------------------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use work.util_pkg.all;

entity rref_datapath is
  generic (
    N            : integer := 468;
    K            : integer := 234;
    Q            : integer := 31;
    COL_ID_WIDTH : integer := clog2(N);
    ROW_ID_WIDTH : integer := clog2(K);
    DATA_WIDTH   : integer := clog2(Q);
    MEM_DEPTH    : integer := ((K + 4) / 5) * 5;
    USE_COL_PERM : boolean := false
  );
  port (
    clk_i               :  in std_logic;
    rst_i               :  in std_logic;
    -- counters
    row_en_i            :  in std_logic;
    row_ld_i            :  in std_logic;
    row_z_o             : out std_logic;
    row_last_o          : out std_logic;
    row_to_reduce_en_i  :  in std_logic;
    row_to_reduce_ld_i  :  in std_logic;
    row_to_reduce_z_o   : out std_logic;
    wr_row_id_z_o       : out std_logic;
    rref_done_o         : out std_logic;
    -- column memory
    init_i    :  in std_logic;
    en_i      :  in std_logic_vector(N-1 downto 0);
    we_i      :  in std_logic_vector(N-1 downto 0);
    swap_i    :  in std_logic;
    data_i    :  in std_logic_vector((N*DATA_WIDTH)-1 downto 0);
    data_o    : out std_logic_vector((N*DATA_WIDTH)-1 downto 0);
    rd_addr_i :  in std_logic_vector((ceil_div(N, 5)*clog2(MEM_DEPTH)-1) downto 0); -- one read address for each bram
    rd_en_i   :  in std_logic;                                                  -- memory read enable
    -- pivot search
    start_search_i      :  in std_logic;
    col_mask_en_i       :  in std_logic;
    col_mask_ld_i       :  in std_logic;
    valid_pivot_o       : out std_logic;
    pivot_col_list_o    : out std_logic_vector(N-1 downto 0);
    -- col permutation table for pivot search
    col_tbl_addr_i :  in std_logic_vector(COL_ID_WIDTH-1 downto 0);
    col_tbl_we_i   :  in std_logic;
    col_tbl_data_i :  in std_logic_vector(COL_ID_WIDTH-1 downto 0);
    -- row arithmetic
    rescale_pivot_row_i : in std_logic;
    new_pivot_i         : in std_logic
  );

end rref_datapath;

architecture structural of rref_datapath is

  -- counters
  signal row_id_to_reduce_r : unsigned(ROW_ID_WIDTH downto 0);
  signal ritr               : unsigned(ROW_ID_WIDTH-1 downto 0);

  signal ritr_sub_3_temp    : unsigned(ROW_ID_WIDTH-1 downto 0);
  signal ritr_sub_3         : unsigned(ROW_ID_WIDTH   downto 0);
  signal ritr_sub_3_red     : unsigned(ROW_ID_WIDTH   downto 0);
  signal ritr_sub_3_final   : unsigned(ROW_ID_WIDTH-1 downto 0);
  signal rd_row_id_r        : unsigned(ROW_ID_WIDTH-1 downto 0) := (others => '0');

  signal wr_row_id_r        : unsigned(ROW_ID_WIDTH-1 downto 0) := (others => '0');

  -- control signals for write stage of pipeline
  signal wr_row_en_r        : std_logic;
  signal wr_row_en_r2       : std_logic;
  signal wr_row_en_r3       : std_logic;
  signal wr_row_en_r4       : std_logic;
  signal wr_row_en_r5       : std_logic;
  signal wr_row_en_r6       : std_logic;
  signal wr_row_en_r7       : std_logic;
  signal wr_row_en_r8       : std_logic;

  signal wr_row_ld_r        : std_logic;
  signal wr_row_ld_r2       : std_logic;
  signal wr_row_ld_r3       : std_logic;
  signal wr_row_ld_r4       : std_logic;
  signal wr_row_ld_r5       : std_logic;
  signal wr_row_ld_r6       : std_logic;
  signal wr_row_ld_r7       : std_logic;
  signal wr_row_ld_r8       : std_logic;

  signal ritr_r             : unsigned(ROW_ID_WIDTH-1 downto 0);
  signal ritr_r2            : unsigned(ROW_ID_WIDTH-1 downto 0);
  signal ritr_r3            : unsigned(ROW_ID_WIDTH-1 downto 0);
  signal ritr_r4            : unsigned(ROW_ID_WIDTH-1 downto 0);
  signal ritr_r5            : unsigned(ROW_ID_WIDTH-1 downto 0);
  signal ritr_r6            : unsigned(ROW_ID_WIDTH-1 downto 0);
  signal ritr_r7            : unsigned(ROW_ID_WIDTH-1 downto 0);
  signal ritr_r8            : unsigned(ROW_ID_WIDTH-1 downto 0);

  signal we_r  : std_logic_vector(N-1 downto 0);
  signal we_r2 : std_logic_vector(N-1 downto 0);
  signal we_r3 : std_logic_vector(N-1 downto 0);
  signal we_r4 : std_logic_vector(N-1 downto 0);
  signal we_r5 : std_logic_vector(N-1 downto 0);
  signal we_r6 : std_logic_vector(N-1 downto 0);
  signal we_r7 : std_logic_vector(N-1 downto 0);
  signal we_r8 : std_logic_vector(N-1 downto 0);

  signal wr_swap_r  : std_logic;
  signal wr_swap_r2 : std_logic;
  signal wr_swap_r3 : std_logic;
  signal wr_swap_r4 : std_logic;
  signal wr_swap_r5 : std_logic;
  signal wr_swap_r6 : std_logic;
  signal wr_swap_r7 : std_logic;
  signal wr_swap_r8 : std_logic;

  -- input data/loopback mux
  signal data     : std_logic_vector((N*DATA_WIDTH-1) downto 0);
  signal results  : std_logic_vector((N*DATA_WIDTH-1) downto 0);
  signal mem_data : std_logic_vector((N*DATA_WIDTH-1) downto 0);

  -- pivot search signals
  signal pivot_row_id   : std_logic_vector(ROW_ID_WIDTH-1 downto 0) := (others => '0');
  signal pivot_col_id   : std_logic_vector(COL_ID_WIDTH-1 downto 0) := (others => '0');
  signal pivot_col_id_r : std_logic_vector(COL_ID_WIDTH-1 downto 0) := (others => '0');

  signal search_done_o : std_logic;


begin

  -- counters
  -- reset to 0 when rst_i = '1'
  -- init = 1 => row_en_i bypass pipeline for wr row id
  process (clk_i)
  begin
    if rising_edge(clk_i) then

      -- row id to reduce
      if ((rst_i = '1') or (row_to_reduce_ld_i = '1')) then
        row_id_to_reduce_r <= (others => '0');
      else
        if (row_to_reduce_en_i = '1') then
          row_id_to_reduce_r <= row_id_to_reduce_r + 1;
        end if;
      end if;

      -- rd row id
      if (rst_i = '1') then
        rd_row_id_r <= (others => '0');
      else
        if ((row_ld_i and row_z_o) = '1') then
          rd_row_id_r <= ritr;
        elsif (row_en_i = '1') then
          rd_row_id_r <= rd_row_id_r + 1 when (rd_row_id_r ?< K-1) else (others => '0');
        end if;
      end if;

      -- wr row counter pipeline
      if (init_i = '0') then
        wr_row_en_r  <= row_en_i;
        wr_row_en_r2 <= wr_row_en_r;
        wr_row_en_r3 <= wr_row_en_r2;
        wr_row_en_r4 <= wr_row_en_r3;
        wr_row_en_r5 <= wr_row_en_r4;
        wr_row_en_r6 <= wr_row_en_r5;
        wr_row_en_r7 <= wr_row_en_r6;
        wr_row_en_r8 <= wr_row_en_r7;

        wr_row_ld_r  <= row_ld_i and row_z_o;
        wr_row_ld_r2 <= wr_row_ld_r;
        wr_row_ld_r3 <= wr_row_ld_r2;
        wr_row_ld_r4 <= wr_row_ld_r3;
        wr_row_ld_r5 <= wr_row_ld_r4;
        wr_row_ld_r6 <= wr_row_ld_r5;
        wr_row_ld_r7 <= wr_row_ld_r6;
        wr_row_ld_r8 <= wr_row_ld_r7;

        ritr_r  <= ritr;
        ritr_r2 <= ritr_r;
        ritr_r3 <= ritr_r2;
        ritr_r4 <= ritr_r3;
        ritr_r5 <= ritr_r4;
        ritr_r6 <= ritr_r5;
        ritr_r7 <= ritr_r6;
        ritr_r8 <= ritr_r7;
      end if;

      -- wr row id
      if (rst_i = '1') then
        wr_row_id_r <= (others => '0');
      else
        if (wr_row_ld_r7 = '1') then
          wr_row_id_r <= ritr_r7;
        -- use pipelined row en, or if init is 1, use the normal row en
        elsif ((wr_row_en_r7 = '1') or ((row_en_i = '1') and (init_i = '1'))) then
          wr_row_id_r <= wr_row_id_r + 1 when (wr_row_id_r ?< K-1) else (others => '0');
        end if;
      end if;

    end if;

  end process;

  ritr             <= row_id_to_reduce_r(ROW_ID_WIDTH-1 downto 0);
  -- ritr_sub_3_temp  <= ritr when (ritr ?< K) else ritr - K; --doubt
  ritr_sub_3_temp  <= ritr when (row_id_to_reduce_r ?< K) else ritr - K;
  ritr_sub_3       <= (("0" & ritr_sub_3_temp) - 1 + K);
  ritr_sub_3_red   <= ritr_sub_3 - K;
  ritr_sub_3_final <= ritr_sub_3(ROW_ID_WIDTH-1 downto 0) when (ritr_sub_3 ?< K) else
                      ritr_sub_3_red(ROW_ID_WIDTH-1 downto 0);
  row_z_o          <= '1' when (rd_row_id_r ?= ritr_sub_3_final) else '0';

  row_last_o       <= '1' when (rd_row_id_r ?= K-1) else '0';

  -- row_to_reduce_z_o <= '1' when (row_id_to_reduce_r(ROW_ID_WIDTH-1 downto 0) ?= K) else '0'; --doubt
  row_to_reduce_z_o <= '1' when (row_id_to_reduce_r ?= K) else '0';

  wr_row_id_z_o <= '1' when (wr_row_id_r ?= K-2) else '0';

  process(clk_i)
  begin
    if (rising_edge(clk_i)) then
      if ((row_to_reduce_z_o ?= '1') and (rd_row_id_r ?= K-2)) then
        rref_done_o <= '1';
      elsif ((search_done_o ?= '1') and (rd_row_id_r ?= K-1) and (valid_pivot_o ?= '0')) then --doubt
        rref_done_o <= '1';
      end if;
      if ((rst_i or init_i) = '1') then
        rref_done_o <= '0';
      end if;
    end if;
  end process;

  -- input/loopback data mux
  data <= data_i when init_i = '1' else results;

  -- column memory write pipeline
  process(clk_i)
  begin
    if (rising_edge(clk_i)) then

      if (init_i = '0') then
        wr_swap_r  <= swap_i and (ritr ?/= unsigned(pivot_row_id));
        wr_swap_r2 <= wr_swap_r;
        wr_swap_r3 <= wr_swap_r2;
        wr_swap_r4 <= wr_swap_r3;
        wr_swap_r5 <= wr_swap_r4;
        wr_swap_r6 <= wr_swap_r5;
        wr_swap_r7 <= wr_swap_r6;

        we_r  <= we_i;
        we_r2 <= we_r;
        we_r3 <= we_r2;
        we_r4 <= we_r3;
        we_r5 <= we_r4;
        we_r6 <= we_r5;
        we_r7 <= we_r6;
        we_r8 <= we_r7;

      end if;

      if (rst_i = '1') then
        we_r  <= (others => '0');
        we_r2 <= (others => '0');
        we_r3 <= (others => '0');
        we_r4 <= (others => '0');
        we_r5 <= (others => '0');
        we_r6 <= (others => '0');
        we_r7 <= (others => '0');
        we_r8 <= (others => '0');
      end if;

    end if;
  end process;

  -- column memory
  -- init = 1 -> we_i bypass pipeline
  -- swap is gated by rtr != pivot row
  column_memory : entity work.rref_column_mem
    generic map(
      N            => N,
      K            => K,
      Q            => Q,
      DATA_WIDTH   => DATA_WIDTH,
      ROW_ID_WIDTH => ROW_ID_WIDTH
    )
    port map(
      clk_i          => clk_i,
      rst_i          => rst_i,
      init_i         => init_i,
      swap_i         => swap_i,
      en_i           => en_i,
      we_i           => we_r6 or (init_i and we_i), -- bypass the pipeline if init = 1
      wr_row_id_i    => std_logic_vector(wr_row_id_r),
      rd_row_id_i    => std_logic_vector(rd_row_id_r),
      pivot_row_id_i => pivot_row_id,
      data_i         => data,
      data_o         => mem_data,
      -- external read address and enable
      rd_addr_i      => rd_addr_i,
      rd_en_i        => rd_en_i
    );

  data_o <= mem_data;

  -- pivot search
  pivot_search : entity work.rref_pivot_search
    generic map(
      K            => K,
      N            => N,
      Q            => Q,
      DATA_WIDTH   => DATA_WIDTH,
      USE_COL_PERM => USE_COL_PERM
    )
    port map(
      clk_i              => clk_i,
      rst_i              => rst_i,
      data_i             => data,
      vld_data_i         => we_r6 or (init_i and we_i), -- bypass the pipeline if init = 1
      row_id_to_reduce_i => std_logic_vector(ritr),
      row_id_i           => std_logic_vector(wr_row_id_r),
      start_search_i     => start_search_i, -- bypass pipeline when init
      col_mask_en_i      => col_mask_en_i,
      col_mask_ld_i      => col_mask_ld_i,
      pivot_row_id_o     => pivot_row_id,
      pivot_col_id_o     => pivot_col_id,
      pivot_col_list_o   => pivot_col_list_o,
      valid_pivot_o      => valid_pivot_o,
      search_done_o      => search_done_o,
      -- column permutation table
      col_tbl_addr_i      => col_tbl_addr_i,
      col_tbl_data_i      => col_tbl_data_i,
      col_tbl_we_i        => col_tbl_we_i
    );


  -- register pivot col id for arithmetic
  process (clk_i)
  begin
    if (rising_edge(clk_i)) then

      if (new_pivot_i = '1') then
        pivot_col_id_r <= pivot_col_id;
      end if;

    end if;
  end process;

  -- row arithmetic
  row_arithmetic : entity work.rref_arithmetic
    generic map(
      N            => N,
      Q            => Q,
      DATA_WIDTH   => DATA_WIDTH,
      COL_ID_WIDTH => COL_ID_WIDTH
    )
    port map(
      clk_i               => clk_i,
      data_i              => mem_data,
      pivot_col_id_i      => pivot_col_id_r,
      rescale_pivot_row_i => rescale_pivot_row_i,
      result_o            => results
    );


end structural;
