----------------------------------------------------------------------------------------------------
--
-- Entity: rref_pivot_search
--
-- Description:
--
----------------------------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use work.util_pkg.all;

entity rref_pivot_search is
  generic (
    K            : integer := 318;
    N            : integer := 636;
    Q            : integer := 31;
    DATA_WIDTH   : integer := clog2(Q);
    USE_COL_PERM : boolean := false
  );
  port (
    clk_i              :  in std_logic;
    rst_i              :  in std_logic;
    data_i             :  in std_logic_vector((N*DATA_WIDTH)-1 downto 0);
    vld_data_i         :  in std_logic_vector(N-1 downto 0);
    row_id_to_reduce_i :  in std_logic_vector(clog2(K)-1 downto 0);
    row_id_i           :  in std_logic_vector(clog2(K)-1 downto 0);
    start_search_i     :  in std_logic;
    search_done_o      :  out std_logic; --doubt
    col_mask_en_i      :  in std_logic;
    col_mask_ld_i      :  in std_logic;
    pivot_row_id_o     : out std_logic_vector(clog2(K)-1 downto 0);
    pivot_col_id_o     : out std_logic_vector(clog2(N)-1 downto 0);
    pivot_col_list_o   : out std_logic_vector(N-1 downto 0);
    valid_pivot_o      : out std_logic;
    -- column perm table
    col_tbl_addr_i     :  in std_logic_vector(clog2(N)-1 downto 0);
    col_tbl_we_i       :  in std_logic;
    col_tbl_data_i     :  in std_logic_vector(clog2(N)-1 downto 0)
  );

end rref_pivot_search;

architecture behavioral of rref_pivot_search is

  constant K_BITS : integer := clog2(K);
  constant N_BITS : integer := clog2(N);

  signal pivot_col_c : std_logic_vector(N_BITS-1 downto 0);
  signal pivot_col_r : std_logic_vector(N_BITS-1 downto 0);
  signal pivot_col_r2 : std_logic_vector(N_BITS-1 downto 0);

  signal pivot_vld_c : std_logic;
  signal pivot_vld_r : std_logic;
  signal pivot_vld_r2 : std_logic;

  signal col_mask : std_logic_vector(N-1 downto 0);

  signal valid_row : std_logic;

  signal data_compare : std_logic_vector(N-1 downto 0);

  type row_id_reg_arr_t is array (0 to N-1) of std_logic_vector(K_BITS-1 downto 0);
  signal row_id_arr_r     : row_id_reg_arr_t;
  signal row_id_arr_r2    : row_id_reg_arr_t;
  signal row_id_arr_r3    : row_id_reg_arr_t;
  signal row_id_arr_r4    : row_id_reg_arr_t;
  signal vld_pivot_arr_r  : std_logic_vector(N-1 downto 0);

  signal pivot_reg_en     : std_logic_vector(N-1 downto 0);

  type unpacked_data_arr_t is array (0 to N-1) of std_logic_vector(DATA_WIDTH-1 downto 0);
  signal col_data_arr : unpacked_data_arr_t;

  signal out_reg_en_r  : std_logic;
  signal out_reg_en_r2 : std_logic;
  signal out_reg_en_r3 : std_logic;
  signal out_reg_en_r4 : std_logic;

  -- column permutation table
  type perm_tbl_arr_t is array (0 to N-1) of std_logic_vector(N_BITS-1 downto 0);
  signal perm_tbl_arr : perm_tbl_arr_t;
  signal rev_perm_tbl_arr : perm_tbl_arr_t;

  signal rev_perm_tbl_out : std_logic_vector(N_BITS-1 downto 0);

  signal perm_tbl_out : std_logic_vector(N_BITS-1 downto 0);

begin

  shift_reg : process(clk_i)
  begin
    if (rising_edge(clk_i)) then
      if ((col_mask_ld_i = '1') or (rst_i = '1')) then
          col_mask <= (others => '1');
      elsif (col_mask_en_i = '1') then
        col_mask <= col_mask(N-2 downto 0) & '0';
      end if;
    end if;
  end process shift_reg;

  valid_row <= unsigned(row_id_i) ?>= unsigned(row_id_to_reduce_i);

  gen_perm_on : if USE_COL_PERM generate

    -- column translation table (permutes the columns)
    -- its really just a bank of registers
    perm_table : process(clk_i)
    begin
      if (rising_edge(clk_i)) then
        if (col_tbl_we_i = '1') then
          perm_tbl_arr(to_integer(unsigned(col_tbl_addr_i))) <= col_tbl_data_i;
        end if;
        if (pivot_vld_r = '1') then
          perm_tbl_out <= perm_tbl_arr(to_integer(unsigned(pivot_col_r)));
        end if;
      end if;
    end process perm_table;

    -- column translation table (reverses the translation)
    rev_perm_table : process(clk_i)
    begin
      if (rising_edge(clk_i)) then
        if (col_tbl_we_i = '1') then
          rev_perm_tbl_arr(to_integer(unsigned(col_tbl_data_i))) <= col_tbl_addr_i;
        end if;
        if (pivot_vld_r = '1') then
          rev_perm_tbl_out <= rev_perm_tbl_arr(to_integer(unsigned(pivot_col_r)));
        end if;
      end if;
    end process rev_perm_table;

  end generate gen_perm_on;

  gen_perm_off : if not USE_COL_PERM generate

    -- the table is only ever written with the identity mapping (address = data),
    -- so the lookup result is the index itself; the register stage is kept so
    -- the pipeline depth matches the table-based path
    perm_identity : process(clk_i)
    begin
      if (rising_edge(clk_i)) then
        if (pivot_vld_r = '1') then
          perm_tbl_out <= pivot_col_r;
        end if;
      end if;
    end process perm_identity;

  end generate gen_perm_off;

  gen_pivot_col : for i in 0 to N-1 generate

    col_data_arr(i) <= data_i((i*DATA_WIDTH)+DATA_WIDTH-1 downto (i*DATA_WIDTH));

    data_compare(i) <= '1' when (unsigned(col_data_arr(i)) ?> 0) else '0';

    -- (((~pivot_bit[0] & (data[0] > 0) & valid_data[0] & valid_row) | start_search) & col_mask[0])
    -- chose the data_compare bit based off the permutation table
    gen_en_perm : if USE_COL_PERM generate
      pivot_reg_en(i) <= (not vld_pivot_arr_r(i)) and data_compare(to_integer(unsigned(perm_tbl_arr(i)))) and vld_data_i(to_integer(unsigned(perm_tbl_arr(i)))) and valid_row;
    end generate gen_en_perm;

    -- identity permutation: direct per-column wiring, no N:1 muxes
    gen_en_ident : if not USE_COL_PERM generate
      pivot_reg_en(i) <= (not vld_pivot_arr_r(i)) and data_compare(i) and vld_data_i(i) and valid_row;
    end generate gen_en_ident;

    pivot_reg : process(clk_i)
    begin
      if (rising_edge(clk_i)) then
        if (rst_i = '1') then
          vld_pivot_arr_r(i) <= '0';
        elsif (((pivot_reg_en(i) or start_search_i) and col_mask(i)) = '1') then
          row_id_arr_r(i)    <= row_id_i;
          vld_pivot_arr_r(i) <= not start_search_i;
        end if;
      end if;
    end process pivot_reg;

  end generate gen_pivot_col;

  pe : entity work.priority_encoder(reversed)
    generic map(
      DATA_WIDTH => N,
      ID_WIDTH   => clog2(N)
    )
    port map(
      clk_i    => clk_i,
      en_i     => '1',
      vector_i => (vld_pivot_arr_r and col_mask),
      index_o  => pivot_col_c,
      valid_o  => pivot_vld_c
    );



  pipeline : process(clk_i)
  begin
    if (rising_edge(clk_i)) then

      if ((rst_i = '1') or (col_mask_ld_i = '1')) then
        pivot_col_list_o <= (others => '0');
      end if;

      -- pipeline layer
      pivot_col_r <= pivot_col_c;
      pivot_col_r2 <= pivot_col_r;
      pivot_vld_r <= pivot_vld_c;
      pivot_vld_r2 <= pivot_vld_r;

      -- end of search
      out_reg_en_r  <= (unsigned(row_id_i) ?= (K-1));
      -- normal pipeline
      out_reg_en_r2 <= out_reg_en_r;
      row_id_arr_r2 <= row_id_arr_r;

      out_reg_en_r3 <= out_reg_en_r2;
      row_id_arr_r3 <= row_id_arr_r2;

      -- reverse column permutation table
      out_reg_en_r4 <= out_reg_en_r3;
      row_id_arr_r4 <= row_id_arr_r3;

      -- output layer

      if ((start_search_i = '1') or (rst_i = '1')) then
        valid_pivot_o <= '0';
      elsif (out_reg_en_r4) then
        valid_pivot_o <= pivot_vld_r2;
      end if;

      if (out_reg_en_r4 and pivot_vld_r2) then
        pivot_col_id_o <= perm_tbl_out;
        for i in 0 to N-1 loop
          if (unsigned(pivot_col_r2) = i) then
            pivot_row_id_o <= row_id_arr_r4(i);
          end if;
        end loop;
        pivot_col_list_o(to_integer(unsigned(perm_tbl_out))) <= '1';
      end if;
    end if;

    search_done_o <= out_reg_en_r4;

  end process pipeline;





end behavioral;
