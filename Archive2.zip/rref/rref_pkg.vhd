-- utility package containing useful operations and types that should exist by default
library ieee;
use ieee.std_logic_1164.all;

use work.util_pkg.all;

package rref_pkg is
  constant LESS_N       : integer := 400;
  constant LESS_K       : integer := 200;
  constant LESS_Q       : integer := 127;
  constant LESS_Q_WIDTH : integer := clog2(LESS_Q);
  constant LESS_K_WIDTH : integer := clog2(LESS_K);

  type unpacked_less_elem_arr_t is array (natural range <>) of std_logic_vector(LESS_Q_WIDTH-1 downto 0);

  type unpacked_less_addr_arr_t is array (natural range <>) of std_logic_vector(LESS_K_WIDTH-1 downto 0);

  type unpacked_less_matrix_t is array (0 to LESS_N-1) of unpacked_less_elem_arr_t(0 to LESS_K-1);
  type unpacked_less_k_matrix_t is array (0 to LESS_K-1) of unpacked_less_elem_arr_t(0 to LESS_K-1);

end package rref_pkg;

package body rref_pkg is


end package body rref_pkg;
