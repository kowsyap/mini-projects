----------------------------------------------------------------------------------------------------
--
-- Entity: rref_arithmetic
--
-- Description: 5 cycle latency
--
----------------------------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use std.textio.all;

use work.util_pkg.all;

entity rref_arithmetic is
  generic (
    N            : integer := 468;
    Q            : integer := 31;
    DATA_WIDTH   : integer := clog2(Q);
    COL_ID_WIDTH : integer := clog2(N)
  );
  port (
    clk_i                :  in std_logic;
    data_i               :  in std_logic_vector((N*DATA_WIDTH)-1 downto 0);
    pivot_col_id_i       :  in std_logic_vector(COL_ID_WIDTH-1 downto 0);
    rescale_pivot_row_i  :  in std_logic;
    result_o             : out std_logic_vector((N*DATA_WIDTH)-1 downto 0)
  );

end rref_arithmetic;

architecture pipelined of rref_arithmetic is

  type lut_arr_t is array (0 to Q-1) of std_logic_vector(DATA_WIDTH-1 downto 0);

  constant inv_lut : lut_arr_t := (
    0  => "0000",
    1  => "0001",
    2  => "1001",
    3  => "1110",
    4  => "1101",
    5  => "1011",
    6  => "0111",
    7  => "0110",
    8  => "1111",
    9  => "0010",
    10 => "1100",
    11 => "0101",
    12 => "1010",
    13 => "0100",
    14 => "0011",
    15 => "1000"
  );

  signal mux_id : integer := 0;
  signal data_mux_out : std_logic_vector(DATA_WIDTH-1 downto 0);
  signal data_mux_out_r : std_logic_vector(DATA_WIDTH-1 downto 0);
  signal multiplier : std_logic_vector(DATA_WIDTH-1 downto 0);

  signal multiplier_r : std_logic_vector(DATA_WIDTH-1 downto 0);
  signal data_r  : std_logic_vector((N*DATA_WIDTH)-1 downto 0);
  signal data_r2 : std_logic_vector((N*DATA_WIDTH)-1 downto 0);
  signal rescale_pivot_row_r  : std_logic;
  signal rescale_pivot_row_r2 : std_logic;

  signal pivot_col_id_r : std_logic_vector(COL_ID_WIDTH-1 downto 0);

begin

  -- temporary process to stall pipeline
  process (clk_i)
  begin
    if (rising_edge(clk_i)) then
      pivot_col_id_r <= pivot_col_id_i;
    end if;
  end process;

  -- generate data mux
  mux_id <= to_integer(unsigned(pivot_col_id_r));

  -- select the element from the row
  data_mux_out <= data_r(((mux_id)*DATA_WIDTH)+DATA_WIDTH-1 downto (mux_id*DATA_WIDTH));

  -- mux for multiplier
  multiplier <= inv_lut(to_integer(unsigned(data_mux_out_r))) when rescale_pivot_row_r2 ?= '1' else
                data_mux_out_r;

  process (clk_i)
  begin
    if (rising_edge(clk_i)) then
      -- p1 (pivot column permutation table)
      rescale_pivot_row_r <= rescale_pivot_row_i;
      data_r <= data_i;
      -- p2 (pivot column mux)
      rescale_pivot_row_r2 <= rescale_pivot_row_r;
      data_r2              <= data_r;
      data_mux_out_r       <= data_mux_out;
      -- p3 (invert look up table)
      multiplier_r        <= multiplier;
    end if;
  end process;

  -- generate col arithmetic
  gen_col_arith : for i in 0 to N-1 generate

    inst_col_arith : entity work.col_arith(pipelined)
      generic map (
        Q          => Q,
        DATA_WIDTH => DATA_WIDTH
      )
      port map (
        clk_i                => clk_i,
        data_i               => data_r2((i*DATA_WIDTH)+DATA_WIDTH-1 downto (i*DATA_WIDTH)),
        multiplier_i         => multiplier_r,
        rescale_pivot_row_i  => rescale_pivot_row_r2,
        result_o             => result_o((i*DATA_WIDTH)+DATA_WIDTH-1 downto (i*DATA_WIDTH))
      );

  end generate gen_col_arith;

end pipelined;
