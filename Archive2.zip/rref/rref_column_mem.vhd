----------------------------------------------------------------------------------------------------
--
-- Entity: rref_column_mem
--
-- Description:
--
----------------------------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use work.util_pkg.all;

entity rref_column_mem is
  generic (
    N            : integer := 468;
    K            : integer := 234;
    Q            : integer := 31;
    DATA_WIDTH   : integer := clog2(Q);
    ROW_ID_WIDTH : integer := clog2(K);
    MEM_DEPTH    : integer := ((K + 4) / 5) * 5
  );
  port (
    clk_i          :  in std_logic;
    rst_i          :  in std_logic;
    init_i         :  in std_logic;
    swap_i         :  in std_logic;
    en_i           :  in std_logic_vector(N-1 downto 0);
    we_i           :  in std_logic_vector(N-1 downto 0);
    wr_row_id_i    :  in std_logic_vector(ROW_ID_WIDTH-1 downto 0);
    rd_row_id_i    :  in std_logic_vector(ROW_ID_WIDTH-1 downto 0);
    pivot_row_id_i :  in std_logic_vector(ROW_ID_WIDTH-1 downto 0);
    data_i         :  in std_logic_vector((N*DATA_WIDTH)-1 downto 0);
    data_o         : out std_logic_vector((N*DATA_WIDTH)-1 downto 0);
    -- external read address and enable
    rd_addr_i :  in std_logic_vector((ceil_div(N, 5)*clog2(MEM_DEPTH)-1) downto 0); -- one read address for each bram
    rd_en_i   :  in std_logic                                                   -- memory read enable
  );

end rref_column_mem;

architecture behavioral of rref_column_mem is

  constant COL_PER_MEM : integer := 5;
  constant MEM_CHUNKS  : integer := ceil_div(N, COL_PER_MEM);

  signal trn_wr_row_id : std_logic_vector(ROW_ID_WIDTH-1 downto 0) := (others => '0');
  signal trn_rd_row_id : std_logic_vector(ROW_ID_WIDTH-1 downto 0) := (others => '0');
  signal piv_wr_row_id : std_logic_vector(ROW_ID_WIDTH-1 downto 0) := (others => '0');
  signal piv_rd_row_id : std_logic_vector(ROW_ID_WIDTH-1 downto 0) := (others => '0');
  signal new_wr_row_id : std_logic_vector(ROW_ID_WIDTH-1 downto 0) := (others => '0');
  signal new_rd_row_id : std_logic_vector(ROW_ID_WIDTH-1 downto 0) := (others => '0');
  signal wr_addr       : std_logic_vector(ROW_ID_WIDTH-1 downto 0) := (others => '0');
  signal rd_addr       : std_logic_vector(ROW_ID_WIDTH-1 downto 0) := (others => '0');
  signal wr_addr_temp  : std_logic_vector(clog2(MEM_DEPTH)-1 downto 0) := (others => '0');
  signal rd_addr_temp  : std_logic_vector(clog2(MEM_DEPTH)-1 downto 0) := (others => '0');
  signal mem_rd_addr   : std_logic_vector(ROW_ID_WIDTH-1 downto 0) := (others => '0');

  signal data_i_r      : std_logic_vector((N*DATA_WIDTH)-1 downto 0);
  signal we_r          : std_logic_vector(N-1 downto 0);
  signal en_r          : std_logic_vector(N-1 downto 0);
  signal wr_row_id_r   : std_logic_vector(ROW_ID_WIDTH-1 downto 0) := (others => '0');
  signal swap_r     : std_logic;

  type rd_addr_arr_t is array (0 to MEM_CHUNKS-1) of std_logic_vector(clog2(MEM_DEPTH)-1 downto 0);
  signal rd_addr_arr : rd_addr_arr_t;

  -- injecting swap data into the write pipeline
  signal after_swap : std_logic;

  signal wr_data_stall : std_logic_vector((N*DATA_WIDTH)-1 downto 0);
  signal wr_data       : std_logic_vector((N*DATA_WIDTH)-1 downto 0);
  signal wr_addr_stall : std_logic_vector(ROW_ID_WIDTH-1 downto 0) := (others => '0');
  signal we_stall      : std_logic_vector(N-1 downto 0);
  signal wr_en         : std_logic_vector(N-1 downto 0);
  signal rd_data       : std_logic_vector((N*DATA_WIDTH)-1 downto 0);

begin

  process (clk_i)
  begin
    if (rising_edge(clk_i)) then
      if (swap_i = '1') then
        after_swap <= '1';
      end if;
      if (unsigned(we_i) ?= 0) then
        after_swap <= '0';
      end if;
      if (rst_i = '1') then
        after_swap <= '0';
      end if;
      if (init_i = '1') then
        after_swap <= '0';
      end if;
    end if;

    -- pipeline stall
    if (rising_edge(clk_i)) then
      data_i_r    <= data_i;
      we_r        <= we_i;
      en_r        <= en_i;
      wr_row_id_r <= wr_row_id_i;
      swap_r   <= swap_i;
    end if;
  end process;

  -- stall selection
  wr_data_stall <= data_i_r when after_swap = '1' else
                   data_i;
  wr_addr_stall <= wr_row_id_r when after_swap = '1' else
                   wr_row_id_i;
  we_stall      <= we_r when after_swap = '1' else
                   we_i;

  -- address and data select
  rd_addr <= pivot_row_id_i when swap_r = '1' else
             rd_row_id_i;

  wr_data <= rd_data when swap_r = '1' else
             wr_data_stall;

  wr_addr <= pivot_row_id_i when swap_r = '1' else
             wr_addr_stall;
  wr_addr_temp <= std_logic_vector(resize(unsigned(wr_addr), wr_addr_temp'length));
  rd_addr_temp <= std_logic_vector(resize(unsigned(rd_addr), rd_addr_temp'length));

  wr_en   <= (others => '1') when swap_r = '1' else
             we_stall;

  -- 5 columns per memory
  mem_array_chunks : for i in 0 to (MEM_CHUNKS-1) generate

    rd_addr_arr(i) <= rd_addr_i((i+1)*clog2(MEM_DEPTH)-1 downto i*clog2(MEM_DEPTH)) when rd_en_i = '1' else rd_addr_temp;
                                                                          --  else '0' & rd_addr; --doubt

    gen_last_mem : if i = MEM_CHUNKS-1 generate
      last_col_mem : entity work.sdp_ram(synth)
          generic map(
            DATA_WIDTH => ((N*DATA_WIDTH)-(i*DATA_WIDTH*5)),
            RAM_DEPTH  => MEM_DEPTH,
            ADDR_WIDTH => clog2(MEM_DEPTH)
          )
          port map(
            clk_i   => clk_i,
            ena_i   => en_r(i),
            enb_i   => en_r(i) or rd_en_i,
            wea_i   => wr_en(i),
            addra_i => wr_addr_temp, -- '0' & wr_addr, -- doubt
            addrb_i => rd_addr_arr(i),
            da_i    => wr_data((N*DATA_WIDTH)-1 downto (i*DATA_WIDTH*COL_PER_MEM)),
            db_o    => rd_data((N*DATA_WIDTH)-1 downto (i*DATA_WIDTH*COL_PER_MEM))
          );
    else
    gen_other_mems : generate
      col_mem : entity work.sdp_ram(synth)
        generic map(
          DATA_WIDTH => DATA_WIDTH*5,
          RAM_DEPTH  => MEM_DEPTH,
          ADDR_WIDTH => clog2(MEM_DEPTH)
        )
        port map(
          clk_i   => clk_i,
          ena_i   => en_r(i),
          enb_i   => en_r(i) or rd_en_i,
          wea_i   => wr_en(i),
          addra_i => wr_addr_temp, -- '0' & wr_addr, -- doubt
          addrb_i => rd_addr_arr(i),
          da_i    => wr_data(DATA_WIDTH*COL_PER_MEM*(i+1)-1 downto (i*DATA_WIDTH*COL_PER_MEM)),
          db_o    => rd_data(DATA_WIDTH*COL_PER_MEM*(i+1)-1 downto (i*DATA_WIDTH*COL_PER_MEM))
        );
    end generate;

  end generate;

  data_o <= rd_data;


end behavioral;
