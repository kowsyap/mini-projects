----------------------------------------------------------------------------------------------------
--
-- Entity: priority_encoder
--
-- Description: DATA_WIDTH must be greater than 4.
--
----------------------------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use work.util_pkg.all;

entity priority_encoder is
  generic (
    DATA_WIDTH : integer := 4;
    ID_WIDTH   : integer := clog2(DATA_WIDTH)
  );
  port (
    clk_i    :  in std_logic;
    en_i     :  in std_logic;
    vector_i :  in std_logic_vector(DATA_WIDTH-1 downto 0);
    index_o  : out std_logic_vector(ID_WIDTH-1 downto 0);
    valid_o  : out std_logic
  );

end priority_encoder;


-- build an N-bit priority encoder out of multiple 4-2 encoders
architecture registered of priority_encoder is
  -- conditional padding
  constant PW : integer := 2**(clog2(DATA_WIDTH-1)); -- PW (power of 2) >= DATA_WIDTH

  signal padded_vec : std_logic_vector(PW-1 downto 0);

  -- recursive signals

  type rec_vec_arr_t is array(0 to 3) of std_logic_vector((PW/4)-1 downto 0);
  type rec_id_arr_t  is array(0 to 3) of std_logic_vector(clog2((PW/4))-1 downto 0);
  type rec_vld_arr_t is array(0 to 3) of std_logic;

  signal rec_vec_arr : rec_vec_arr_t;
  signal rec_id_arr  : rec_id_arr_t;
  signal rec_vld_arr : rec_vld_arr_t;

  signal rec_id_upper : std_logic_vector(1 downto 0);
  signal rec_id_lower : std_logic_vector(clog2((PW/4))-1 downto 0);

  -- end of recursion signals
  signal pad_16bit : std_logic_vector(15 downto 0);

  type  id_arr_t is array(0 to 3) of std_logic_vector(1 downto 0);
  type vld_arr_t is array(0 to 3) of std_logic;

  signal id_arr  : id_arr_t;
  signal vld_arr : vld_arr_t;

  signal id_upper      : std_logic_vector(1 downto 0);
  signal id_lower      : std_logic_vector(1 downto 0);
  signal id_temp       : std_logic_vector(3 downto 0);

  signal id_r : std_logic_vector(ID_WIDTH-1 downto 0);
  signal vld_r : std_logic;

begin

  -- if our first DW isn't a power of 2, we pad it with 0's so it is a power of 2
  gen_padding : if (PW > DATA_WIDTH) generate
    padded_vec(PW-1 downto DATA_WIDTH) <= (others => '0');
    padded_vec(DATA_WIDTH-1 downto 0) <= vector_i;
  else generate -- DW = PW
    padded_vec <= vector_i(PW-1 downto 0);
  end generate gen_padding;

  -- condition to end recursion
  -- end recursion when we have 16 bit PW so we can generate the final 4-2 PE
  gen_recurse : if (PW <= 16) generate

    -- if the DW is less than 16, pad it with 0's so we can get an even 4x 4-2 PE
    gen_16bit_pad : if (PW < 16) generate
      pad_16bit(15 downto PW)  <= (others => '0');
      pad_16bit(PW-1 downto 0) <= padded_vec;
    else generate --both vectors should be 16 bits
      pad_16bit <= padded_vec(15 downto 0);
    end generate gen_16bit_pad;

    -- generate 4x 4-2 PE
    gen_enc : for i in 0 to 3 generate

      id_arr(i) <= "11" when pad_16bit((4*i)+3) = '1' else -- 3, 7, 11, 15
                   "10" when pad_16bit((4*i)+2) = '1' else -- 2, 6, 10, 14
                   "01" when pad_16bit((4*i)+1) = '1' else -- 1, 5,  9, 13
                   "00";                                   -- 0, 4,  8, 12

                                      -- 3:0, 7:4, 11:8, 15:12
      vld_arr(i) <= '0' when pad_16bit(((4*i)+3) downto (4*i)) = "0000" else '1';

    end generate gen_enc;



    id_upper <= "11" when vld_arr(3) = '1' else
                "10" when vld_arr(2) = '1' else
                "01" when vld_arr(1) = '1' else
                "00";

    with id_upper select
      id_lower <= id_arr(0) when "00",
                  id_arr(1) when "01",
                  id_arr(2) when "10",
                  id_arr(3) when "11",
                  (others => '0')  when others;

    id_temp <= id_upper & id_lower;

    -- registers outputs at the last layer
    process(clk_i)
    begin
      if (rising_edge(clk_i)) then
        -- Only crops the MSBs if clog2(DW) < 4
        id_r <= id_temp(ID_WIDTH-1 downto 0);
        -- map 4x 4-2 PE to output
        vld_r <= '0' when vld_arr = "0000" else '1';
      end if;
    end process;

    index_o <= id_r;
    valid_o <= vld_r;

  else generate -- PW > 16

    gen_rec_enc : for i in 0 to 3 generate

      -- split vector into 4 parts. guranteed to be even because PW is a power of 2, and divisible by 4
      rec_vec_arr(i) <= padded_vec(((PW/4)*i)+(PW/4)-1 downto (PW/4)*i);

      -- generate 4x PE for each vector part. Uses the width of the vector divided by 4
      recursive_entity : entity work.priority_encoder(registered)
        generic map (
          DATA_WIDTH => (PW/4),
          ID_WIDTH   => clog2((PW/4))
        )
        port map (
          clk_i    => clk_i,
          en_i     => en_i,
          vector_i => rec_vec_arr(i),
          index_o  => rec_id_arr(i),
          valid_o  => rec_vld_arr(i)
        );

    end generate gen_rec_enc;

    -- map to output
    valid_o <= '0' when rec_vld_arr = "0000" else '1';

    rec_id_upper <= "11" when rec_vld_arr(3) = '1' else
                    "10" when rec_vld_arr(2) = '1' else
                    "01" when rec_vld_arr(1) = '1' else
                    "00";

    with rec_id_upper select
      rec_id_lower <= rec_id_arr(0) when "00",
                      rec_id_arr(1) when "01",
                      rec_id_arr(2) when "10",
                      rec_id_arr(3) when "11",
                      (others => '0')  when others;

    index_o <= rec_id_upper & rec_id_lower;

  end generate gen_recurse;

end registered;

-- build an N-bit LSB priority encoder out of multiple 4-2 encoders
architecture reversed of priority_encoder is
  -- conditional padding
  constant PW : integer := 2**(clog2(DATA_WIDTH-1)); -- PW (power of 2) >= DATA_WIDTH

  signal padded_vec : std_logic_vector(PW-1 downto 0);

  -- recursive signals

  type rec_vec_arr_t is array(0 to 3) of std_logic_vector((PW/4)-1 downto 0);
  type rec_id_arr_t  is array(0 to 3) of std_logic_vector(clog2((PW/4))-1 downto 0);
  type rec_vld_arr_t is array(0 to 3) of std_logic;

  signal rec_vec_arr : rec_vec_arr_t;
  signal rec_id_arr  : rec_id_arr_t;
  signal rec_vld_arr : rec_vld_arr_t;

  signal rec_id_upper : std_logic_vector(1 downto 0);
  signal rec_id_lower : std_logic_vector(clog2((PW/4))-1 downto 0);

  -- end of recursion signals
  signal pad_16bit : std_logic_vector(15 downto 0);

  type  id_arr_t is array(0 to 3) of std_logic_vector(1 downto 0);
  type vld_arr_t is array(0 to 3) of std_logic;

  signal id_arr  : id_arr_t;
  signal vld_arr : vld_arr_t;

  signal id_upper      : std_logic_vector(1 downto 0);
  signal id_lower      : std_logic_vector(1 downto 0);
  signal id_temp       : std_logic_vector(3 downto 0);

  signal id_r  : std_logic_vector(ID_WIDTH-1 downto 0);
  signal vld_r : std_logic;

begin

  -- if our first DW isn't a power of 2, we pad it with 0's so it is a power of 2
  gen_padding : if (PW > DATA_WIDTH) generate
    padded_vec(PW-1 downto DATA_WIDTH) <= (others => '0');
    padded_vec(DATA_WIDTH-1 downto 0) <= vector_i;
  else generate -- DW = PW
    padded_vec <= vector_i(PW-1 downto 0);
  end generate gen_padding;

  -- condition to end recursion
  -- end recursion when we have 16 bit PW so we can generate the final 4-2 PE
  gen_recurse : if (PW <= 16) generate

    -- if the DW is less than 16, pad it with 0's so we can get an even 4x 4-2 PE
    gen_16bit_pad : if (PW < 16) generate
      pad_16bit(15 downto PW)  <= (others => '0');
      pad_16bit(PW-1 downto 0) <= padded_vec;
    else generate --both vectors should be 16 bits
      pad_16bit <= padded_vec(15 downto 0);
    end generate gen_16bit_pad;

    -- generate 4x 4-2 PE
    gen_enc : for i in 0 to 3 generate

      id_arr(i) <= "00" when pad_16bit((4*i)  ) = '1' else -- 0, 4,  8, 12
                   "01" when pad_16bit((4*i)+1) = '1' else -- 1, 5,  9, 13
                   "10" when pad_16bit((4*i)+2) = '1' else -- 2, 6, 10, 14
                   "11";                                   -- 3, 7, 11, 15

                                      -- 3:0, 7:4, 11:8, 15:12
      vld_arr(i) <= '0' when pad_16bit(((4*i)+3) downto (4*i)) = "0000" else '1';

    end generate gen_enc;

    -- id_arr(0) <= "00";
    -- vld_arr(0) <= '1';

    id_upper <= "00" when vld_arr(0) = '1' else
                "01" when vld_arr(1) = '1' else
                "10" when vld_arr(2) = '1' else
                "11";

    with id_upper select
      id_lower <= id_arr(0) when "00",
                  id_arr(1) when "01",
                  id_arr(2) when "10",
                  id_arr(3) when "11",
                  (others => '0')  when others;

    -- id_lower <= "00";

    id_temp <= id_upper & id_lower;

    -- registers outputs at the last layer
    process(clk_i)
    begin
      if (rising_edge(clk_i)) then
        -- Only crops the MSBs if clog2(DW) < 4
        id_r <= id_temp(ID_WIDTH-1 downto 0);
        -- map 4x 4-2 PE to output
        vld_r <= '0' when vld_arr = "0000" else '1';
      end if;
    end process;

    index_o <= id_r;
    valid_o <= vld_r;

  else generate -- PW > 16

    gen_rec_enc : for i in 0 to 3 generate

      -- split vector into 4 parts. guranteed to be even because PW is a power of 2, and divisible by 4
      rec_vec_arr(i) <= padded_vec(((PW/4)*i)+(PW/4)-1 downto (PW/4)*i);

      -- generate 4x PE for each vector part. Uses the width of the vector divided by 4
      recursive_entity : entity work.priority_encoder(reversed)
        generic map (
          DATA_WIDTH => (PW/4),
          ID_WIDTH   => clog2((PW/4))
        )
        port map (
          clk_i    => clk_i,
          en_i     => en_i,
          vector_i => rec_vec_arr(i),
          index_o  => rec_id_arr(i),
          valid_o  => rec_vld_arr(i)
        );

    end generate gen_rec_enc;

    -- map to output
    valid_o <= '0' when rec_vld_arr = "0000" else '1';

    rec_id_upper <= "00" when rec_vld_arr(0) = '1' else
                    "01" when rec_vld_arr(1) = '1' else
                    "10" when rec_vld_arr(2) = '1' else
                    "11";

    with rec_id_upper select
      rec_id_lower <= rec_id_arr(0) when "00",
                      rec_id_arr(1) when "01",
                      rec_id_arr(2) when "10",
                      rec_id_arr(3) when "11",
                      (others => '0')  when others;

    index_o <= rec_id_upper & rec_id_lower;

  end generate gen_recurse;

end reversed;


architecture simple_lsb of priority_encoder is

  constant ZEROS : unsigned(DATA_WIDTH-1 downto 0) := (others => '0');
  constant THIRD  : integer := DATA_WIDTH/3;

  signal index_r   : std_logic_vector(ID_WIDTH-1 downto 0);
  signal vector_r  : std_logic_vector(DATA_WIDTH-1 downto 0);
  signal index_r2  : std_logic_vector(ID_WIDTH-1 downto 0);
  signal vector_r2 : std_logic_vector(DATA_WIDTH-1 downto 0);

begin

  process(clk_i)
  begin
    if (rising_edge(clk_i)) then

      if (en_i = '1') then
        for i in DATA_WIDTH-1 downto DATA_WIDTH-THIRD loop
          if (vector_i(i) = '1') then
            index_r <= std_logic_vector(to_unsigned(i, ID_WIDTH));
          end if;
        end loop;
        vector_r <= vector_i;

        index_r2 <= index_r;
        for i in DATA_WIDTH-THIRD-1 downto THIRD loop
          if (vector_r(i) = '1') then
            index_r2 <= std_logic_vector(to_unsigned(i, ID_WIDTH));
          end if;
        end loop;
        vector_r2 <= vector_r;

      end if;

    end if;
  end process;

  process(all)
  begin

    index_o <= index_r2;
    for i in THIRD-1 downto 0 loop
      if (vector_r2(i) = '1') then
        index_o <= std_logic_vector(to_unsigned(i, ID_WIDTH));
      end if;
    end loop;

    valid_o <= '0' when unsigned(vector_r2) ?= ZEROS else '1';
  end process;

end simple_lsb;
