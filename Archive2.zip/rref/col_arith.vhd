----------------------------------------------------------------------------------------------------
--
-- Entity: col_arith
--
-- Description: 5 cycle latency
--
----------------------------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use work.util_pkg.all;
use work.rref_pkg.all;

entity col_arith is
  generic (
    Q          : integer := 31;
    DATA_WIDTH : integer := clog2(Q)
  );
  port (
    clk_i                :  in std_logic;
    data_i               :  in std_logic_vector(DATA_WIDTH-1 downto 0);
    multiplier_i         :  in std_logic_vector(DATA_WIDTH-1 downto 0);
    rescale_pivot_row_i  :  in std_logic;
    result_o             : out std_logic_vector(DATA_WIDTH-1 downto 0)
  );

end col_arith;

architecture pipelined of col_arith is

  signal pivot_row_rescaled   : std_logic_vector(DATA_WIDTH-1 downto 0);
  signal pivot_row_rescaled_r : std_logic_vector(DATA_WIDTH-1 downto 0);

  signal mult_in  : std_logic_vector(DATA_WIDTH-1 downto 0);
  signal mult_out : std_logic_vector(DATA_WIDTH-1 downto 0);
  signal mult_out_r1 : std_logic_vector(DATA_WIDTH-1 downto 0);
  signal mult_out_r2 : std_logic_vector(DATA_WIDTH-1 downto 0);
  signal sub_mid  : std_logic_vector(DATA_WIDTH   downto 0);
  signal cond_red : std_logic_vector(DATA_WIDTH   downto 0);
  signal sub_out  : std_logic_vector(DATA_WIDTH-1 downto 0);
  signal result_c : std_logic_vector(DATA_WIDTH-1 downto 0);

  signal rpr_r1      : std_logic;
  signal rpr_r2      : std_logic;
  signal rpr_r3      : std_logic;
  signal mult_in_r   : std_logic_vector(DATA_WIDTH-1 downto 0);
  signal data_r1     : std_logic_vector(DATA_WIDTH-1 downto 0);
  signal data_r2     : std_logic_vector(DATA_WIDTH-1 downto 0);
  signal data_r3     : std_logic_vector(DATA_WIDTH-1 downto 0);
  signal result_r    : std_logic_vector(DATA_WIDTH-1 downto 0);

begin

  -- pipeline registers
  process (clk_i)
  begin
    if (rising_edge(clk_i)) then
      -- p1 - scale factor select
      mult_in_r <= mult_in;
      data_r1   <= data_i;
      rpr_r1    <= rescale_pivot_row_i;

      -- p2 parallel with mult_mod_q p1 - multiply and reduce p1
      data_r2 <= data_r1;
      rpr_r2  <= rpr_r1;

      -- p3 parallel with mult_mod_q p2 - multiply and reduce p2
      data_r3 <= data_r2;
      rpr_r3  <= rpr_r2;

      mult_out_r1 <= mult_out;
      mult_out_r2 <= mult_out_r1;

      -- pivot row rescaled register
      if (rpr_r3 = '1') then
        pivot_row_rescaled_r <= mult_out_r2;
      end if;

      -- p4 - output register (not needed maybe)
      result_r    <= result_c;
    end if;
  end process;

  -- pivot row rescaled bypass mux
  pivot_row_rescaled <= mult_out_r2 when rpr_r3 ?= '1' else
                        pivot_row_rescaled_r;

  -- rescale mux 1
  mult_in <= data_i when rescale_pivot_row_i ?= '1' else
             pivot_row_rescaled;

    mul_inst: entity work.mul_gf16
      port map (
          a => multiplier_i,
          b => mult_in_r,
          result => mult_out
      );

  sub_out <= data_r3 xor mult_out_r2;

  result_c <= mult_out_r2 when rpr_r3 = '1' else
              sub_out;

  result_o <= result_r;

end pipelined;
