
----------------------------------------------------------------------------------------------------
--
-- Entity: rref_top
--
-- Description:
--
----------------------------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use work.util_pkg.all;

entity rref_top is
  generic (
    N            : integer := 468;
    K            : integer := 234;
    Q            : integer := 31;
    COL_ID_WIDTH : integer := clog2(N);
    ROW_ID_WIDTH : integer := clog2(K);
    DATA_WIDTH   : integer := clog2(Q);
    MEM_DEPTH    : integer := ((K + 4) / 5) * 5;
    USE_COL_PERM : boolean := false
  );
  port (
    clk_i  :  in std_logic;
    rst_i  :  in std_logic;
    -- input interface
    vld_i  :  in std_logic;
    we_i   :  in std_logic_vector(N-1 downto 0); -- one write enable per column
    data_i :  in std_logic_vector((N*DATA_WIDTH)-1 downto 0);
    last_i :  in std_logic;                                   -- identifies that the last chunk of a row was written.
    -- column permutation table
    col_tbl_addr_i :  in std_logic_vector(COL_ID_WIDTH-1 downto 0);
    col_tbl_we_i   :  in std_logic;
    col_tbl_data_i :  in std_logic_vector(COL_ID_WIDTH-1 downto 0);
    -- output interface
    rd_addr_i        :  in std_logic_vector((ceil_div(N, 5)*clog2(MEM_DEPTH)-1) downto 0); -- one read address for each bram
    rd_en_i          :  in std_logic;                                                  -- memory read enable
    data_o           : out std_logic_vector((N*DATA_WIDTH)-1 downto 0);
    pivot_col_list_o : out std_logic_vector(N-1 downto 0);                             -- flag if a column is a pivot
    -- status
    done_o : out std_logic
  );

end rref_top;

architecture structural of rref_top is

  -- counters
  signal row_en            : std_logic;
  signal row_ld            : std_logic;
  signal row_z             : std_logic;
  signal row_last          : std_logic;
  signal row_to_reduce_en  : std_logic;
  signal row_to_reduce_ld  : std_logic;
  signal row_to_reduce_z   : std_logic;
  signal wr_row_id_z       : std_logic;
  signal rref_done         : std_logic;
  -- column memory
  signal init              : std_logic;
  signal en                : std_logic_vector(N-1 downto 0);
  signal we                : std_logic_vector(N-1 downto 0);
  signal swap              : std_logic;
  -- pivot search
  signal start_search      : std_logic;
  signal col_mask_en       : std_logic;
  signal col_mask_ld       : std_logic;
  signal valid_pivot       : std_logic;
  -- row arithmetic
  signal rescale_pivot_row : std_logic;
  signal new_pivot         : std_logic;

begin

  datapath : entity work.rref_datapath
    generic map(
      N            => N,
      K            => K,
      Q            => Q,
      COL_ID_WIDTH => COL_ID_WIDTH,
      ROW_ID_WIDTH => ROW_ID_WIDTH,
      DATA_WIDTH   => DATA_WIDTH,
      USE_COL_PERM => USE_COL_PERM
    )
    port map(
      clk_i               => clk_i,
      rst_i               => rst_i,
      row_en_i            => row_en,
      row_ld_i            => row_ld,
      row_z_o             => row_z,
      row_last_o          => row_last,
      row_to_reduce_en_i  => row_to_reduce_en,
      row_to_reduce_ld_i  => row_to_reduce_ld,
      row_to_reduce_z_o   => row_to_reduce_z,
      wr_row_id_z_o       => wr_row_id_z,
      rref_done_o         => rref_done,
      init_i              => init,
      en_i                => en,
      we_i                => we or (we_i and init),
      swap_i              => swap,
      data_i              => data_i,
      data_o              => data_o,
      start_search_i      => start_search,
      col_mask_en_i       => col_mask_en,
      col_mask_ld_i       => col_mask_ld,
      valid_pivot_o       => valid_pivot,
      rescale_pivot_row_i => rescale_pivot_row,
      pivot_col_list_o    => pivot_col_list_o,
      new_pivot_i         => new_pivot,
      -- column permutation table
      col_tbl_addr_i      => col_tbl_addr_i,
      col_tbl_data_i      => col_tbl_data_i,
      col_tbl_we_i        => col_tbl_we_i,
      -- internal memory access
      rd_addr_i     => rd_addr_i,
      rd_en_i       => rd_en_i
    );

  controller : entity work.rref_controller
    generic map(
      N => N
    )
    port map(
      clk_i               => clk_i,
      rst_i               => rst_i,
      vld_i               => vld_i,
      last_i              => last_i,
      done_o              => done_o,
      row_en_o            => row_en,
      row_ld_o            => row_ld,
      row_z_i             => row_z,
      row_last_i          => row_last,
      row_to_reduce_en_o  => row_to_reduce_en,
      row_to_reduce_ld_o  => row_to_reduce_ld,
      row_to_reduce_z_i   => row_to_reduce_z,
      wr_row_id_z_i       => wr_row_id_z,
      rref_done_i         => rref_done,
      init_o              => init,
      en_o                => en,
      we_o                => we,
      swap_o              => swap,
      start_search_o      => start_search,
      col_mask_en_o       => col_mask_en,
      col_mask_ld_o       => col_mask_ld,
      valid_pivot_i       => valid_pivot,
      rescale_pivot_row_o => rescale_pivot_row,
      new_pivot_o         => new_pivot
    );


end structural;
