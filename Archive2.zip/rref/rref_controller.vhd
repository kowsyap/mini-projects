----------------------------------------------------------------------------------------------------
--
-- Entity: rref_controller
--
-- Description:
--
----------------------------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use work.util_pkg.all;

entity rref_controller is
  generic (
    N            : integer := 468
  );
  port (
    clk_i               :  in std_logic;
    rst_i               :  in std_logic;
    -- data transfer
    vld_i               :  in std_logic;
    done_o              : out std_logic;
    last_i              :  in std_logic;
    -- counters
    row_en_o            : out std_logic;
    row_ld_o            : out std_logic;
    row_z_i             :  in std_logic;
    row_last_i          :  in std_logic;
    row_to_reduce_en_o  : out std_logic;
    row_to_reduce_ld_o  : out std_logic;
    row_to_reduce_z_i   :  in std_logic;
    wr_row_id_z_i       :  in std_logic;
    rref_done_i         :  in std_logic;
    -- column memory
    init_o              : out std_logic;
    en_o                : out std_logic_vector(N-1 downto 0);
    we_o                : out std_logic_vector(N-1 downto 0);
    swap_o              : out std_logic;
    -- pivot search
    start_search_o      : out std_logic;
    col_mask_en_o       : out std_logic;
    col_mask_ld_o       : out std_logic;
    valid_pivot_i       :  in std_logic;
    -- row arithmetic
    rescale_pivot_row_o : out std_logic;
    new_pivot_o         : out std_logic
  );

end rref_controller;

architecture behavioral of rref_controller is

  type state_t is (S_INIT,        S_SEARCH,  S_SWAP,   S_RPR,    S_STALL, S_START_SEARCH,
                   S_REDUCE_ROWS, S_DONE);
  signal state_r : state_t;
  signal state_c : state_t;

begin

  process(clk_i)
  begin
    if (rising_edge(clk_i)) then
      if (rst_i = '1') then
        state_r <= S_INIT;
      else
        state_r <= state_c;
      end if;
    end if;
  end process;

  -- next state logic
  process(all)
  begin
    state_c             <= state_r;
    row_en_o            <= '0';
    row_ld_o            <= '0';
    row_to_reduce_en_o  <= '0';
    row_to_reduce_ld_o  <= '0';
    init_o              <= '0';
    en_o                <= (others => '1');
    we_o                <= (others => '0');
    swap_o              <= '0';
    start_search_o      <= '0';
    col_mask_en_o       <= '0';
    col_mask_ld_o       <= '0';
    rescale_pivot_row_o <= '0';
    done_o              <= '0';
    new_pivot_o         <= '0';

    case state_r is
      when S_INIT =>
        init_o        <= '1';
        en_o          <= (others => '1');
        col_mask_ld_o <= '1';
        if ((vld_i = '1') and (last_i = '1')) then
          row_en_o <= '1';
          if (row_last_i = '1') then
            state_c <= S_SEARCH;
          end if;
        end if;

      when S_SEARCH =>
        if (valid_pivot_i = '1') then
          swap_o             <= '1';
          row_to_reduce_en_o <= '1';
          col_mask_en_o      <= '1';
          -- we_o     <= (others => '1');
          state_c            <= S_SWAP;
        end if;

        if (rref_done_i = '1') then
          if (wr_row_id_z_i = '1' or row_last_i = '1') then --doubt
            we_o        <= (others => '0');
            state_c <= S_DONE;
          end if;
        end if;

      when S_SWAP =>
        new_pivot_o <= '1';
        state_c <= S_RPR;

      when S_RPR =>
        rescale_pivot_row_o <= '1';
        row_en_o            <= '1';
        we_o     <= (others => '1');
        state_c             <= S_STALL;

      when S_STALL =>
        state_c             <= S_START_SEARCH;

      when S_START_SEARCH =>
        start_search_o <= '1';
        row_en_o       <= '1';
        state_c        <= S_REDUCE_ROWS;

        -- we_o     <= (others => '1');

      when S_REDUCE_ROWS =>
        row_en_o <= '1';
        we_o     <= (others => '1');
        if (row_to_reduce_z_i /= '1') then
          row_ld_o <= '1';
        end if;

        if (row_z_i = '1') then
          we_o        <= (others => '1');
          state_c     <= S_SEARCH;
        end if;



      when S_DONE =>
        done_o <= '1';
        state_c <= S_INIT;
    end case;
  end process;

end behavioral;
