library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.util_pkg.all;
use work.mayo_pkg.all;

entity sig_gen is
    generic (
        w            : positive := 8;
        nibble       : positive := 4;
        param_n      : positive := 86;
        param_o      : positive := 8;
        param_k      : positive := 10;
        param_d      : positive := param_n - param_o;
        d_read_bits  : positive := param_d * nibble;
        salt_bytes   : positive := 24;
        sig_size : positive := ((param_n*param_k + 2*salt_bytes + 15) / 16) * 16;
        WR_NIBBLES : positive := 1   -- rtl: row-write divisor (1 = original 1-cycle write); lutram: nibbles/cycle (<=16)
    );
    port (
        clk      : in  std_logic;
        reset    : in  std_logic;
        calc     : in  std_logic;
        done     : out std_logic;

        -- O-matrix read interface (from esk_decode_memory)
        o_addr      : out std_logic_vector(clog2(param_o)-1 downto 0);
        o_data      : in  std_logic_vector(param_d*nibble-1 downto 0);

        -- x-data input (from solution memory)
        x_data      : in  std_logic_vector(param_o*param_k*nibble-1 downto 0);

        -- v-data read interface (from vr_expand_memory)
        v_addr      : out std_logic_vector(nibble-1 downto 0);
        v_data      : in  std_logic_vector(param_d*nibble-1 downto 0);

        salt        :  in  std_logic_vector(salt_bytes*w-1 downto 0);

        -- signature output interface
        sig_addr    : in std_logic_vector(clog2(sig_size/16)-1 downto 0);
        sig_data    : out std_logic_vector(16*nibble-1 downto 0)
    );
end sig_gen;

architecture rtl of sig_gen is

    constant zero_pad : integer := is_odd(param_k*param_n);
    constant WR_CHUNK    : positive := (param_n + WR_NIBBLES - 1) / WR_NIBBLES; 
    constant N_WR_CHUNKS : positive := (param_n + WR_CHUNK - 1) / WR_CHUNK; 

    type sig_word_array is array (0 to sig_size-1) of std_logic_vector(nibble-1 downto 0);
    signal s_words : sig_word_array := (others => (others => '0'));

    signal encoded_vector : std_logic_vector(16*nibble-1 downto 0);
    signal vOxx_reg : std_logic_vector(param_n*nibble-1 downto 0);
    signal salt_dec : std_logic_vector(salt_bytes*w-1 downto 0);

    signal i : unsigned(nibble-1 downto 0);
    signal j : unsigned(clog2(param_o)-1 downto 0);
    signal c : integer range 0 to N_WR_CHUNKS-1 := 0;

    signal x_i : std_logic_vector(param_o*nibble-1 downto 0);
    signal x_j : std_logic_vector(nibble-1 downto 0);
    signal x_index, base_x_index : integer range 0 to param_o*param_k-1;
    signal Ox_reg, vOx_reg, Ox_temp_reg : std_logic_vector(d_read_bits-1 downto 0);
    
    signal zi, zj, zc : std_logic;
    signal Ei, Ej, Ec : std_logic;

    signal Li, Lj, Lvo, Lc : std_logic;
    signal wr, wro, wr2 : std_logic;

    type state_type is (IDLE, S1, S2, S3, OK);
    signal state_reg, state_next : state_type := IDLE;


begin
    o_addr <= std_logic_vector(j);
    v_addr <= std_logic_vector(i);

    base_x_index <= param_o * to_integer(i);
    x_index <= base_x_index + to_integer(j);

    x_i <= x_data(x_data'length - 1 - base_x_index * nibble downto x_data'length - (base_x_index+param_o) * nibble);
    x_j <= x_data(x_data'length-1 - x_index*nibble downto x_data'length - (x_index+1)*nibble);

    vOx_reg <= v_data xor Ox_reg;
    vOxx_reg <= vOx_reg & x_i;

    encode_vector_inst: entity work.decode_vector
        generic map(
            nibble_count => 16,
            nibble => nibble,
            reverse => false
        )
        port map(
            a => encoded_vector,
            result => sig_data
        );

    encode_vector_inst2: entity work.decode_vector
        generic map(
            nibble_count => 2*salt_bytes,
            nibble => nibble,
            reverse => false
        )
        port map(
            a => salt,
            result => salt_dec
        );

    s_reg_proc : process(clk)
        variable idx : integer;
        variable idx2 : integer;
    begin
        if rising_edge(clk) then
            if wr = '1' then
                idx := to_integer(i);
                if idx < param_k then
                    for cc in 0 to WR_CHUNK-1 loop
                        if (c*WR_CHUNK + cc) < param_n then
                            s_words((idx*param_n) + c*WR_CHUNK + cc) <=
                                vOxx_reg(vOxx_reg'length - 1 - ((c*WR_CHUNK+cc) * nibble)
                                  downto vOxx_reg'length - ((c*WR_CHUNK+cc + 1) * nibble));
                        end if;
                    end loop;
                end if;
            end if;

            if wr2 = '1' then
                idx2 := param_k;
                if zero_pad = 1 then
                    s_words(idx2 * param_n) <= (others => '0');
                end if;
                for n in 0 to 2*salt_bytes-1 loop
                    s_words((idx2 * param_n) + n + zero_pad) <= salt_dec(2*salt_bytes*nibble - 1 - (n * nibble) downto 2*salt_bytes*nibble - ((n + 1) * nibble));
                end loop;
            end if;
            if Lvo = '1' then
                Ox_reg <= (others => '0');
            elsif wro = '1' then
                Ox_reg <= Ox_reg xor Ox_temp_reg;
            end if;
        end if;
    end process;

    counterI: process(clk)
    begin
        if rising_edge(clk) then
            if Li = '1' then
                i <= (others => '0');
            elsif Ei = '1' then
                i <= i + 1;
            end if;    
        end if;
    end process;

    counterJ: process(clk)
    begin
        if rising_edge(clk) then
            if Lj = '1' then
                j <= (others => '0');
            elsif Ej = '1' then
                j <= j + 1;
            end if;    
        end if;
    end process;

    counterC: process(clk)
    begin
        if rising_edge(clk) then
            if Lc = '1' then
                c <= 0;
            elsif Ec = '1' then
                c <= c + 1;
            end if;
        end if;
    end process;

    mul_array_inst : entity work.mul_gf16_array
        generic map(
            m => param_d,
            nibble => nibble
        )
        port map(
            input_data => o_data,
            a => x_j,
            result => Ox_temp_reg
        );

    reg: process(clk, reset)
    begin
        if reset = '1' then
            state_reg <= IDLE;
        elsif rising_edge(clk) then
            state_reg <= state_next;
        end if;
    end process;

    process(state_reg, calc, zi, zj, zc)
    begin
        done <= '0';
        Li <= '0'; 
        Lj <= '0'; 
        Lvo <= '0';
        Lc <= '0';

        Ei <= '0'; 
        Ej <= '0'; 
        Ec <= '0';

        wr <= '0';
        wro <= '0';
        wr2 <= '0';
        state_next <= state_reg;

        case state_reg is
            when IDLE =>
                Li <= '1';
                Lj <= '1';
                if calc = '1' then
                    wr2 <= '1';
                    state_next <= S1;
                end if;
            when S1 =>
                Lvo <= '1';
                state_next <= S2;
            when S2 =>
                wro <= '1';
                if zj = '0' then
                    Ej <= '1';
                    state_next <= S2;
                else
                    state_next <= S3;
                end if;
            when S3 =>
                wr <= '1';
                if zc = '0' then
                    Ec <= '1';
                    state_next <= S3;
                else
                    Lc <= '1';
                    if zi = '0' then
                        Ei <= '1';
                        Lj <= '1';
                        state_next <= S1;
                    else
                        state_next <= OK;
                    end if;
                end if;

            when OK =>
                done <= '1';
                if calc = '0' then
                    state_next <= IDLE;
                end if;

            when others =>
                state_next <= IDLE;
        end case;
    end process;


    zi <= '1' when i = to_unsigned(param_k-1, nibble) else '0';
    zj <= '1' when j = to_unsigned(param_o-1, j'length) else '0';
    zc <= '1' when c = N_WR_CHUNKS-1 else '0';


    gen_sig_words : for n in 0 to 15 generate
        encoded_vector(sig_data'length - 1 - (n * nibble) downto sig_data'length - ((n + 1) * nibble)) <=
            s_words((to_integer(unsigned(sig_addr)) * 16) + n);
    end generate;

end rtl;


architecture lutram of sig_gen is

    constant zero_pad   : integer := is_odd(param_k*param_n);
    constant N_WORDS    : integer := sig_size / 16;
    constant SALT_NIB   : integer := 2*salt_bytes;
    constant SALT_LEN   : integer := zero_pad + SALT_NIB;   
    constant F          : integer := WR_NIBBLES;            
    constant ACC_NIB    : integer := 16 + F;               
    constant ACC_W      : integer := ACC_NIB * nibble;

    -- distributed RAM: async read, sync write
    type word_ram_t is array (0 to N_WORDS-1) of std_logic_vector(16*nibble-1 downto 0);
    signal ram : word_ram_t := (others => (others => '0'));
    attribute ram_style : string;
    attribute ram_style of ram : signal is "distributed";

    signal encoded_vector : std_logic_vector(16*nibble-1 downto 0);
    signal vOxx_reg : std_logic_vector(param_n*nibble-1 downto 0);
    signal salt_dec : std_logic_vector(salt_bytes*w-1 downto 0);

    signal i : unsigned(nibble-1 downto 0);
    signal j : unsigned(clog2(param_o)-1 downto 0);

    signal x_i : std_logic_vector(param_o*nibble-1 downto 0);
    signal x_j : std_logic_vector(nibble-1 downto 0);
    signal x_index, base_x_index : integer range 0 to param_o*param_k-1;
    signal Ox_reg, vOx_reg, Ox_temp_reg : std_logic_vector(d_read_bits-1 downto 0);

    -- packer (barrel: F nibbles/cycle, emits 16-nibble words)
    signal acc      : std_logic_vector(ACC_W-1 downto 0) := (others => '0');
    signal fill     : integer range 0 to ACC_NIB := 0;   -- valid nibbles in acc (top-justified)
    signal wr_ptr   : integer range 0 to N_WORDS := 0;   -- terminal value N_WORDS after last word
    signal feed_data: std_logic_vector(F*nibble-1 downto 0);
    signal feed_cnt : integer range 0 to F;
    signal feed_en  : std_logic;
    signal ocnt     : integer range 0 to param_n;
    signal scnt     : integer range 0 to SALT_LEN;

    signal zi, zj, zo, zs, zf : std_logic;
    signal Ei, Ej, Eo, Es : std_logic;
    signal Li, Lj, Lvo, Lo, Ls, wro, pk_clr : std_logic;
    signal feed_row, feed_salt, feed_flush : std_logic;

    type state_type is (IDLE, S1, S2, S3, SALTS, FLUSH, OK);
    signal state_reg, state_next : state_type := IDLE;

begin
    o_addr <= std_logic_vector(j);
    v_addr <= std_logic_vector(i);

    base_x_index <= param_o * to_integer(i);
    x_index <= base_x_index + to_integer(j);

    x_i <= x_data(x_data'length - 1 - base_x_index*nibble downto x_data'length - (base_x_index+param_o)*nibble);
    x_j <= x_data(x_data'length - 1 - x_index*nibble downto x_data'length - (x_index+1)*nibble);

    vOx_reg  <= v_data xor Ox_reg;
    vOxx_reg <= vOx_reg & x_i;

    encode_vector_inst2: entity work.decode_vector
        generic map(
            nibble_count => SALT_NIB, 
            nibble => nibble, 
            reverse => false
        )
        port map(
            a => salt, 
            result => salt_dec
        );

    mul_array_inst : entity work.mul_gf16_array
        generic map(
            m => param_d, 
            nibble => nibble
        )
        port map(
            input_data => o_data, 
            a => x_j, 
            result => Ox_temp_reg
        );

    encoded_vector <= ram(to_integer(unsigned(sig_addr)));

    encode_vector_inst: entity work.decode_vector
        generic map(
            nibble_count => 16, 
            nibble => nibble, 
            reverse => false
        )
        port map(
            a => encoded_vector, 
            result => sig_data
        );

    assert WR_NIBBLES <= 16 report "sig_gen(lutram): WR_NIBBLES must be 1..16" severity failure;

    feed_comb : process(feed_row, feed_salt, feed_flush, ocnt, scnt, vOxx_reg, salt_dec, fill)
        variable fd  : std_logic_vector(F*nibble-1 downto 0);
        variable cnt : integer range 0 to F;
        variable pos : integer;
    begin
        fd  := (others => '0');
        cnt := 0;
        if feed_row = '1' then
            for p in 0 to F-1 loop
                if (ocnt + p) < param_n then
                    fd(F*nibble-1 - p*nibble downto F*nibble - (p+1)*nibble) :=
                        vOxx_reg(param_n*nibble-1 - (ocnt+p)*nibble downto param_n*nibble - (ocnt+p+1)*nibble);
                    cnt := cnt + 1;
                end if;
            end loop;
        elsif feed_salt = '1' then
            for p in 0 to F-1 loop
                pos := scnt + p;
                if pos < SALT_LEN then
                    if pos >= zero_pad then
                        fd(F*nibble-1 - p*nibble downto F*nibble - (p+1)*nibble) :=
                            salt_dec(SALT_NIB*nibble-1 - (pos-zero_pad)*nibble downto SALT_NIB*nibble - (pos-zero_pad+1)*nibble);
                    end if;   
                    cnt := cnt + 1;
                end if;
            end loop;
        elsif feed_flush = '1' then
            if fill /= 0 then           
                if (16 - fill) <= F then
                    cnt := 16 - fill;
                else
                    cnt := F;
                end if;
            end if;
        end if;
        feed_data <= fd;
        feed_cnt  <= cnt;
    end process;

    feed_en <= '1' when feed_cnt > 0 else '0';

    packer: process(clk)
        variable feed_top : std_logic_vector(ACC_W-1 downto 0);
        variable aligned  : std_logic_vector(ACC_W-1 downto 0);
        variable acc_v    : std_logic_vector(ACC_W-1 downto 0);
        variable fill_v   : integer range 0 to ACC_NIB;
    begin
        if rising_edge(clk) then
            if pk_clr = '1' then
                acc    <= (others => '0');
                fill   <= 0;
                wr_ptr <= 0;
            elsif feed_en = '1' then
                feed_top := (others => '0');
                feed_top(ACC_W-1 downto ACC_W - F*nibble) := feed_data;
                aligned  := std_logic_vector(shift_right(unsigned(feed_top), fill*nibble));
                acc_v    := acc or aligned;
                fill_v   := fill + feed_cnt;
                if fill_v >= 16 then
                    ram(wr_ptr) <= acc_v(ACC_W-1 downto F*nibble);  
                    wr_ptr <= wr_ptr + 1;
                    acc    <= acc_v(F*nibble-1 downto 0) & std_logic_vector(to_unsigned(0, 16*nibble));
                    fill   <= fill_v - 16;
                else
                    acc    <= acc_v;
                    fill   <= fill_v;
                end if;
            end if;
        end if;
    end process;

    Ox_proc: process(clk)
    begin
        if rising_edge(clk) then
            if Lvo = '1' then 
                Ox_reg <= (others => '0');
            elsif wro = '1' then 
                Ox_reg <= Ox_reg xor Ox_temp_reg;
            end if;
        end if;
    end process;

    counterI: process(clk)
    begin
        if rising_edge(clk) then
            if Li = '1' then
                i <= (others => '0');
            elsif Ei = '1' then
                i <= i + 1;
            end if;
        end if;
    end process;

    counterJ: process(clk)
    begin
        if rising_edge(clk) then
            if Lj = '1' then
                j <= (others => '0');
            elsif Ej = '1' then
                j <= j + 1;
            end if;
        end if;
    end process;

    counterO: process(clk)
    begin
        if rising_edge(clk) then
            if Lo = '1' then
                ocnt <= 0;
            elsif Eo = '1' then
                ocnt <= ocnt + F;
            end if;
        end if;
    end process;

    counterS: process(clk)
    begin
        if rising_edge(clk) then
            if Ls = '1' then
                scnt <= 0;
            elsif Es = '1' then
                scnt <= scnt + F;
            end if;
        end if;
    end process;

    reg: process(clk, reset)
    begin
        if reset = '1' then
            state_reg <= IDLE;
        elsif rising_edge(clk) then
            state_reg <= state_next;
        end if;
    end process;

    process(state_reg, calc, zi, zj, zo, zs, zf)
    begin
        done <= '0';
        Li  <= '0';
        Lj  <= '0';
        Lvo <= '0';
        Lo  <= '0';
        Ls  <= '0';

        Ei <= '0';
        Ej <= '0';
        Eo <= '0';
        Es <= '0';

        wro    <= '0';
        pk_clr <= '0';

        feed_row   <= '0';
        feed_salt  <= '0';
        feed_flush <= '0';
        state_next <= state_reg;

        case state_reg is
            when IDLE =>
                Li <= '1';
                Lj <= '1';
                Lo <= '1';
                Ls <= '1';
                pk_clr <= '1';
                if calc = '1' then
                    state_next <= S1;
                end if;
            when S1 =>
                Lvo <= '1';
                Lo  <= '1';
                state_next <= S2;
            when S2 =>
                wro <= '1';
                if zj = '0' then
                    Ej <= '1';
                    state_next <= S2;
                else
                    state_next <= S3;
                end if;
            when S3 =>
                feed_row <= '1';
                if zo = '0' then
                    Eo <= '1';
                    state_next <= S3;
                else
                    if zi = '0' then
                        Ei <= '1';
                        Lj <= '1';
                        state_next <= S1;
                    else
                        Ls <= '1';
                        state_next <= SALTS;
                    end if;
                end if;
            when SALTS =>
                feed_salt <= '1';
                if zs = '0' then
                    Es <= '1';
                    state_next <= SALTS;
                else
                    state_next <= FLUSH;
                end if;
            when FLUSH =>
                feed_flush <= '1';
                if zf = '1' then
                    state_next <= OK;
                else
                    state_next <= FLUSH;
                end if;
            when OK =>
                done <= '1';
                if calc = '0' then 
                    state_next <= IDLE;
                end if;
            when others =>
                state_next <= IDLE;
        end case;
    end process;

    zi <= '1' when i = to_unsigned(param_k-1, nibble) else '0';
    zj <= '1' when j = to_unsigned(param_o-1, j'length) else '0';
    zo <= '1' when (ocnt + F) >= param_n  else '0';  
    zs <= '1' when (scnt + F) >= SALT_LEN else '0';  
    zf <= '1' when fill = 0 else '0';                

end lutram;
