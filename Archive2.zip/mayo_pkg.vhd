library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

package mayo_pkg is
    constant MAYO_W : positive := 8;
    constant MAYO_NIBBLE : positive := 4;

    type mayo_params_t is record
        m : positive;
        n : positive;
        o : positive;
        k : positive;
        salt_bytes : positive;
        digest_bytes : positive;
        pk_seed_bytes : positive;
    end record;
    type fx_lookup_type is array(0 to 4) of STD_LOGIC_VECTOR(3 downto 0);
    type int_lut_t is array (natural range <>) of integer;
    function get_mayo_params(version: positive; set : positive) return mayo_params_t;
    function shn(din : std_logic_vector; n : natural; nibble : positive) return std_logic_vector;
    function calc_width(n : positive; word_nibbles : positive) return positive;
    function get_fx_lookup_table(m : positive) return fx_lookup_type;
    function is_power_of_2(n : positive) return integer;
    function word_size(n : positive; word_count : positive; nibble_count : positive) return positive;
    function get_shift_rom(n : positive; x_width : positive; word_nibbles : positive) return int_lut_t;
    function get_load_rom(n : positive; word_count : positive; x_width : positive; word_nibbles : positive) return int_lut_t;
    function is_odd(value : integer) return integer;
    function make_tri_lut(k : positive) return int_lut_t;
    function count_ones(v : std_logic_vector) return natural;
end package mayo_pkg;

package body mayo_pkg is

    function get_mayo_params(version: positive; set : positive) return mayo_params_t is
    begin
        if version = 1 then
            case set is
                when 1 => return (
                    m => 64, n => 66, o => 8, k => 9, salt_bytes => 24, digest_bytes => 32, pk_seed_bytes => 16
                );
                when 2 => return (
                    m => 64, n => 78, o => 18, k => 4, salt_bytes => 24, digest_bytes => 32, pk_seed_bytes => 16
                );
                when 3 => return (
                    m => 96, n => 99, o => 10, k => 11, salt_bytes => 32, digest_bytes => 48, pk_seed_bytes => 16
                );
                when 5 => return (
                    m => 128, n => 133, o => 12, k => 12, salt_bytes => 40, digest_bytes => 64, pk_seed_bytes => 16
                );
                when others => return (
                    m => 64, n => 78, o => 18, k => 4, salt_bytes => 24, digest_bytes => 32, pk_seed_bytes => 16
                );
            end case;
        elsif version = 2 then
            case set is
                when 1 => return (
                    m => 78, n => 86, o => 8, k => 10, salt_bytes => 24, digest_bytes => 32, pk_seed_bytes => 16
                );
                when 2 => return (
                    m => 64, n => 81, o => 17, k => 4, salt_bytes => 24, digest_bytes => 32, pk_seed_bytes => 16
                );
                when 3 => return (
                    m => 108, n => 118, o => 10, k => 11, salt_bytes => 32, digest_bytes => 48, pk_seed_bytes => 16
                );
                when 5 => return (
                    m => 142, n => 154, o => 12, k => 12, salt_bytes => 40, digest_bytes => 64, pk_seed_bytes => 16
                );
                when others => return (
                    m => 64, n => 81, o => 17, k => 4, salt_bytes => 24, digest_bytes => 32, pk_seed_bytes => 16
                );
            end case;
        else
            return (
                m => 64, n => 81, o => 17, k => 4, salt_bytes => 24, digest_bytes => 32, pk_seed_bytes => 16
            );
        end if;
    end function;

    function shn(din : std_logic_vector; n : natural; nibble : positive) return std_logic_vector is
        variable v : std_logic_vector(din'range);
    begin
        if n = 0 then
            v := din;
        else
            v := (n*nibble-1 downto 0 => '0') & din(din'high downto n*nibble);
        end if;
        return v;
    end function shn;

    function calc_width(n : positive; word_nibbles : positive) return positive is
        variable width : positive := 1;
        variable limit : positive := word_nibbles;
    begin
        while limit > 2 loop
            limit := limit / 2;
            width := width + 1;
        end loop;

        if (n mod 4) = 0 then
            return width - 2;
        elsif (n mod 2) = 0 then
            return width - 1;
        else
            return width;
        end if;
    end function calc_width;

    function is_odd(value : integer) return integer is
    begin
        if (value mod 2) = 0 then
            return 0;
        else
            return 1;
        end if;
    end function is_odd;

    function get_fx_lookup_table(m : positive) return fx_lookup_type is
    begin
        case m is
            when 78 =>
                return ("1000","0001","0001","0000","0000");
            when 64 =>
                return ("1000","0000","0010","1000","0000");
            when 108 =>
                return ("1000","0000","0001","0111","0000");
            when 142 =>
                return ("0100","0000","1000","0001","0000");
            when 96 =>
                return ("0010","0010","0000","0010","0000");
            when 128 =>
                return ("0100","1000","0000","0100","0010");
            when others =>
                return ("1000","0000","0010","1000","0000");
        end case;
    end function get_fx_lookup_table;

    function is_power_of_2(n : positive) return integer is
        variable u : unsigned(31 downto 0);
    begin
        u := to_unsigned(n, u'length);
        if (u and (u - 1)) = 0 then
            return n + 1;
        else
            return n;
        end if;
    end function is_power_of_2;

    function word_size(n : positive; word_count : positive; nibble_count : positive) return positive is
    begin
        if (n mod nibble_count) = 0 then
            return word_count;
        else
            return (word_count + 1);
        end if;
    end function word_size;

    function get_shift_rom(n : positive; x_width : positive; word_nibbles : positive) return int_lut_t is
        constant rom_size : integer := 2**x_width;
        constant step : integer := n mod word_nibbles;
        variable rom : int_lut_t(0 to rom_size-1) := (others => 0);
        variable rem_val : integer;
    begin
        if step = 0 then
            return rom;
        end if;

        for i in rom'range loop
            rem_val := (i * step) mod word_nibbles;
            if rem_val = 0 then
                rom(i) := word_nibbles;
            else
                rom(i) := rem_val;
            end if;
        end loop;

        return rom;
    end function get_shift_rom;

    function get_load_rom(n : positive; word_count : positive; x_width : positive; word_nibbles : positive) return int_lut_t is
        constant rom_size : integer := 2**x_width;
        constant step : integer := n mod word_nibbles;
        variable rom : int_lut_t(0 to rom_size-1) := (others => word_count-1);
        variable rem_val : integer;
    begin
        if step = 0 then
            rom := (others => word_count);
            return rom;
        end if;

        for i in rom'range loop
            rem_val := (i * step) mod word_nibbles;
            if rem_val /= 0 and rem_val <= step then
                rom(i) := word_count;
            end if;
        end loop;

        return rom;
    end function get_load_rom;

    function make_tri_lut(k : positive) return int_lut_t is
        variable lut : int_lut_t(0 to k-1);
        variable acc : integer := 0;
    begin
        for r in 0 to k-1 loop
            lut(r) := acc;
            acc := acc + (k - r);
        end loop;
        return lut;
    end function;

    function count_ones(v : std_logic_vector) return natural is
        variable c : natural := 0;
    begin
        for i in v'range loop
            if v(i) = '1' then
                c := c + 1;
            end if;
        end loop;
        return c;
    end function;

end package body mayo_pkg;
