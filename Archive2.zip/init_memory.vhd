library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.util_pkg.all;

entity init_memory is
    generic (
        w            : positive := 8;
        nibble       : positive := 4;
        param_n      : positive := 86;
        param_o      : positive := 8;
        param_k      : positive := 10;
        param_d      : positive := param_n - param_o
    );
    port(
        clk        : in  std_logic;
        reset      : in  std_logic;
        calc1       : in  std_logic;
        calc2       : in  std_logic;
        done       : out std_logic;
        mem_init1     : out  std_logic;
        mem_init2     : out  std_logic;
        mem_addr     : out  std_logic_vector(clog2(param_n)-1 downto 0)
    );

end init_memory;

architecture rtl of init_memory is

    signal l   : unsigned(w-1 downto 0);
    signal El : std_logic;
    signal Ll : std_logic;
    signal zn, zm : std_logic;

    type state_type is (IDLE, S1, S2, OK);
    signal state, next_state : state_type := IDLE;

begin

    mem_addr <= std_logic_vector(resize(l, clog2(param_n)));

    -- Counter l
    counter_l : process(clk)
    begin
        if rising_edge(clk) then
            if Ll = '1' then
                l <= (others => '0');
            elsif El = '1' then
                l <= l + 1;
            end if;
        end if;
    end process counter_l;

    fsm_proc : process(clk, reset)
    begin
        if reset = '1' then
            state <= IDLE;
        elsif rising_edge(clk) then
            state <= next_state;
        end if;
    end process;

    control_proc : process(state, zm, zn, calc1, calc2)
    begin
        Ll <= '0'; 
        El <= '0';
        mem_init1 <= '0';
        mem_init2 <= '0';
        done <= '0';
        next_state <= state;
        case state is
            when IDLE =>
                Ll <= '1';
                if calc1 = '1' then
                    next_state <= S1;
                elsif calc2 = '1' then
                    next_state <= S2;
                end if;
            
            when S1 =>
                mem_init1 <= '1';
                if zn = '0' then
                    El <= '1';
                    next_state <= S1;
                else
                    next_state <= OK;
                end if;

            when S2 =>
                mem_init2 <= '1';
                if zm = '0' then
                    El <= '1';
                    next_state <= S2;
                else
                    next_state <= OK;
                end if;

            when OK =>
                done <= '1';
                if calc1 = '0' and calc2 = '0' then
                    next_state <= IDLE;
                end if;
        end case;
    end process;

    zn <= '1' when l = to_unsigned(param_n-1, l'length) else '0';
    zm <= '1' when l = to_unsigned(param_d-1, l'length) else '0';

end rtl;
