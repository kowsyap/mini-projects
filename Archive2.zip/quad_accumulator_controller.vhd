library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity quad_accumulator_controller is
    port (
        clk     : in  std_logic;
        reset   : in  std_logic;
        calc    : in  std_logic;
        done    : out std_logic;
        verify  : in  std_logic;
        
        -- control outputs to datapath
        reduce_calc   : out std_logic;
        arr      : out std_logic;
        a_decode : out std_logic;
        a_reduce : out std_logic;
        a_reduce_calc : out std_logic;
        a_reduce_done : in std_logic;
       
        duo      : out std_logic;
        wra      : out std_logic;
        Ey       : out std_logic;
        Ei       : out std_logic;
        Ea       : out std_logic;
        Eo       : out std_logic;
        Li       : out std_logic;
        La       : out std_logic;
        Ly       : out std_logic;
        Lt       : out std_logic;
        Lo       : out std_logic;
        
        -- status inputs from datapath
        zi       : in  std_logic;
        za       : in  std_logic;
        zo       : in  std_logic;
        reduce_done  : in std_logic
    );
end quad_accumulator_controller;

architecture behavioral of quad_accumulator_controller is

    type state_type is (IDLE, S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, OK);
    signal state_reg, state_next : state_type := IDLE;
    type sub_state_type is (T0, T1, T1b, T2, T3, T4, T5);
    signal sub_state_reg, sub_state_next : sub_state_type := T0;

    signal a_decode_start, a_decode_done : std_logic;
    signal wra1, wra2 : std_logic;
    signal Lo1, Lo2 : std_logic;
    signal Eo1, Eo2 : std_logic;
    signal duo1, duo2 : std_logic;

begin

    reg: process(clk, reset)
    begin
        if reset = '1' then
            state_reg <= IDLE;
        elsif rising_edge(clk) then
            state_reg <= state_next;
        end if;
    end process;

    process(state_reg, calc, zi, za, zo, a_decode_done, reduce_done, a_reduce_done, verify)
    begin
        done <= '0';
        arr <= '0'; 
        wra1 <= '0';
        reduce_calc <= '0';
        a_reduce <= '0';
        a_reduce_calc <= '0';
        duo1 <= '0';

        Ei <= '0'; 
        Ea <= '0';
        Ey <= '0'; 

        Li <= '0'; 
        La <= '0'; 
        Ly <= '0';
        Lt <= '0';
        Lo1 <= '0';
        Eo1 <= '0';

        a_decode_start <= '0';
        
        state_next <= state_reg;

        case state_reg is
            when IDLE =>
                Li <= '1';
                if calc = '1' then
                    La <= '1';
                    if verify = '1' then
                        Ly <= '1';
                        state_next <= S2;
                    else
                        Lt <= '1';
                        state_next <= S1;
                    end if;
                end if;
            when S1 =>
                if verify = '1' then
                    state_next <= S2;
                else
                    a_decode_start <= '1';
                    if a_decode_done = '1' then
                        state_next <= S2;
                    end if; 
                end if;
            when S2 =>
                arr <= '1';
                if za = '0' then
                    Ea <= '1';
                    state_next <= S2;
                else
                    state_next <= S3;
                end if;
            when S3 =>
                if zi = '0' then
                    Ei <= '1';
                    La <= '1';
                    if verify = '1' then
                        state_next <= S2;
                    else
                        state_next <= S1;
                    end if;
                else
                    state_next <= S4;
                end if;
            when S4 =>
                state_next <= S5;
            when S5 =>
                Lo1 <= '1';
                reduce_calc <= '1';
                if reduce_done = '1' then
                    Ey <= '1';
                    if verify = '1' then
                        state_next <= OK;
                    else
                        state_next <= S6;
                    end if;
                end if;
            when S6 =>
                a_reduce <= '1';
                state_next <= S7;
            when S7 =>
                a_reduce <= '1';
                duo1 <= '1';
                state_next <= S8;
            when S8 =>
                a_reduce <= '1';
                a_reduce_calc <= '1';
                if a_reduce_done = '1' then
                    state_next <= S9;
                end if;
            when S9 =>
                a_reduce <= '1';
                wra1 <= '1';
                if zo = '0' then
                    Eo1 <= '1';
                    state_next <= S6;
                else
                    state_next <= S10;
                end if;
            when S10 =>
                a_reduce <= '1';
                state_next <= OK;
            when OK =>
                done <= '1';
                if calc = '0' then
                    state_next <= IDLE;
                end if;
        end case;
    end process;

    sub_state: process(clk, reset)
    begin
        if reset = '1' then
            sub_state_reg <= T0;
        elsif rising_edge(clk) then
            sub_state_reg <= sub_state_next;
        end if;
    end process;

    process(sub_state_reg, zo, a_decode_start)
    begin
        Lo2 <= '0';
        Eo2 <= '0';
        duo2 <= '0';
        wra2 <= '0';
        a_decode_done <= '0';
        sub_state_next <= sub_state_reg;
        case sub_state_reg is
            when T0 =>
                if a_decode_start = '1' then
                    Lo2 <= '1';
                    sub_state_next <= T1;
                end if;
            when T1 =>
                sub_state_next <= T1b;
            when T1b =>
                sub_state_next <= T2;
            when T2 =>
                wra2 <= '1';
                sub_state_next <= T3;
            when T3 =>
                duo2 <= '1';
                sub_state_next <= T4;
            when T4 =>
                wra2 <= '1';
                duo2 <= '1';
                if zo = '0' then
                    Eo2 <= '1';
                    sub_state_next <= T1;
                else
                    sub_state_next <= T5;
                end if;
            when T5 =>
                a_decode_done <= '1';
                if a_decode_start = '0' then
                    sub_state_next <= T0;
                end if;
        end case;
    end process;

    Lo <= Lo1 or Lo2;
    Eo <= Eo1 or Eo2;
    duo <= duo1 or duo2;
    wra <= wra1 or wra2;

    a_decode <= a_decode_start;

end behavioral;