library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.util_pkg.all;

entity reg_store is
  generic (
    DATA_WIDTH : integer := 64;    -- Bits per entry
    ADDR_WIDTH      : integer := 4    -- Number of entries
  );
  port (
    clk    : in  std_logic;
    reset  : in  std_logic;
    ld     : in  std_logic;
    we     : in  std_logic;
    waddr  : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    wdata  : in  std_logic_vector(DATA_WIDTH-1 downto 0);
    raddr  : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
    rdata  : out std_logic_vector(DATA_WIDTH-1 downto 0)
  );
end entity reg_store;

architecture rtl of reg_store is
  type reg_array_t is array (0 to 2**ADDR_WIDTH-1) of std_logic_vector(DATA_WIDTH-1 downto 0);
  signal regs : reg_array_t := (others => (others => '0'));

begin

  process(clk)
  begin
    if rising_edge(clk) then
      if ld = '1' then
        regs <= (others => (others => '0'));
      elsif we = '1' then
        regs(to_integer(unsigned(waddr))) <= wdata;
      end if;
    end if;
  end process;

  rdata <= regs(to_integer(unsigned(raddr)));

end architecture rtl;
