-------------------------------------------------------------------------------
--! @file       AES128P.vhd
--! @brief      Fully unrolled, pipelined AES-128 encryption core (1 block/cycle).
--!             G_SHARE_KEY=False (default): computes key schedule internally and
--!             exposes pipelined round keys on rkeys_o for sharing with slave instances.
--!             G_SHARE_KEY=True: accepts pre-pipelined round keys on rkeys_i and
--!             skips the internal key schedule (~1440 LUT saving per slave instance).
-------------------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use work.AES_pkg.all;

entity AES128P is
    generic (
        G_SBOX_LOGIC : boolean := False;
        G_SHARE_KEY  : boolean := False  -- True: accept pipelined round keys from a master instance
    );
    port(
        clk     : in  std_logic;
        rst     : in  std_logic;
        din     : in  std_logic_vector(AES_BLOCK_SIZE-1 downto 0);
        key     : in  std_logic_vector(AES_BLOCK_SIZE-1 downto 0);
        dout    : out std_logic_vector(AES_BLOCK_SIZE-1 downto 0);

        rkeys_i : in  std_logic_vector(AES_ROUNDS*AES_BLOCK_SIZE-1 downto 0);  -- G_SHARE_KEY=True : pipelined round keys from master
        rkeys_o : out std_logic_vector(AES_ROUNDS*AES_BLOCK_SIZE-1 downto 0);  -- G_SHARE_KEY=False: pipelined round keys for slaves

        start   : in  std_logic;
        en      : in  std_logic;
        done    : out std_logic
    );
end AES128P;

architecture rtl of AES128P is
    type t_state_array   is array (0 to AES_ROUNDS) of t_AES_state;
    type t_state_array_1 is array (1 to AES_ROUNDS) of t_AES_state;

    signal din_state   : t_AES_state;
    signal key_state   : t_AES_state;
    signal dout_state  : t_AES_state;
    signal state_reg   : t_state_array;
    signal valid       : std_logic_vector(0 to AES_ROUNDS);
    signal fdb         : t_state_array_1;
    signal dout_rnd    : t_state_array_1;

    -- Active pipelined round keys: driven by internal key schedule (master) or rkeys_i (slave)
    signal rkey_active : t_rkey_pipeline;
begin
    u_map_key : entity work.AES_map(structure)
        port map (ii => key, oo => key_state);
    u_map_din : entity work.AES_map(structure)
        port map (ii => din, oo => din_state);
    u_invmap  : entity work.AES_invmap(structure)
        port map (ii => dout_state, oo => dout);

    -- Round functions 1..AES_ROUNDS use pipelined round keys from rkey_active
    g_rounds : for i in 1 to AES_ROUNDS generate
        u_round : entity work.AES_Round(basic)
            generic map (G_SBOX_LOGIC => G_SBOX_LOGIC)
            port map (
                din      => state_reg(i-1),
                rkey     => rkey_active(i),
                dout_fdb => fdb(i),
                dout     => dout_rnd(i)
            );
    end generate;

    -- Key schedule: compute and pipeline internally (master), or accept externally (slave)
    g_key : if not G_SHARE_KEY generate
        signal rkey_reg  : t_rkey_pipeline;
        signal key_next  : t_state_array_1;
    begin
        g_keyexp : for i in 0 to AES_ROUNDS-1 generate
            constant C_ROUND : std_logic_vector(3 downto 0) :=
                std_logic_vector(to_unsigned(i, 4));
        begin
            u_keyexp : entity work.AES_KeyUpdate(key_size_128)
                generic map (G_SBOX_LOGIC => G_SBOX_LOGIC)
                port map (
                    round => C_ROUND,
                    ki    => rkey_reg(i),
                    ko    => key_next(i+1)
                );
        end generate;

        p_rkey : process(clk)
        begin
            if rising_edge(clk) then
                if en = '1' then
                    if start = '1' then
                        rkey_reg(0) <= key_state;
                    end if;
                    for i in 0 to AES_ROUNDS-1 loop
                        rkey_reg(i+1) <= key_next(i+1);
                    end loop;
                end if;
            end if;
        end process p_rkey;

        rkey_active <= rkey_reg;

        g_rkeys_out : for i in 1 to AES_ROUNDS generate
            u_rkey_invmap : entity work.AES_invmap(structure)
                port map (
                    ii => rkey_reg(i),
                    oo => rkeys_o(i*AES_BLOCK_SIZE-1 downto (i-1)*AES_BLOCK_SIZE)
                );
        end generate;
    else generate
        g_rkey_in : for i in 1 to AES_ROUNDS generate
            u_rkey_map : entity work.AES_map(structure)
                port map (
                    ii => rkeys_i(i*AES_BLOCK_SIZE-1 downto (i-1)*AES_BLOCK_SIZE),
                    oo => rkey_active(i)
                );
        end generate;
        rkeys_o <= rkeys_i;
    end generate g_key;

    -- State pipeline and valid shift register
    p_pipe : process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                valid <= (others => '0');
            else
                if en = '1' then
                    valid(0) <= start;
                    for i in 1 to AES_ROUNDS loop
                        valid(i) <= valid(i-1);
                    end loop;

                    -- Stage 0: AddRoundKey (XOR din with key in the same cycle as start)
                    if start = '1' then
                        for c in 0 to 3 loop
                            for r in 0 to 3 loop
                                state_reg(0)(r,c) <= din_state(r,c) xor key_state(r,c);
                            end loop;
                        end loop;
                    end if;

                    -- Propagate through round pipeline 
                    for i in 0 to AES_ROUNDS-2 loop
                        state_reg(i+1) <= fdb(i+1);
                    end loop;
                    state_reg(AES_ROUNDS) <= dout_rnd(AES_ROUNDS);
                end if;
            end if;
        end if;
    end process p_pipe;

    dout_state <= state_reg(AES_ROUNDS);
    done       <= valid(AES_ROUNDS);
end rtl;
