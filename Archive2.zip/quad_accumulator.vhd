library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.util_pkg.all;

entity quad_accumulator is
    generic (
        w            : positive := 8;
        nibble       : positive := 4;
        param_m      : positive := 78;
        param_n      : positive := 86;
        param_o      : positive := 8;
        param_k      : positive := 10;
        a_addr_width : positive := clog2(param_o);
        m_read_bits  : positive := param_m*nibble
    );
    port (
        clk      : in  std_logic;
        reset    : in  std_logic;
        calc     : in  std_logic;
        done     : out std_logic;
        verify   : in  std_logic;
        wra      : out std_logic;
        duo      : out std_logic;
        a_decode : out std_logic;
        a_reduce : out std_logic;
        a_reduce_calc : out std_logic;
        a_reduce_done : in std_logic;

        -- datapath interfaces
        v_addr     : out std_logic_vector(nibble-1 downto 0);
        mem_ram_addr : out std_logic_vector(clog2(param_n)-1 downto 0);
        a_addr       : out std_logic_vector(a_addr_width-1 downto 0);
        u_data       : in std_logic_vector((param_m + param_k - 1)*nibble - 1 downto 0);
        target       : in  std_logic_vector(param_m*nibble-1 downto 0);
        y            : out std_logic_vector(m_read_bits-1 downto 0)
    );
end quad_accumulator;

architecture structural of quad_accumulator is

    -- control signals
    signal arr, reduce_calc : std_logic;
    signal Ei, Ea, Ey, Eo  : std_logic;
    signal Li, La, Ly, Lo, Lt  : std_logic;
    -- status signals
    signal zi, za, zo, reduce_done : std_logic;

begin

    dp_inst : entity work.quad_accumulator_datapath
        generic map (
            w => w,
            nibble => nibble,
            param_m => param_m,
            param_n => param_n,
            param_o => param_o,
            param_k => param_k,
            a_addr_width => a_addr_width
        )
        port map (
            clk    => clk,
            reset  => reset,
            verify  => verify,
            v_addr => v_addr,
            mem_ram_addr => mem_ram_addr,
            u_data => u_data,
            a_addr => a_addr,
            target => target,
            arr => arr,
            reduce_calc => reduce_calc,
            a_decode => a_decode,

            Ei => Ei,
            Ea => Ea,
            Eo => Eo,
            Ey => Ey,
            Li => Li,
            La => La,
            Lo => Lo,
            Ly => Ly,
            Lt => Lt,
            zi => zi,
            za => za,
            zo => zo,
            reduce_done => reduce_done,
            y => y
        );

    ctrl_inst : entity work.quad_accumulator_controller
        port map (
            clk    => clk,
            reset  => reset,
            calc  => calc,
            done   => done,
            verify  => verify,
            arr => arr,
            reduce_calc => reduce_calc,
            duo => duo,
            a_decode => a_decode,
            a_reduce => a_reduce,
            a_reduce_calc => a_reduce_calc,
            a_reduce_done => a_reduce_done,
            wra => wra,
            Ey => Ey,
            Ei => Ei,
            Ea => Ea,
            Eo => Eo,
            Li => Li,
            La => La,
            Ly => Ly,
            Lt => Lt,
            Lo => Lo,
            zi => zi,
            za => za,
            zo => zo,
            reduce_done => reduce_done
        );

end structural;
