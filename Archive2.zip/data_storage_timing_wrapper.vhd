library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use work.util_pkg.all;
use work.mayo_pkg.all;

entity data_storage_timing_wrapper is
    generic (
        version : positive := 2;
        set_id  : positive := 5;
        parallel_factor : positive := 8;
        NUM_GROUPS : positive := 18
    );
    port (
        clk : in std_logic;
        reset : in std_logic;
        enable : in std_logic;
        ctrl : in std_logic_vector(23 downto 0);
        status : out std_logic_vector(31 downto 0)
    );
end data_storage_timing_wrapper;

architecture rtl of data_storage_timing_wrapper is
    constant P : mayo_params_t := get_mayo_params(version, set_id);
    constant w : positive := MAYO_W;
    constant nibble : positive := MAYO_NIBBLE;
    constant param_m : positive := P.m;
    constant param_n : positive := P.n;
    constant param_o : positive := P.o;
    constant param_k : positive := P.k;
    constant param_d : positive := P.n - P.o;
    constant m_read_bits : positive := param_m * nibble;
    constant r_bytes : positive := (param_k * param_o) / 2;

    signal ctr : unsigned(31 downto 0) := (others => '0');
    signal lfsr : std_logic_vector(31 downto 0) := x"1ACE_B00C";

    signal v_in : std_logic_vector(param_n*nibble-1 downto 0);
    signal input_data : std_logic_vector(m_read_bits-1 downto 0);
    signal input_data2 : std_logic_vector(m_read_bits-1 downto 0);
    signal v_out : std_logic_vector(param_d*nibble-1 downto 0);
    signal o_out : std_logic_vector(param_d*nibble-1 downto 0);
    signal u_out : std_logic_vector((param_m + param_k - 1)*nibble-1 downto 0);
    signal cfl_out : std_logic_vector(r_bytes*w-1 downto 0);

    signal v_wr_addr : std_logic_vector(nibble-1 downto 0);
    signal v_addr : std_logic_vector(nibble-1 downto 0);
    signal o_in : std_logic_vector(nibble-1 downto 0);
    signal o_addr : std_logic_vector(clog2(param_o)-1 downto 0);
    signal o_wr : std_logic_vector(param_o-1 downto 0);
    signal a_addr : std_logic_vector(clog2(param_o)-1 downto 0);
    signal mem_init_addr : std_logic_vector(clog2(param_n)-1 downto 0);
    signal cfl_grp : std_logic_vector(clog2(NUM_GROUPS)-1 downto 0);
    signal cfl_idx : std_logic_vector(clog2(parallel_factor)-1 downto 0);
    signal col_idx : std_logic_vector(clog2(param_n)-1 downto 0);
    signal row_idx : std_logic_vector(clog2(param_n)-1 downto 0);
    signal col_idx2 : std_logic_vector(clog2(param_n)-1 downto 0);
    signal row_idx2 : std_logic_vector(clog2(param_n)-1 downto 0);
    signal pv_addr : std_logic_vector(clog2(param_n)-1 downto 0);
    signal a_reduce_done : std_logic;
    signal status_reg : std_logic_vector(31 downto 0) := (others => '0');

    attribute keep : string;
    attribute keep of v_out : signal is "true";
    attribute keep of o_out : signal is "true";
    attribute keep of u_out : signal is "true";
    attribute keep of cfl_out : signal is "true";

    function fold32(vec : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(31 downto 0) := (others => '0');
    begin
        for i in 0 to vec'length-1 loop
            result(i mod 32) := result(i mod 32) xor vec(i);
        end loop;
        return result;
    end function;

begin
    counter_proc : process(clk)
        variable feedback : std_logic;
        variable status_next : std_logic_vector(31 downto 0);
    begin
        if rising_edge(clk) then
            if reset = '1' then
                ctr <= (others => '0');
                lfsr <= x"1ACE_B00C";
                status_reg <= (others => '0');
            elsif enable = '1' then
                ctr <= ctr + 1;
                feedback := lfsr(31) xor lfsr(21) xor lfsr(1) xor lfsr(0);
                lfsr <= lfsr(30 downto 0) & feedback;
                status_next := fold32(v_out) xor fold32(o_out) xor fold32(u_out) xor fold32(cfl_out);
                status_next(0) := status_next(0) xor a_reduce_done;
                status_reg <= status_next;
            end if;
        end if;
    end process;

    gen_v_in : for i in 0 to v_in'length-1 generate
    begin
        v_in(i) <= lfsr(i mod 32);
    end generate;

    gen_input_data : for i in 0 to input_data'length-1 generate
    begin
        input_data(i) <= lfsr((i + 5) mod 32) xor ctr(i mod 32);
        input_data2(i) <= lfsr((i + 13) mod 32) xor not ctr((i + 7) mod 32);
    end generate;

    v_wr_addr <= std_logic_vector(resize(ctr, v_wr_addr'length));
    v_addr <= std_logic_vector(resize(ctr(7 downto 0), v_addr'length));
    o_in <= std_logic_vector(ctr(o_in'length-1 downto 0));
    o_addr <= std_logic_vector(resize(ctr, o_addr'length));
    a_addr <= std_logic_vector(resize(ctr(11 downto 0), a_addr'length));
    mem_init_addr <= std_logic_vector(resize(ctr, mem_init_addr'length));
    cfl_grp <= std_logic_vector(resize(ctr, cfl_grp'length));
    cfl_idx <= std_logic_vector(resize(ctr, cfl_idx'length));
    col_idx <= std_logic_vector(resize(ctr, col_idx'length));
    row_idx <= std_logic_vector(resize(ctr(15 downto 0), row_idx'length));
    col_idx2 <= std_logic_vector(resize(ctr(23 downto 0), col_idx2'length));
    row_idx2 <= std_logic_vector(resize(ctr(31 downto 8), row_idx2'length));
    pv_addr <= std_logic_vector(resize(ctr(20 downto 0), pv_addr'length));

    gen_o_wr : for i in 0 to param_o-1 generate
    begin
        o_wr(i) <= ctrl(23) when o_addr = std_logic_vector(to_unsigned(i, o_addr'length)) else '0';
    end generate;

    storage_inst : entity work.data_storage
        generic map (
            w => w,
            nibble => nibble,
            param_m => param_m,
            param_n => param_n,
            param_o => param_o,
            param_k => param_k,
            param_d => param_d,
            m_read_bits => m_read_bits,
            r_bytes => r_bytes,
            parallel_factor => parallel_factor,
            NUM_GROUPS => NUM_GROUPS
        )
        port map (
            clk => clk,
            reset => reset,
            calc => ctrl(0),
            signing => ctrl(1),

            v_wr => ctrl(2),
            v_in => v_in,
            v_out => v_out,
            v_wr_addr => v_wr_addr,
            v_addr => v_addr,

            o_in => o_in,
            o_out => o_out,
            o_addr => o_addr,
            o_wr => o_wr,

            a_addr => a_addr,
            a_wr => ctrl(3),
            a_reduce => ctrl(4),
            a_reduce_calc => ctrl(5),
            a_reduce_done => a_reduce_done,
            a_cfl => ctrl(6),

            m_mem_init => ctrl(7),
            a_mem_init => ctrl(8),
            mem_init_addr => mem_init_addr,

            cfl_load => ctrl(9),
            cfl_extra => ctrl(10),
            cfl_grp => cfl_grp,
            cfl_idx => cfl_idx,

            m_mode => ctrl(11),
            l_mode => ctrl(12),
            pv_load => ctrl(13),
            lv_load => ctrl(14),
            pv_mem_load => ctrl(15),
            pv_wr => ctrl(16),
            lv_wr => ctrl(17),
            mem_wr => ctrl(18),
            l_wr => ctrl(19),
            po_mode => ctrl(20),
            a_decode => ctrl(21),
            duo => ctrl(22),

            input_data => input_data,
            input_data2 => input_data2,
            col_idx => col_idx,
            row_idx => row_idx,
            col_idx2 => col_idx2,
            row_idx2 => row_idx2,
            pv_addr => pv_addr,

            u_out => u_out,
            cfl_out => cfl_out
        );

    status <= status_reg;
end rtl;
