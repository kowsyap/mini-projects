library ieee;
use ieee.std_logic_1164.all;

entity repeat_bus is
    generic (
        SLICE_WIDTH : positive := 8;
        REPEAT_COUNT : positive := 4
    );
    port (
        din  : in  std_logic_vector(SLICE_WIDTH-1 downto 0);
        dout : out std_logic_vector(SLICE_WIDTH*REPEAT_COUNT-1 downto 0)
    );
end repeat_bus;

architecture rtl of repeat_bus is
begin
    gen_rep : for i in 0 to REPEAT_COUNT-1 generate
        dout((i+1)*SLICE_WIDTH-1 downto i*SLICE_WIDTH) <= din;
    end generate;
end rtl;
