-------------------------------------------------------------------------------
--! @file       AES_TB.vhd
--! @brief      Simple testbench for AES
-------------------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.AES_pkg.all;

entity AES_TB is
end entity;

architecture tb of AES_TB is
    constant C_CLK_PERIOD : time := 10 ns;
    constant C_RNDS       : integer := AES_ROUNDS;

    signal clk   : std_logic := '0';
    signal rst   : std_logic := '1';

    signal din   : std_logic_vector(AES_BLOCK_SIZE-1 downto 0) := (others => '0');
    signal key   : std_logic_vector(AES_BLOCK_SIZE-1 downto 0) := (others => '0');
    signal dout  : std_logic_vector(AES_BLOCK_SIZE-1 downto 0);
    signal start : std_logic := '0';
    signal ready : std_logic;
    signal done  : std_logic;

    constant C_KEY : std_logic_vector(AES_BLOCK_SIZE-1 downto 0) :=
        x"5E5A17F31B8CBED1EDCF410EBD624B32";

begin
    clk <= not clk after C_CLK_PERIOD/2;

    uut: entity work.AES(structure)
        generic map (
            G_RNDS       => C_RNDS,
            G_SBOX_LOGIC => False,
            G_OBUF       => False
        )
        port map (
            clk   => clk,
            rst   => rst,
            din   => din,
            key   => key,
            dout  => dout,
            start => start,
            ready => ready,
            done  => done
        );

    stim: process
    begin
        -- Reset
        rst <= '1';
        wait for 3*C_CLK_PERIOD;
        rst <= '0';

        -- Fixed key
        key <= C_KEY;
        report "AES_TB key = " & to_hstring(C_KEY);

        -- Test din values 0..10 (LSB contains the value)
        for i in 0 to 10 loop
            wait until rising_edge(clk);
            while ready /= '1' loop
                wait until rising_edge(clk);
            end loop;

            din <= (others => '0');
            din(31 downto 0) <= std_logic_vector(to_unsigned(i, 32));
            start <= '1';
            wait until rising_edge(clk);
            start <= '0';

            while done /= '1' loop
                wait until rising_edge(clk);
            end loop;

            report "din=" & integer'image(i) & " dout=" & to_hstring(dout);
        end loop;

        report "AES_TB complete.";
        wait;
    end process;

end architecture;
