LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.all;
USE IEEE.std_logic_textio.all;
use work.util_pkg.all;
LIBRARY std;
USE std.textio.all;

ENTITY tb_sig_decode IS
END tb_sig_decode;

ARCHITECTURE behavior OF tb_sig_decode IS

    constant w : integer := 8;
    constant nibble : integer := 4;
    constant sha_bits : integer := 64;

    -- mayo1
    -- constant param_n : integer := 86;
    -- constant param_k : integer := 10;
    -- constant salt_bytes : integer := 24;
    -- constant digest_bytes : integer := 32;
    -- constant digest_addr_width : integer := 5;
    -- FILE sig_inpFile: TEXT OPEN READ_MODE IS "input_gen_sig_mayo_1_test.txt";

    -- mayo2
    -- constant param_n : integer := 81;
    -- constant param_k : integer := 4;
    -- constant salt_bytes : integer := 24;
    -- constant digest_bytes : integer := 32;
    -- constant digest_addr_width : integer := 5;
    -- FILE sig_inpFile: TEXT OPEN READ_MODE IS "input_gen_sig_mayo_2_test.txt";

    -- mayo3
    -- constant param_n : integer := 118;
    -- constant param_k : integer := 11;
    -- constant salt_bytes : integer := 32;
    -- constant digest_bytes : integer := 48;
    -- constant digest_addr_width : integer := 5;
    -- FILE sig_inpFile: TEXT OPEN READ_MODE IS "input_gen_sig_mayo_3_test.txt";

    -- mayo5
    constant param_n : integer := 154;
    constant param_k : integer := 12;
    constant salt_bytes : integer := 40;
    constant digest_bytes : integer := 64;
    constant digest_addr_width : integer := 5;
    FILE sig_inpFile: TEXT OPEN READ_MODE IS "input_gen_sig_mayo_5_test.txt";

    constant nibble_count : integer := 16;

    signal clk : std_logic := '0';
    signal reset : std_logic := '0';
    signal calc : std_logic := '0';

    signal vector_input_ready : std_logic;
    signal vector_input : std_logic_vector(nibble_count*nibble-1 downto 0) := (others => '0');

    signal s_data : std_logic_vector(param_n*nibble-1 downto 0);
    signal s_addr : std_logic_vector(clog2(param_k)-1 downto 0);
    signal s_wr : std_logic;
    signal salt_wr_addr : std_logic_vector(digest_addr_width-1 downto 0);
    signal salt_wr_data : std_logic_vector(sha_bits-1 downto 0);
    signal salt_wr : std_logic;
    signal done : std_logic;

    constant clk_period : time := 10 ns;
    constant initial_delay : time := 100 ns;


BEGIN

    clk <= not clk after clk_period/2;

    reset <= '1' after initial_delay, '0' after initial_delay + clk_period;

    dut: entity work.sig_decoder
        generic map (
            nibble => nibble,
            w => w,
            param_n => param_n,
            param_k => param_k,
            sha_bits => sha_bits,
            salt_bytes => salt_bytes,
            digest_bytes => digest_bytes,
            digest_addr_width => digest_addr_width
        )
        port map (
            clk => clk,
            reset => reset,
            calc => calc,
            vector_input_ready => vector_input_ready,
            vector_input => vector_input,
            s_data => s_data,
            s_addr => s_addr,
            s_wr => s_wr,
            salt_wr_addr => salt_wr_addr,
            salt_wr_data => salt_wr_data,
            salt_wr => salt_wr,
            done => done
        );

    stim_proc : process
        variable bit_vec : std_logic_vector(nibble_count*nibble-1 downto 0);
        variable VectorLine: LINE;
        variable VectorValid: BOOLEAN;
    begin
        wait until reset = '0';
        calc <= '1';

        while not endfile(sig_inpFile) loop
            wait until rising_edge(clk);
            if vector_input_ready = '1' then
                readline(sig_inpFile, VectorLine);
                hread(VectorLine, bit_vec, good => VectorValid);
                next when not VectorValid;
                vector_input <= bit_vec;
            end if;
        end loop;

        wait until done = '1';
        wait for clk_period;
        calc <= '0';

        report "Simulation complete" severity note;
        wait;
    end process;

END behavior;
