LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.all;
USE IEEE.std_logic_textio.all;

LIBRARY std;
USE std.textio.all;
USE work.mayo_tb_pkg.all;

ENTITY mayo_sign_tb IS
END mayo_sign_tb;

ARCHITECTURE behavior OF mayo_sign_tb IS

    constant w: integer := 8;
    constant nibble:integer := 4;

    --ROUND 1
--     constant version : integer := 1;

    --ROUND 2
    constant version : integer := 2;

    --mayo1
--    constant set : integer := 1;

    --mayo2
--     constant set : integer := 2;

    --mayo3
--     constant set : integer := 3;

    --mayo5
     constant set : integer := 5;



    FILE csk_inpFile: TEXT OPEN READ_MODE IS csk_file(version, set);
    FILE msg_inpFile: TEXT OPEN READ_MODE IS msg_file(version, set);
    FILE sig_inpFile: TEXT OPEN READ_MODE IS sig_file(version, set);
    constant param_n : integer := param_n_tb(version, set);
    constant param_k : integer := param_k_tb(version, set);
    constant salt_bytes : integer := salt_bytes_tb(set);

    constant nibble_count : integer := 16;
    -- Inputs
    signal clk : std_logic := '0';
    signal reset : std_logic := '0';
    signal sig : std_logic_vector(nibble_count*nibble-1 downto 0) := (others => '0');
    signal sk : std_logic_vector(16*nibble-1 downto 0) := (others => '0');
    signal msg : std_logic_vector(nibble_count*nibble-1 downto 0) := (others => '0');
    signal msg_bytes : std_logic_vector(2*w-1 downto 0) := (others => '0');
    signal calc : std_logic := '0';
    signal sig_ready : std_logic := '0';
    signal sk_valid : std_logic := '0';
    signal msg_valid : std_logic := '0';

    -- Outputs
    signal sk_input_ready : std_logic;
    signal msg_input_ready : std_logic;
    signal done : std_logic;
    signal sig_read : std_logic;
    signal sig_last : std_logic;
    signal signature : std_logic_vector(16*nibble-1 downto 0);

    -- Clock period
    constant clk_period : time := 10 ns;
    constant initial_delay : time := 100 ns;

    signal csk_done : std_logic := '0';
    signal msg_done : std_logic := '0';
    signal sig_done : std_logic := '0';
    constant SIG_WORDS : integer := (param_n*param_k + 2*salt_bytes + 15) / 16;
    type sig_arr_t is array (0 to SIG_WORDS-1) of std_logic_vector(16*nibble-1 downto 0);
    signal sig_exp : sig_arr_t := (others => (others => '0'));
    signal sig_exp_count : integer range 0 to SIG_WORDS := 0;
    signal sig_exp_loaded : std_logic := '0';
    constant MODULE_COUNT : integer := 11;
    constant IDX_SIG_DEC  : integer := 0;
    constant IDX_DERIVE_T : integer := 1;
    constant IDX_SIG_GEN  : integer := 2;
    constant IDX_SOLUTION : integer := 3;
    constant IDX_RREF     : integer := 4;
    constant IDX_CFL      : integer := 5;
    constant IDX_QUAD_ACC : integer := 6;
    constant IDX_EXPAND   : integer := 10;
    type module_cycle_array_t is array (0 to MODULE_COUNT-1) of natural;
    signal module_status : std_logic_vector(2*MODULE_COUNT-1 downto 0);
    signal module_cycles : module_cycle_array_t := (others => 0);
    signal module_active : std_logic_vector(MODULE_COUNT-1 downto 0) := (others => '0');

BEGIN

    -- Clock process definition
    clk <= not clk after clk_period/2;

    -- Uncomment the below code for Behavioral Simulation
    -- Comment out otherwise
    -- reset <= '1', '0' after clk_period;

    -- Uncomment the below code for Post-Synthesis and Post-Implementation Simulation
    -- Comment out otherwise
    reset <= '1' after initial_delay, '0' after initial_delay + clk_period;

    -- Instantiate the Design Under Test (DUT)
    dut: ENTITY work.mayo
    GENERIC MAP (
        set => set,
        round => version
    )
    PORT MAP (
        clk_i => clk,
        reset_i => reset,

        msg_bytes_i => msg_bytes,
        mode_i => '0',

        msg_valid_i => msg_valid,
        msg_ready_o => msg_input_ready,
        msg_data_i => msg,

        sig_verify_data_i => (others => '0'),
        sig_verify_valid_i => '0',
        sig_verify_ready_o => open,

        sk_data_i => sk,
        sk_valid_i => sk_valid,
        sk_ready_o => sk_input_ready,

        verify_ok_o => open,
        sig_gen_data_o => signature,
        sig_gen_ready_i => sig_ready,
        sig_gen_valid_o => sig_read,
        sig_gen_last_o => sig_last,

        calc_i => calc,
        done_o => done,
        module_status_o => module_status
    );

    module_cycle_counter : process(clk, reset)
    begin
        if reset = '1' then
            module_cycles <= (others => 0);
            module_active <= (others => '0');
        elsif rising_edge(clk) then
            for i in 0 to MODULE_COUNT-1 loop
                if module_status(MODULE_COUNT+i) = '1' or module_active(i) = '1' then
                    module_cycles(i) <= module_cycles(i) + 1;
                end if;
                if module_status(i) = '1' then
                    module_active(i) <= '0';
                elsif module_status(MODULE_COUNT+i) = '1' then
                    module_active(i) <= '1';
                end if;
            end loop;
        end if;
    end process;

    stim_proc_0 : process
        variable bit_vec : std_logic_vector(16*nibble-1 downto 0);
        variable VectorLine: LINE;
        variable VectorValid: BOOLEAN;
    begin
        sk_valid <= '0';
        wait until reset = '0';
        while not endfile(csk_inpFile) loop
            readline(csk_inpFile, VectorLine);
            hread(VectorLine, bit_vec, good => VectorValid);
            NEXT WHEN NOT VectorValid;
            sk <= bit_vec;
            sk_valid <= '1';
            loop
                wait until rising_edge(clk);
                exit when sk_input_ready = '1';
            end loop;
        end loop;
        sk_valid <= '0';
        csk_done <= '1';
        wait;
    end process;

    stim_proc_2 : process
        variable bit_vec : std_logic_vector(nibble_count*nibble-1 downto 0);
        variable VectorLine: LINE;
        variable VectorValid: BOOLEAN;
    begin
        msg_valid <= '0';
        wait until reset = '0';
        while not endfile(msg_inpFile) loop
            readline(msg_inpFile, VectorLine);
            hread(VectorLine, bit_vec, good => VectorValid);
            NEXT WHEN NOT VectorValid;
            msg <= bit_vec;
            msg_valid <= '1';
            loop
                wait until rising_edge(clk);
                exit when msg_input_ready = '1';
            end loop;
        end loop;
        msg_valid <= '0';
        msg_done <= '1';
        wait;
    end process;

    stim_proc_3 : process
        variable bit_vec : std_logic_vector(nibble_count*nibble-1 downto 0);
        variable VectorLine: LINE;
        variable VectorValid: BOOLEAN;
        variable idx : integer := 0;
    begin
        wait until reset = '0';
        while not endfile(sig_inpFile) loop
            readline(sig_inpFile, VectorLine);
            hread(VectorLine, bit_vec, good => VectorValid);
            next when not VectorValid;
            if idx < SIG_WORDS then
                sig_exp(idx) <= bit_vec;
                idx := idx + 1;
            end if;
        end loop;
        sig_exp_count <= idx;
        sig_exp_loaded <= '1';
        sig_done <= '1';
        wait;
    end process;

    stim_proc_4 : process
        variable rd_idx : integer := 0;
        variable msg_line : LINE;
        variable mismatch : boolean := false;
        variable start_time : time;
        variable end_time : time;
    begin
        wait until reset = '0';
        sig_ready <= '0';
        msg_bytes <= "0000000000100000";
        calc <= '1';
        start_time := now;
        report "calc=1 at " & time'image(start_time) severity note;
        wait for clk_period;
        wait until done = '1';
        end_time := now;
        report "done=1 at " & time'image(end_time) severity note;
        report "execution time = " & time'image(end_time - start_time) severity note;
        wait for clk_period/2;
        sig_ready <= '1';
        while rd_idx < sig_exp_count loop
            wait until rising_edge(clk);
            if sig_read = '1' and sig_ready = '1' then
                if signature /= sig_exp(rd_idx) then
                    msg_line := null;
                    write(msg_line, string'("Signature mismatch exp="));
                    hwrite(msg_line, sig_exp(rd_idx));
                    write(msg_line, string'(" got="));
                    hwrite(msg_line, signature);
                    report msg_line.all severity error;
                    mismatch := true;
                end if;
                if rd_idx = sig_exp_count-1 and sig_last /= '1' then
                    report "Missing sig_last on final signature word" severity error;
                    mismatch := true;
                elsif rd_idx /= sig_exp_count-1 and sig_last = '1' then
                    report "Unexpected sig_last before final signature word" severity error;
                    mismatch := true;
                end if;
                rd_idx := rd_idx + 1;
            end if;
        end loop;
        if not mismatch then
            report "Signature matches expected output" severity note;
        end if;
        report "Selected phase cycle counts: sigdec=" & integer'image(module_cycles(IDX_SIG_DEC)) &
               " expandSK=" & integer'image(module_cycles(IDX_EXPAND)) &
               " QuadAcc=" & integer'image(module_cycles(IDX_QUAD_ACC)) &
               " Derive-t=" & integer'image(module_cycles(IDX_DERIVE_T)) &
               " sigGen=" & integer'image(module_cycles(IDX_SIG_GEN)) &
               " samplesolution=" & integer'image(module_cycles(IDX_CFL) + module_cycles(IDX_RREF) + module_cycles(IDX_SOLUTION))
               severity note;
        sig_ready <= '0';
        calc <= '0';
        assert false report "Simulation complete" severity note;
        wait;
    end process;

END behavior;
