library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use IEEE.STD_LOGIC_TEXTIO.ALL;

library std;
use std.textio.all;

use work.mayo_tb_pkg.all;

entity mayo_accelerator_tb is
end entity mayo_accelerator_tb;

architecture behavior of mayo_accelerator_tb is
    constant tb_round : positive := 1;
    constant tb_set   : positive := 2;

    constant w            : positive := 8;
    constant nibble       : positive := 4;
    constant stream_width : positive := 16 * nibble;
    constant axi_data_width : integer := 32;
    constant axi_addr_width : integer := 4;

    constant ctrl_addr   : std_logic_vector(axi_addr_width-1 downto 0) := x"0";
    constant msglen_addr : std_logic_vector(axi_addr_width-1 downto 0) := x"4";
    constant status_addr : std_logic_vector(axi_addr_width-1 downto 0) := x"8";

    constant mode_sign   : std_logic := '0';
    constant mode_verify : std_logic := '1';
    constant run_mode    : std_logic_vector(1 downto 0) := "01"; -- 00 sign, 01 verify
    constant message_bytes : natural := 32;

    constant param_n : positive := param_n_tb(tb_round, tb_set);
    constant param_k : positive := param_k_tb(tb_round, tb_set);
    constant salt_bytes : positive := salt_bytes_tb(tb_set);
    constant sig_words : natural := (param_n * param_k + 2 * salt_bytes + 15) / 16;

    file csk_inpFile : text open read_mode is csk_file(tb_round, tb_set);
    file cpk_inpFile : text open read_mode is cpk_file(tb_round, tb_set);
    file msg_inpFile : text open read_mode is msg_file(tb_round, tb_set);
    file sig_inpFile : text open read_mode is sig_file(tb_round, tb_set);
    file sig_expFile : text open read_mode is sig_file(tb_round, tb_set);

    signal clk    : std_logic := '0';
    signal resetn : std_logic := '0';

    signal s_axi_awaddr  : std_logic_vector(axi_addr_width-1 downto 0) := (others => '0');
    signal s_axi_awprot  : std_logic_vector(2 downto 0) := (others => '0');
    signal s_axi_awvalid : std_logic := '0';
    signal s_axi_awready : std_logic;
    signal s_axi_wdata   : std_logic_vector(axi_data_width-1 downto 0) := (others => '0');
    signal s_axi_wstrb   : std_logic_vector((axi_data_width/8)-1 downto 0) := (others => '1');
    signal s_axi_wvalid  : std_logic := '0';
    signal s_axi_wready  : std_logic;
    signal s_axi_bresp   : std_logic_vector(1 downto 0);
    signal s_axi_bvalid  : std_logic;
    signal s_axi_bready  : std_logic := '0';
    signal s_axi_araddr  : std_logic_vector(axi_addr_width-1 downto 0) := (others => '0');
    signal s_axi_arprot  : std_logic_vector(2 downto 0) := (others => '0');
    signal s_axi_arvalid : std_logic := '0';
    signal s_axi_arready : std_logic;
    signal s_axi_rdata   : std_logic_vector(axi_data_width-1 downto 0);
    signal s_axi_rresp   : std_logic_vector(1 downto 0);
    signal s_axi_rvalid  : std_logic;
    signal s_axi_rready  : std_logic := '0';

    signal s_axis_tdata  : std_logic_vector(stream_width-1 downto 0) := (others => '0');
    signal s_axis_tvalid : std_logic := '0';
    signal s_axis_tlast  : std_logic := '0';
    signal s_axis_tready : std_logic;

    signal m_axis_tdata  : std_logic_vector(stream_width-1 downto 0);
    signal m_axis_tvalid : std_logic;
    signal m_axis_tlast  : std_logic;
    signal m_axis_tready : std_logic := '1';

    constant clk_period : time := 10 ns;

    procedure read_next_valid_word(
        file vec_file : text;
        variable word_out : out std_logic_vector(stream_width-1 downto 0);
        variable found : out boolean
    ) is
        variable vector_line : line;
        variable vector_valid : boolean;
    begin
        found := false;
        while not endfile(vec_file) loop
            readline(vec_file, vector_line);
            hread(vector_line, word_out, good => vector_valid);
            if vector_valid then
                found := true;
                exit;
            end if;
        end loop;
    end procedure;

    procedure axis_send_file(
        file vec_file : text;
        signal clk_s : in std_logic;
        signal tready_s : in std_logic;
        signal tdata_s : out std_logic_vector(stream_width-1 downto 0);
        signal tvalid_s : out std_logic;
        signal tlast_s : out std_logic
    ) is
        variable curr_word : std_logic_vector(stream_width-1 downto 0);
        variable next_word : std_logic_vector(stream_width-1 downto 0);
        variable have_curr : boolean;
        variable have_next : boolean;
    begin
        read_next_valid_word(vec_file, curr_word, have_curr);
        while have_curr loop
            read_next_valid_word(vec_file, next_word, have_next);
            tdata_s <= curr_word;
            tvalid_s <= '1';
            if have_next then
                tlast_s <= '0';
            else
                tlast_s <= '1';
            end if;
            loop
                wait until rising_edge(clk_s);
                exit when tready_s = '1';
            end loop;
            curr_word := next_word;
            have_curr := have_next;
        end loop;
        tvalid_s <= '0';
        tlast_s <= '0';
        tdata_s <= (others => '0');
    end procedure;

    procedure axi_write(
        constant addr : in std_logic_vector(axi_addr_width-1 downto 0);
        constant data : in std_logic_vector(axi_data_width-1 downto 0);
        signal clk_s : in std_logic;
        signal awaddr_s : out std_logic_vector(axi_addr_width-1 downto 0);
        signal awvalid_s : out std_logic;
        signal awready_s : in std_logic;
        signal wdata_s : out std_logic_vector(axi_data_width-1 downto 0);
        signal wvalid_s : out std_logic;
        signal wready_s : in std_logic;
        signal bready_s : out std_logic;
        signal bvalid_s : in std_logic
    ) is
    begin
        awaddr_s <= addr;
        wdata_s <= data;
        awvalid_s <= '1';
        wvalid_s <= '1';
        bready_s <= '1';

        loop
            wait until rising_edge(clk_s);
            exit when awready_s = '1' and wready_s = '1';
        end loop;

        awvalid_s <= '0';
        wvalid_s <= '0';

        -- bready_s <= '1';
        loop
            wait until rising_edge(clk_s);
            exit when bvalid_s = '1';
        end loop;
        wait until rising_edge(clk_s);
        bready_s <= '0';
    end procedure;

    procedure axi_read(
        constant addr : in std_logic_vector(axi_addr_width-1 downto 0);
        variable data : out std_logic_vector(axi_data_width-1 downto 0);
        signal clk_s : in std_logic;
        signal araddr_s : out std_logic_vector(axi_addr_width-1 downto 0);
        signal arvalid_s : out std_logic;
        signal arready_s : in std_logic;
        signal rready_s : out std_logic;
        signal rvalid_s : in std_logic;
        signal rdata_s : in std_logic_vector(axi_data_width-1 downto 0)
    ) is
    begin
        araddr_s <= addr;
        arvalid_s <= '1';
        rready_s <= '1';

        loop
            wait until rising_edge(clk_s);
            exit when arready_s = '1';
        end loop;
        arvalid_s <= '0';

        loop
            wait until rising_edge(clk_s);
            exit when rvalid_s = '1';
        end loop;
        data := rdata_s;
        wait until rising_edge(clk_s);
        rready_s <= '0';
    end procedure;
begin
    clk <= not clk after clk_period / 2;

    dut : entity work.mayo_accelerator
        generic map (
            round => tb_round,
            set => tb_set,
            C_S_AXI_DATA_WIDTH => axi_data_width,
            C_S_AXI_ADDR_WIDTH => axi_addr_width
        )
        port map (
            ACLK => clk,
            ARESETN => resetn,
            S_AXI_AWADDR => s_axi_awaddr,
            S_AXI_AWPROT => s_axi_awprot,
            S_AXI_AWVALID => s_axi_awvalid,
            S_AXI_AWREADY => s_axi_awready,
            S_AXI_WDATA => s_axi_wdata,
            S_AXI_WSTRB => s_axi_wstrb,
            S_AXI_WVALID => s_axi_wvalid,
            S_AXI_WREADY => s_axi_wready,
            S_AXI_BRESP => s_axi_bresp,
            S_AXI_BVALID => s_axi_bvalid,
            S_AXI_BREADY => s_axi_bready,
            S_AXI_ARADDR => s_axi_araddr,
            S_AXI_ARPROT => s_axi_arprot,
            S_AXI_ARVALID => s_axi_arvalid,
            S_AXI_ARREADY => s_axi_arready,
            S_AXI_RDATA => s_axi_rdata,
            S_AXI_RRESP => s_axi_rresp,
            S_AXI_RVALID => s_axi_rvalid,
            S_AXI_RREADY => s_axi_rready,
            S_AXIS_TDATA => s_axis_tdata,
            S_AXIS_TVALID => s_axis_tvalid,
            S_AXIS_TLAST => s_axis_tlast,
            S_AXIS_TREADY => s_axis_tready,
            M_AXIS_TDATA => m_axis_tdata,
            M_AXIS_TVALID => m_axis_tvalid,
            M_AXIS_TLAST => m_axis_tlast,
            M_AXIS_TREADY => m_axis_tready
        );

    stimulus_proc : process
        variable status_reg : std_logic_vector(axi_data_width-1 downto 0);
        variable ctrl_word : std_logic_vector(axi_data_width-1 downto 0);
    begin
        resetn <= '0';
        s_axis_tvalid <= '0';
        s_axis_tlast <= '0';
        m_axis_tready <= '1';
        wait for 100 ns;
        wait until rising_edge(clk);
        resetn <= '1';
        wait until rising_edge(clk);

        assert run_mode = "00" or run_mode = "01"
            report "Invalid run_mode. Use 00(sign) or 01(verify)."
            severity failure;

        axi_write(msglen_addr, std_logic_vector(to_unsigned(message_bytes, axi_data_width)),
                  clk, s_axi_awaddr, s_axi_awvalid, s_axi_awready,
                  s_axi_wdata, s_axi_wvalid, s_axi_wready, s_axi_bready, s_axi_bvalid);

        if run_mode = "00" then
            ctrl_word := (others => '0');
            ctrl_word(0) := '1';
            ctrl_word(1) := mode_sign;
            axi_write(ctrl_addr, ctrl_word, clk, s_axi_awaddr, s_axi_awvalid, s_axi_awready,
                      s_axi_wdata, s_axi_wvalid, s_axi_wready, s_axi_bready, s_axi_bvalid);
            report "sign: calc asserted, streaming CSK then MSG" severity note;

            axis_send_file(csk_inpFile, clk, s_axis_tready, s_axis_tdata, s_axis_tvalid, s_axis_tlast);
            axis_send_file(msg_inpFile, clk, s_axis_tready, s_axis_tdata, s_axis_tvalid, s_axis_tlast);

            loop
                axi_read(status_addr, status_reg, clk, s_axi_araddr, s_axi_arvalid, s_axi_arready,
                         s_axi_rready, s_axi_rvalid, s_axi_rdata);
                exit when status_reg(0) = '1';
            end loop;
            report "sign: done observed through AXI-Lite status" severity note;

            ctrl_word := (others => '0');
            axi_write(ctrl_addr, ctrl_word, clk, s_axi_awaddr, s_axi_awvalid, s_axi_awready,
                      s_axi_wdata, s_axi_wvalid, s_axi_wready, s_axi_bready, s_axi_bvalid);
            wait until rising_edge(clk);
        end if;

        if run_mode = "01" then
            ctrl_word := (others => '0');
            ctrl_word(0) := '1';
            ctrl_word(1) := mode_verify;
            axi_write(ctrl_addr, ctrl_word, clk, s_axi_awaddr, s_axi_awvalid, s_axi_awready,
                      s_axi_wdata, s_axi_wvalid, s_axi_wready, s_axi_bready, s_axi_bvalid);
            report "verify: calc asserted, streaming SIG then MSG then CPK" severity note;

            axis_send_file(sig_inpFile, clk, s_axis_tready, s_axis_tdata, s_axis_tvalid, s_axis_tlast);
            axis_send_file(msg_inpFile, clk, s_axis_tready, s_axis_tdata, s_axis_tvalid, s_axis_tlast);
            axis_send_file(cpk_inpFile, clk, s_axis_tready, s_axis_tdata, s_axis_tvalid, s_axis_tlast);

            loop
                axi_read(status_addr, status_reg, clk, s_axi_araddr, s_axi_arvalid, s_axi_arready,
                         s_axi_rready, s_axi_rvalid, s_axi_rdata);
                exit when status_reg(0) = '1';
            end loop;
            if status_reg(1) = '1' then
                report "verify: SUCCESS" severity note;
            else
                report "verify: FAIL" severity warning;
            end if;

            ctrl_word := (others => '0');
            axi_write(ctrl_addr, ctrl_word, clk, s_axi_awaddr, s_axi_awvalid, s_axi_awready,
                      s_axi_wdata, s_axi_wvalid, s_axi_wready, s_axi_bready, s_axi_bvalid);
        end if;

        wait for clk_period;
        report "Simulation complete" severity note;
        wait;
    end process;

    sink_proc : process
        variable l : line;
        variable exp_word : std_logic_vector(stream_width-1 downto 0);
        variable have_exp : boolean;
        variable out_count : natural := 0;
        variable mismatch : boolean := false;
    begin
        wait until resetn = '1';
        loop
            wait until rising_edge(clk);
            if m_axis_tvalid = '1' and m_axis_tready = '1' then
                read_next_valid_word(sig_expFile, exp_word, have_exp);
                if not have_exp then
                    report "Generated more signature words than expected" severity error;
                    mismatch := true;
                elsif m_axis_tdata /= exp_word then
                    l := null;
                    write(l, string'("Signature mismatch word "));
                    write(l, out_count);
                    write(l, string'(" exp="));
                    hwrite(l, exp_word);
                    write(l, string'(" got="));
                    hwrite(l, m_axis_tdata);
                    report l.all severity error;
                    mismatch := true;
                end if;

                l := null;
                hwrite(l, m_axis_tdata);
                if m_axis_tlast = '1' then
                    write(l, string'(" LAST"));
                    if out_count /= sig_words-1 then
                        report "M_AXIS_TLAST asserted before expected signature word count" severity error;
                        mismatch := true;
                    end if;
                    if not mismatch then
                        report "Generated signature matches expected output" severity note;
                    end if;
                    out_count := 0;
                    mismatch := false;
                else
                    out_count := out_count + 1;
                end if;
                writeline(output, l);
            end if;
        end loop;
    end process;
end architecture behavior;
