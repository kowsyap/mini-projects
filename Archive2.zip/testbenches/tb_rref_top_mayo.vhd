library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use work.util_pkg.all;

entity tb_rref_top_mayo is
end tb_rref_top_mayo;

architecture sim of tb_rref_top_mayo is
  constant N : integer := 81;
  constant K : integer := 78;
  constant Q : integer := 16;
  constant DATA_WIDTH : integer := 4;
  constant MEM_DEPTH : integer := ((K + 4) / 5) * 5;
  constant RD_ADDR_WIDTH : integer := ceil_div(N, 5) * clog2(MEM_DEPTH);

  signal clk_i : std_logic := '0';
  signal rst_i : std_logic := '1';
  signal vld_i : std_logic := '0';
  signal we_i : std_logic_vector(N-1 downto 0) := (others => '0');
  signal data_i : std_logic_vector((N*DATA_WIDTH)-1 downto 0) := (others => '0');
  signal last_i : std_logic := '0';
  signal col_tbl_addr_i : std_logic_vector(clog2(N)-1 downto 0) := (others => '0');
  signal col_tbl_we_i : std_logic := '0';
  signal col_tbl_data_i : std_logic_vector(clog2(N)-1 downto 0) := (others => '0');
  signal rd_addr_i : std_logic_vector(RD_ADDR_WIDTH-1 downto 0) := (others => '0');
  signal rd_en_i : std_logic := '0';
  signal data_o : std_logic_vector((N*DATA_WIDTH)-1 downto 0);
  signal pivot_col_list_o : std_logic_vector(N-1 downto 0);
  signal done_o : std_logic;

  type vec_arr_t is array (0 to K-1) of std_logic_vector((N*DATA_WIDTH)-1 downto 0);
  constant VECTORS : vec_arr_t := (
    0 => x"86d623bcec7e6ed522bd29fa1e7015b6b1c65015700ac25dd2d2a487abae60b5b8980c2aa4fd9cb07",
    1 => x"96f5f25931b2738b14c1e76705f3d612892e3cf914159843a63f17963e3ab1c84c9b2b6955689d642",
    2 => x"de04c41e23f0ae9a6a7bf5887e1ff27aece0c275ff33e57ef7a94afbd635b8118a64b7e36e39a4db2",
    3 => x"561777b508692997eff9e74f3a3ab952a1b3b60c79b2b8d628dba2f5925131d8d6985c28ed301c5a1",
    4 => x"5844ad6e1297b7ef4023bb69f14dfbf525dde1479f2b3f5d0534ca33441bf94158be739a455cd042e",
    5 => x"44efa202638ddaa68254b1db62e63eb6db8c7732c50614feed361db8c77be84616c5f1afee8c89ca6",
    6 => x"ad118397e97cac8c8f98321b49b29c1a3a3919d76cf74473d93f08f2e35e2aeba9866539ca1076fa2",
    7 => x"7f6d338381451fc242909d69957ea7e9bb403cae1077e6c8da72590614e268972c336778c7719ac32",
    8 => x"3c653d23a5dc7449eac654456b039f0088a8a98eaf2bb068ec14afb786680663bc05c81f453f07413",
    9 => x"324c650ed88e70678e983587232f990d4a8dc3afd1d7cf76afe420838cdff9c7047f56b6c2356d7d2",
    10 => x"11cdbcf9a403be0d5b8a5e3d671fb5e98a8365042d4d640c5e6a5a4fda1df3617cc3da6ccaec84528",
    11 => x"755e596fdbefbb77be9251fdfc7d6a4077fbfbaa1543ff53665578765909e62a89af8ff713b5f6525",
    12 => x"754673d5bb2c3dc2dab4047ef1dbdbfade23eecbf2fd0d2c0e7416a75ada2024883ddf3b0578879a7",
    13 => x"ef0862b5534a35c446f10352a8731ea9fa5253d9a079541336133f207d69088dc27d47562da15df4d",
    14 => x"eb82fce87200972ecfad37eb448ecbf0c37438bf055dc455ac7eb591ea4d16727874ee0f990b87d2b",
    15 => x"60242350d925bae7b00002c60fca752bd1456ff9d745bbbb7820f22f125b950a30c98a74f34202350",
    16 => x"7d24ffbdd33d079dd81f6a8f6d945847e09923e69d02017d6cf6bf9bfe5a3bd3caad2f91812ad2ac8",
    17 => x"4dc232faa4c0bce01c3738f051f79b553c9e79a0cc6cde7194106d85f77fd34a0c4adaa36e345b363",
    18 => x"d8d6763065074a50dbf22be16747d1bbb50b4548cf13ef73543ffd0146d40d901de92aaab41d0ec0b",
    19 => x"04bd473dd39992fa936e8a151a8b57b8a820f49e5ffda5ad28d6482120c87057e59a4179d3d433afe",
    20 => x"69bfc2dbf52dccf8b8cb3405e91b2484800dc22dfcd5593196fa3e32fcf914a91de37e2049575f87c",
    21 => x"66b6019119afa3b3edae6211c39df99b577ff33c5efaa4e527b00fe5e70c7064672ae1416347427d6",
    22 => x"a6f1a3abf85191f946824df86395efaecd1fea1592a516addbfc425db3222a19e7cd39e48796201b7",
    23 => x"703d1935cedfd8eae1e20f24f1fda9af83fe9a463db53ce5d0be57e619855fcad2914092f95341738",
    24 => x"b5aa062de60fa81aefe977f05bec91514c9ef8ea6e62b4683de9ffdc1b69c5e9ba3fe9b4410fb1fd9",
    25 => x"c1237a99900c32487cc0b8ab257329ad9865d50b37146438ae6c5dde3e8a4c86700ad6eeaadabf39e",
    26 => x"0a31a53a2a903e1f5efa960c06abcbf2e7ae02f2fff9bee6d2a31c7c0e2a94a978a02cbca55939b23",
    27 => x"d155d5cc11832bb600e5bc7a55f172398620068bfaa51df1a10b7e055f11cbb648b5b4c0f4c23f1f5",
    28 => x"b7f8f00af92621803a3d9a59a10b465dc06bf31c3e1e3d208fd43fec5788598074d6c87725b2b561d",
    29 => x"57cf657c3f1a2588aa72b341479a0e85418fe7882a13cce01d5f6ec6f57ca82f30d601391fc1eef8b",
    30 => x"e1dbaea5f2a59c5a9569b9eb824da9002dfa5465fad08d7d99fbf7539a2a920268010166a34e2c16c",
    31 => x"f515517299dd56847771f887c53ffea6d62fc213cd420a8162f7d5c5039616524873669459eb5f03b",
    32 => x"35870810087f7c52566a8a8a3b57c05bee1ea6691fee45c77c7c66ccd5f6a270470eb1bca6e77ce76",
    33 => x"201c6671465cd36660adba92572f0cafd48a9d0694ff21fa41339d6541efbb69bdf86c1576f070221",
    34 => x"b30d7b44f1c79f704f7688475e515e2840408a243e78101bfaec72acf3bf9fd58b26825909a698222",
    35 => x"a911aee7c7a6a43c6f7ffff0aa3135268e1210bea0845e2e74dacb2abb6b4d8af8e9592215ad891fb",
    36 => x"df548799a512200091ce84d1d713674b74d30109c92ddf71df5464b42533c50d9c1592c476eb69aff",
    37 => x"5556a295eb85a890882866686ee33d4d986a88cfa94203fef6bb1736e2a6bc9ec9210145e86854784",
    38 => x"4ad368cecb121364a8c8f10177102031a65cd93c32ff7ebfd2614ab83dc25c3663ba9963fa872ae28",
    39 => x"c3b21e32af08609df96543690760f2660f36be7fb495a5be94ee31e8903443365ac964b6a094d0ccc",
    40 => x"4f3a165869cdc7a626fea41e7853a21c04e12428c42db97dab8312525101cdc354271e87bc33086c1",
    41 => x"4fc7286bd3fe2c59dded763501e935fd789d64f51d494ac9dd5eafbe6ef336bc738510d5ebf5d1a34",
    42 => x"ddaeb362f3c1d5bd8de65678110890a13f630284ea1fe63468c32132d2000a371488240e3f8e994e4",
    43 => x"38a702e5b092be9c473f38111319d96fcca81df89b07b3b88a9a8180ec0ee4474658fd811326bd527",
    44 => x"6e45a7a06dca9cb383b075b0fcb8e2d9a97da1474fe2f29236439182c376c270beb0cbaf01cebd0e2",
    45 => x"a93589461d1fb3c7c66d0bce72c740f11844ef6f037e8819963523b80417a28cd581d9f7ef34d1e5f",
    46 => x"0b29d1e77593229b3cd381dc25764090d6393b333e5f6f4a3c487a10091c672c2f6cdadc4563f59c0",
    47 => x"771c0219e95a954137ddcbc587c56b514fc9dc1934bf8baa2a9305d591a043131c6563f87d1351c7b",
    48 => x"d2d6190849240214ed1c83662b5779515a174c9488b6cbe273abbf8e4f738ec963657a4f009d09b58",
    49 => x"1a6769060176831db1eb02d85fd60cdc4a10a9a979db3f853984c9a4c2abd7b722503a3f9bc7c1619",
    50 => x"d615d3ac25de58ceb1f1734cccf0f2737fdb8899d4143ae7310c0e8175644f878e0687d21c8bceac3",
    51 => x"e13b65010184134fbe05ae58a36e2194fd997872eb0a6d4cde9054357e6e14ce90c049bed8393b244",
    52 => x"6cc3bee7557489fe9f07cd974c607d97bab06c1448e1f272b43f020c3b96126acdac5b2eb4be25807",
    53 => x"b44a5d8559cbaadeedb8fc062122adc02596f5ea5068ffa9691c8eae93f55666c028bb106aabc858c",
    54 => x"cf3391c25ff23ea5dc64ae5dec9e57f23982b8bee8fa2fd319f7f66c01fc6423747bd9717de5d6da5",
    55 => x"7d0b645b82bcc26a10857ad978602bd7ad1ac52f03ad0368a911a9ce99d004839282e8d17b6a9301b",
    56 => x"c0d7a9a3964181a51d0233422da0c13c8ca2f8c610762357b52adcf32b6901ade57e19a3fe94721e6",
    57 => x"609cbe02ace613129ae48c0c805521269752ad10ac8b0a3643dc3ac259b2628590c43748a580c6016",
    58 => x"008533b18b6390d9ab1081e2261728fa9d84193c92595a19f51a59a807556037e29e5794dfee2960c",
    59 => x"a07e4cd4fe0dc57f366aca0715c60104db9bf12880e07de842ca53d4303f5b73c4b9ed59ff1feaa25",
    60 => x"824d18a40ef0a339834ba3ebbe03e00a348c0c177f1f46719df03aa3b41a830f7fd0d6820631893e8",
    61 => x"0e7b773e523ac6acdff40e3660d18d07044106f0d8a30e813b3f3792eedaab7d7a228a6a5b31c8bed",
    62 => x"bf4782627c9b6197b9720ad122a0cc12248eada6688ff4c8923346791d092b915b7b71f7a795825eb",
    63 => x"e171f34267bbf7f7420aaecb1df353ce78fab73169070dfa610738d22e0e3f261681b1fc59d8022a4",
    64 => x"65ecaf869c86bf987e81b276e4a2725511df81412f45db88e9cda060fdaf54739ed958b84cd684839",
    65 => x"2a5df6812a62f323bc4b619cf836b776441a1856fdde9b5c24bb651f81a9607497af9763349c589fb",
    66 => x"599df6fbb0f2d77e7c683580631f28a43e8f8de0b41f74c24b9025568fe835d1fdabbc0847c712394",
    67 => x"1d468bec4ed77d5a96c77d8973d327c56a2e1ed677c0f6937b17c16c4e4ee6ca0022c9db903e213ff",
    68 => x"2a8e19da5b55c084d7cf495675299beded4db528a523bb0479e722081c9e2452c8bfc5374b7b90bb1",
    69 => x"e1125c56b1de6e581b3c62ee3c6a948e8a289f7c1c9f4f490dd4313477860e52feabf0cb6bbbb4c61",
    70 => x"6a3f93fa2354af87adcdc1c4cc3fb11a18196037ce2d861ee5937b73abe883677fec1a6c2d436a1c1",
    71 => x"2b2ce57a08aed3f93d33b74730ffcd2a9f8869be267edcf4acffcd3ec196e44edda4fbf2b00ab73c5",
    72 => x"f5a3755b021db37d4d854aa18c1c4d8f604c776fe960f7eb2f1049b2ada774f25985fef07f598ee4a",
    73 => x"da598ecd3b18c4996e676546fdcb02c87a9a9aa976a3d4a7615b5f9e31fe95aa2ac797d18ae8dc1d9",
    74 => x"9d2f546796bcf3882059fbba211d5db52237795caafe4d14211e6a8592668c1bea8ae63374dd76223",
    75 => x"d661fd5375df97ec074a87e5e8a078c960f539c47bf8ef2d0c646c8baf499f8d1272172f239bf2140",
    76 => x"aa87e5c2017f48718a3c8018ee22e841f56649fe9a1a5eb76cec33b9dd68d2fcf0ff279a97ee7de54",
    77 => x"3bbedb2880a6881d52004eb708027022f7ae8381e4ea7586d6caa0dcd26b8eec89d676cfb2c2e45e9"
  );

begin
  clk_i <= not clk_i after 5 ns;

  dut : entity work.rref_top(structural)
    generic map(
      N => N,
      K => K,
      Q => Q
    )
    port map(
      clk_i            => clk_i,
      rst_i            => rst_i,
      vld_i            => vld_i,
      we_i             => we_i,
      data_i           => data_i,
      last_i           => last_i,
      col_tbl_addr_i   => col_tbl_addr_i,
      col_tbl_we_i     => col_tbl_we_i,
      col_tbl_data_i   => col_tbl_data_i,
      rd_addr_i        => rd_addr_i,
      rd_en_i          => rd_en_i,
      data_o           => data_o,
      pivot_col_list_o => pivot_col_list_o,
      done_o           => done_o
    );

  stim : process
  begin
    rst_i <= '1';
    wait for 20 ns;
    rst_i <= '0';
    wait for 10 ns;

    we_i <= (others => '1');
    vld_i <= '1';
    last_i <= '1';

    for idx in 0 to K-1 loop
      data_i <= VECTORS(idx);
      wait until rising_edge(clk_i);
    end loop;

    vld_i <= '0';
    last_i <= '0';
    we_i <= (others => '0');

    for idx in 0 to 5000 loop
      exit when done_o = '1';
      wait until rising_edge(clk_i);
    end loop;

    assert done_o = '1' report "rref_top timeout waiting for done_o" severity failure;
    wait;
  end process;

end sim;
