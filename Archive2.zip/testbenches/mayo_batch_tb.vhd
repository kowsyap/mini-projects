library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use ieee.std_logic_textio.all;
use std.env.all;

library std;
use std.textio.all;
use work.mayo_tb_pkg.all;

entity mayo_batch_tb is
end entity mayo_batch_tb;

architecture behavior of mayo_batch_tb is
    constant w      : integer := 8;
    constant nibble : integer := 4;

    -- Set these two for the desired KAT file and DUT build.
    constant tb_round : integer := 1;
    constant tb_set     : integer := 2;

    -- 2-bit run mode:
    -- "00" => sign
    -- "01" => verify
    -- "11" => sign then verify(generated signature)
    constant run_mode : std_logic_vector(1 downto 0) := "00";

    constant word_bits : integer := 16 * nibble; -- 64-bit bus words
    constant max_words : integer := 4096;

    type word_mem_t is array (0 to max_words-1) of std_logic_vector(word_bits-1 downto 0);

    file kat_file : text open read_mode is kat_file_path(tb_round, tb_set);

    signal clk   : std_logic := '0';
    signal reset : std_logic := '0';

    signal msg_bytes : std_logic_vector(2*w-1 downto 0) := (others => '0');
    signal mode      : std_logic := '0'; -- 0=sign, 1=verify
    signal calc      : std_logic := '0';

    signal sk_data_i         : std_logic_vector(word_bits-1 downto 0) := (others => '0');
    signal msg_data_i        : std_logic_vector(word_bits-1 downto 0) := (others => '0');
    signal sig_verify_data_i : std_logic_vector(word_bits-1 downto 0) := (others => '0');

    signal sk_valid_i         : std_logic := '0';
    signal msg_valid_i        : std_logic := '0';
    signal sig_verify_valid_i : std_logic := '0';
    signal sk_ready_o         : std_logic;
    signal msg_ready_o        : std_logic;
    signal sig_verify_ready_o : std_logic;

    signal sig_gen_ready_i : std_logic := '0';
    signal sig_gen_valid_o : std_logic;
    signal sig_gen_last_o  : std_logic;
    signal verify_ok_o     : std_logic;
    signal sig_gen_data_o  : std_logic_vector(word_bits-1 downto 0);
    signal done_o          : std_logic;

    signal cycle_ctr : natural := 0;

    signal csk_mem_s     : word_mem_t := (others => (others => '0'));
    signal cpk_mem_s     : word_mem_t := (others => (others => '0'));
    signal msg_mem_s     : word_mem_t := (others => (others => '0'));
    signal sig_mem_s     : word_mem_t := (others => (others => '0'));
    signal gen_sig_mem_s : word_mem_t := (others => (others => '0'));

    signal csk_words_s : natural range 0 to max_words := 0;
    signal cpk_words_s : natural range 0 to max_words := 0;
    signal msg_words_s : natural range 0 to max_words := 0;
    signal sig_words_s : natural range 0 to max_words := 0;

    signal sk_feed_start         : std_logic := '0';
    signal sk_feed_done          : std_logic := '0';
    signal sk_feed_sel_verify_pk : std_logic := '0'; -- 0=>CSK, 1=>CPK

    signal msg_feed_start : std_logic := '0';
    signal msg_feed_done  : std_logic := '0';

    signal sig_feed_start         : std_logic := '0';
    signal sig_feed_done          : std_logic := '0';
    signal sig_feed_use_generated : std_logic := '0';

    signal sig_cap_start : std_logic := '0';
    signal sig_cap_done  : std_logic := '0';

    constant clk_period    : time := 10 ns;
    constant initial_delay : time := 100 ns;
begin
    clk <= not clk after clk_period/2;
    reset <= '1' after initial_delay, '0' after initial_delay + clk_period;

    p_cycle_ctr : process(clk)
    begin
        if rising_edge(clk) then
            if reset = '1' then
                cycle_ctr <= 0;
            else
                cycle_ctr <= cycle_ctr + 1;
            end if;
        end if;
    end process;

    dut : entity work.mayo
        generic map (
            round => tb_round,
            set   => tb_set
        )
        port map (
            clk_i             => clk,
            reset_i           => reset,
            msg_bytes_i       => msg_bytes,
            mode_i            => mode,
            msg_valid_i       => msg_valid_i,
            msg_ready_o       => msg_ready_o,
            msg_data_i        => msg_data_i,
            sk_data_i         => sk_data_i,
            sk_valid_i        => sk_valid_i,
            sk_ready_o        => sk_ready_o,
            sig_verify_data_i => sig_verify_data_i,
            sig_verify_valid_i => sig_verify_valid_i,
            sig_verify_ready_o => sig_verify_ready_o,
            verify_ok_o       => verify_ok_o,
            sig_gen_data_o    => sig_gen_data_o,
            sig_gen_ready_i   => sig_gen_ready_i,
            sig_gen_valid_o   => sig_gen_valid_o,
            sig_gen_last_o    => sig_gen_last_o,
            calc_i            => calc,
            done_o            => done_o
        );

    p_sk_feed : process
        variable idx    : natural range 0 to max_words;
        variable target : natural range 0 to max_words;
        variable use_pk : std_logic;
    begin
        sk_data_i <= (others => '0');
        sk_valid_i <= '0';
        sk_feed_done <= '0';
        wait until reset = '0';

        loop
            wait until sk_feed_start = '1';
            idx := 0;
            use_pk := sk_feed_sel_verify_pk;
            if use_pk = '1' then
                target := cpk_words_s;
            else
                target := csk_words_s;
            end if;
            sk_feed_done <= '0';

            if target = 0 then
                sk_feed_done <= '1';
            else
                while idx < target loop
                    if use_pk = '1' then
                        sk_data_i <= cpk_mem_s(idx);
                    else
                        sk_data_i <= csk_mem_s(idx);
                    end if;
                    sk_valid_i <= '1';
                    wait until rising_edge(clk);
                    if sk_ready_o = '1' then
                        idx := idx + 1;
                    end if;
                end loop;
                sk_valid_i <= '0';
                sk_feed_done <= '1';
            end if;
        end loop;
    end process;

    p_msg_feed : process
        variable idx    : natural range 0 to max_words;
        variable target : natural range 0 to max_words;
    begin
        msg_data_i <= (others => '0');
        msg_valid_i <= '0';
        msg_feed_done <= '0';
        wait until reset = '0';

        loop
            wait until msg_feed_start = '1';
            idx := 0;
            target := msg_words_s;
            msg_feed_done <= '0';

            if target = 0 then
                msg_feed_done <= '1';
            else
                while idx < target loop
                    msg_data_i <= msg_mem_s(idx);
                    msg_valid_i <= '1';
                    wait until rising_edge(clk);
                    if msg_ready_o = '1' then
                        idx := idx + 1;
                    end if;
                end loop;
                msg_valid_i <= '0';
                msg_feed_done <= '1';
            end if;
        end loop;
    end process;

    p_sig_feed : process
        variable idx       : natural range 0 to max_words;
        variable target    : natural range 0 to max_words;
        variable use_gen   : std_logic;
    begin
        sig_verify_data_i <= (others => '0');
        sig_verify_valid_i <= '0';
        sig_feed_done <= '0';
        wait until reset = '0';

        loop
            wait until sig_feed_start = '1';
            idx := 0;
            target := sig_words_s;
            use_gen := sig_feed_use_generated;
            sig_feed_done <= '0';

            if target = 0 then
                sig_feed_done <= '1';
            else
                while idx < target loop
                    if use_gen = '1' then
                        sig_verify_data_i <= gen_sig_mem_s(idx);
                    else
                        sig_verify_data_i <= sig_mem_s(idx);
                    end if;
                    sig_verify_valid_i <= '1';
                    wait until rising_edge(clk);
                    if sig_verify_ready_o = '1' then
                        idx := idx + 1;
                    end if;
                end loop;
                sig_verify_valid_i <= '0';
                sig_feed_done <= '1';
            end if;
        end loop;
    end process;

    p_sig_capture : process
        variable idx    : natural range 0 to max_words;
        variable target : natural range 0 to max_words;
    begin
        sig_cap_done <= '0';
        wait until reset = '0';

        loop
            wait until sig_cap_start = '1';
            idx := 0;
            target := sig_words_s;
            sig_cap_done <= '0';

            if target = 0 then
                sig_cap_done <= '1';
            else
                while idx < target loop
                    wait until rising_edge(clk);
                    if sig_gen_valid_o = '1' and sig_gen_ready_i = '1' then
                        gen_sig_mem_s(idx) <= sig_gen_data_o;
                        idx := idx + 1;
                    end if;
                end loop;
                sig_cap_done <= '1';
            end if;
        end loop;
    end process;

    p_batch_ctrl : process
        variable l               : line;
        variable tmp_l           : line;

        variable length_bytes    : integer := 0;
        variable msg_hex_l       : line := null;
        variable csk_hex_l       : line := null;
        variable cpk_hex_l       : line := null;
        variable sig_hex_l       : line := null;

        variable has_length      : boolean := false;
        variable has_msg         : boolean := false;
        variable has_csk         : boolean := false;
        variable has_cpk         : boolean := false;
        variable has_sig         : boolean := false;

        variable msg_words       : natural;
        variable csk_words       : natural;
        variable cpk_words       : natural;
        variable sig_words       : natural;

        variable wv              : std_logic_vector(word_bits-1 downto 0);

        variable case_idx        : integer := 0;
        variable wrong_cases     : integer := 0;
        variable total_cycles    : integer := 0;
        variable total_time      : time := 0 ns;

        variable phase_start_t   : time;
        variable phase_end_t     : time;
        variable phase_start_c   : natural;
        variable phase_end_c     : natural;
        variable case_exec_time  : time;
        variable case_exec_cycles: integer;

        variable sign_ok         : boolean;
        variable verify_ok       : boolean;
        variable case_ok         : boolean;

        variable msg_line : line;
    begin
        wait until reset = '0';
        wait until rising_edge(clk);

        if run_mode /= "00" and run_mode /= "01" and run_mode /= "11" then
            report "Invalid run_mode. Use 00(sign), 01(verify), or 11(both)." severity failure;
        end if;

        while not endfile(kat_file) loop
            readline(kat_file, l);
            if l = null or l.all'length = 0 then
                next;
            end if;

            if starts_with(l.all, "#") then
                next;
            elsif starts_with(l.all, "LENGTH=") then
                tmp_l := new string'(strip_spaces(l.all(8 to l.all'high)));
                read(tmp_l, length_bytes);
                free_line(tmp_l);
                has_length := true;
            elsif starts_with(l.all, "MSG=") then
                free_line(msg_hex_l);
                msg_hex_l := new string'(strip_spaces(l.all(5 to l.all'high)));
                has_msg := true;
            elsif starts_with(l.all, "CSK=") then
                free_line(csk_hex_l);
                csk_hex_l := new string'(strip_spaces(l.all(5 to l.all'high)));
                has_csk := true;
            elsif starts_with(l.all, "CPK=") then
                free_line(cpk_hex_l);
                cpk_hex_l := new string'(strip_spaces(l.all(5 to l.all'high)));
                has_cpk := true;
            elsif starts_with(l.all, "SIGNATURE=") then
                free_line(sig_hex_l);
                sig_hex_l := new string'(strip_spaces(l.all(11 to l.all'high)));
                has_sig := true;
            end if;

            if has_length and has_msg and has_csk and has_cpk and has_sig then
                msg_words := hex_word_count(msg_hex_l.all);
                csk_words := hex_word_count(csk_hex_l.all);
                cpk_words := hex_word_count(cpk_hex_l.all);
                sig_words := hex_word_count(sig_hex_l.all);

                if msg_words > max_words or csk_words > max_words or cpk_words > max_words or sig_words > max_words then
                    report "Case exceeds max_words. Increase max_words in mayo_batch_tb." severity failure;
                end if;

                for i in 0 to integer(csk_words)-1 loop
                    get_hex_word(csk_hex_l.all, natural(i), wv);
                    csk_mem_s(i) <= wv;
                end loop;
                for i in 0 to integer(cpk_words)-1 loop
                    get_hex_word(cpk_hex_l.all, natural(i), wv);
                    cpk_mem_s(i) <= wv;
                end loop;
                for i in 0 to integer(msg_words)-1 loop
                    get_hex_word(msg_hex_l.all, natural(i), wv);
                    msg_mem_s(i) <= wv;
                end loop;
                for i in 0 to integer(sig_words)-1 loop
                    get_hex_word(sig_hex_l.all, natural(i), wv);
                    sig_mem_s(i) <= wv;
                end loop;

                csk_words_s <= csk_words;
                cpk_words_s <= cpk_words;
                msg_words_s <= msg_words;
                sig_words_s <= sig_words;

                wait until rising_edge(clk);

                case_idx := case_idx + 1;
                sign_ok := true;
                verify_ok := true;
                case_ok := true;

                sig_gen_ready_i <= '0';
                calc <= '0';
                msg_bytes <= std_logic_vector(to_unsigned(length_bytes, msg_bytes'length));

                while done_o = '1' loop
                    wait until rising_edge(clk);
                end loop;

                case_exec_time := 0 ns;
                case_exec_cycles := 0;

                if run_mode = "00" or run_mode = "11" then
                    mode <= '0';
                    calc <= '1';
                    phase_start_t := now;
                    phase_start_c := cycle_ctr;
                    sk_feed_sel_verify_pk <= '0';

                    sk_feed_start <= '1';
                    msg_feed_start <= '1';
                    wait until rising_edge(clk);
                    sk_feed_start <= '0';
                    msg_feed_start <= '0';

                    wait until sk_feed_done = '1' and msg_feed_done = '1';
                    sig_cap_start <= '1';
                    wait until rising_edge(clk);
                    sig_cap_start <= '0';

                    wait until done_o = '1';
                    phase_end_t := now;
                    phase_end_c := cycle_ctr;
                    case_exec_time := case_exec_time + (phase_end_t - phase_start_t);
                    case_exec_cycles := case_exec_cycles + integer(phase_end_c - phase_start_c);
                    sig_gen_ready_i <= '1';
                    wait until sig_cap_done = '1';
                    wait until rising_edge(clk);
                    sig_gen_ready_i <= '0';
                    calc <= '0';
                    wait until rising_edge(clk);
                    wait until done_o = '0';

                    if run_mode = "00" then
                        for i in 0 to integer(sig_words)-1 loop
                            if gen_sig_mem_s(i) /= sig_mem_s(i) then
                                sign_ok := false;
                            end if;
                        end loop;
                    end if;
                end if;

                if run_mode = "01" or run_mode = "11" then
                    mode <= '1';
                    calc <= '1';
                    phase_start_t := now;
                    phase_start_c := cycle_ctr;
                    sk_feed_sel_verify_pk <= '1';
                    if run_mode = "11" then
                        sig_feed_use_generated <= '1';
                    else
                        sig_feed_use_generated <= '0';
                    end if;

                    sk_feed_start <= '1';
                    msg_feed_start <= '1';
                    sig_feed_start <= '1';
                    wait until rising_edge(clk);
                    sk_feed_start <= '0';
                    msg_feed_start <= '0';
                    sig_feed_start <= '0';

                    wait until sk_feed_done = '1' and msg_feed_done = '1' and sig_feed_done = '1';
                    wait until done_o = '1';
                    phase_end_t := now;
                    phase_end_c := cycle_ctr;
                    case_exec_time := case_exec_time + (phase_end_t - phase_start_t);
                    case_exec_cycles := case_exec_cycles + integer(phase_end_c - phase_start_c);
                    calc <= '0';
                    verify_ok := (verify_ok_o = '1');
                end if;

                if run_mode = "00" then
                    case_ok := sign_ok;
                elsif run_mode = "01" then
                    case_ok := verify_ok;
                else
                    case_ok := verify_ok;
                end if;

                if not case_ok then
                    wrong_cases := wrong_cases + 1;
                end if;

                total_cycles := total_cycles + case_exec_cycles;
                total_time := total_time + case_exec_time;

                report "CASE " & integer'image(case_idx) &
                       " cycles=" & integer'image(case_exec_cycles) &
                       " time=" & integer'image(integer(case_exec_time/1 ns)) & "ns" &
                       " pass=" & boolean'image(case_ok)
                    severity note;

                has_length := false;
                has_msg := false;
                has_csk := false;
                has_cpk := false;
                has_sig := false;
            end if;
        end loop;

        report "BATCH DONE cases=" & integer'image(case_idx) &
               " wrong_cases=" & integer'image(wrong_cases) &
               " total_cycles=" & integer'image(total_cycles) &
               " total_time=" & integer'image(integer(total_time/1 ns)) & "ns"
            severity note;

        assert wrong_cases = 0
            report "Batch completed with failures: " & integer'image(wrong_cases)
            severity warning;

        free_line(msg_hex_l);
        free_line(csk_hex_l);
        free_line(cpk_hex_l);
        free_line(sig_hex_l);

        report "Simulation complete" severity note;
        wait;
    end process;
end architecture behavior;
