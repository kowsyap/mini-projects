library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use work.util_pkg.all;

entity esk_decoder is
    generic (
        w : positive := 8;
        nibble : positive := 4;
        param_m : positive := 64;
        param_n : positive := 66;
        param_o : positive := 8;
        param_d : positive := param_n - param_o;
        salt_bytes : positive := 24;
        digest_bytes : positive := 32;
        pk_seed_bytes : positive := 16;
        digest_addr_width : positive := 4
    );
    port (
        clk : in std_logic;
        reset : in std_logic;
        calc : in std_logic;
        vcalc : in std_logic;
        verify : in std_logic;

        --write inputs
        sk : in std_logic_vector(16*nibble-1 downto 0);
        vr_calc : out std_logic;
        vr_done : in std_logic;
        t_done : in std_logic;
        sk_input_ready : out std_logic;
        sk_input_valid : in std_logic;

        --read i/o
        seed_wr_data : out std_logic_vector(w*w-1 downto 0);
        seed_wr_addr : out std_logic_vector(digest_addr_width-1 downto 0);
        seed_rd_addr : out std_logic_vector(digest_addr_width-1 downto 0);
        seed_rd_data : in std_logic_vector(w*w-1 downto 0);
        seed_wr : out std_logic;

        sha_din : out std_logic_vector( w*w-1 downto 0 );
        sha_dout : in std_logic_vector( w*w-1 downto 0 );
        sha_dst_ready : out std_logic;
        sha_dst_write : in std_logic; 
        sha_src_read : in std_logic;
        sha_src_ready : out std_logic;

        o_data : out std_logic_vector(nibble-1 downto 0);
        p_data : out std_logic_vector(param_m*nibble-1 downto 0);
        col_idx : out std_logic_vector(clog2(param_n)-1 downto 0);
        row_idx : out std_logic_vector(clog2(param_n)-1 downto 0);
        p3_data : out std_logic_vector(param_m*nibble-1 downto 0);
        p3_col_idx : out std_logic_vector(clog2(param_n)-1 downto 0);
        p3_row_idx : out std_logic_vector(clog2(param_n)-1 downto 0);

        o_wr : out  std_logic_vector(param_o-1 downto 0);
        m_mode : out std_logic;
        l_mode : out std_logic;
        po_mode : out std_logic;
        pv_load : out std_logic;
        lv_load : out std_logic;
        pv_mem_load : out std_logic;
        pv_wr : out std_logic;
        lv_wr : out std_logic;
        mem_wr : out std_logic;
        l_wr : out std_logic;
        seed_done : out std_logic;
        done : out std_logic
    );
end esk_decoder;

architecture structural of esk_decoder is
    signal o_wr_mode, o_fifo, o_load, Li, Li2, Lj2, Lx2, Ei2, Ej2, Ex2, Lino, Lj, Ljno, Lij, Lx, Ly, Ls, Lp, Lc, Lk, Ei, Ej, Ex, Ey, Es, Ek, Efifo, ssk_wr, spk_wr, spk_ld, k_init, p3_wr : std_logic;
    signal zino, zjno, zy, zjo, zin, zjn, upper_temp, zs, zp, zk, zio2, zjo2 : std_logic;
    signal aes_calc, aes_done, aes_en, aes_ctr_ld, aes_ctr_en, aes_reg_wr, aes_rst : std_logic;
begin
    datapath_inst : entity work.esk_decoder_datapath
        generic map (
            w => w,
            nibble => nibble,
            param_m => param_m,
            param_n => param_n,
            param_o => param_o,
            param_d => param_d,
            salt_bytes => salt_bytes,
            digest_bytes => digest_bytes,
            digest_addr_width => digest_addr_width
        )
        port map (
            clk => clk,
            reset => reset,
            verify => verify,
            sk => sk,
            seed_wr_data => seed_wr_data,
            seed_wr_addr => seed_wr_addr,
            seed_rd_addr => seed_rd_addr,
            seed_rd_data => seed_rd_data,
            sha_din => sha_din,
            sha_dout => sha_dout,
            p_data => p_data,
            p3_data => p3_data,
            o_data => o_data,
            col_idx => col_idx,
            row_idx => row_idx,
            p3_col_idx => p3_col_idx,
            p3_row_idx => p3_row_idx,

            Li => Li,
            Ei => Ei,
            Lj => Lj,
            Ej => Ej,
            Li2 => Li2,
            Ei2 => Ei2,
            Lj2 => Lj2,
            Ej2 => Ej2,
            Lx2 => Lx2,
            Ex2 => Ex2,
            Lino => Lino,
            Ljno => Ljno,
            Lij => Lij,
            Ex => Ex,
            Ey => Ey,
            Es => Es,
            Ek => Ek,
            Efifo => Efifo,
            Lx => Lx,
            Ly => Ly,
            Ls => Ls,
            Lp => Lp,
            Lc => Lc,
            Lk => Lk,
            o_wr => o_wr,
            ssk_wr => ssk_wr,
            spk_wr => spk_wr,
            spk_ld => spk_ld,
            p3_wr => p3_wr,
            o_wr_mode => o_wr_mode,
            o_load => o_load,
            o_fifo => o_fifo,
            zino => zino,
            zjno => zjno,
            zin => zin,
            zjn => zjn,
            zio2 => zio2,
            zjo2 => zjo2,
            zy => zy,
            zjo => zjo,
            zs => zs,
            zp => zp,
            zk => zk,
            k_init => k_init,
            aes_reg_wr => aes_reg_wr,
            aes_ctr_ld => aes_ctr_ld,
            aes_ctr_en => aes_ctr_en,
            aes_calc => aes_calc,
            aes_done => aes_done,
            aes_rst => aes_rst,
            aes_en => aes_en
        );

    controller_inst : entity work.esk_decoder_controller
        port map (
            clk => clk,
            reset => reset,
            calc => calc,
            vcalc => vcalc,
            verify => verify,
            Li => Li,
            Ei => Ei,
            Lj => Lj,
            Lino => Lino,
            Ljno => Ljno,
            Lij => Lij,
            Ej => Ej,
            Ex => Ex,
            Ey => Ey,
            Es => Es,
            Ek => Ek,
            Efifo => Efifo,
            Lx => Lx,
            Ly => Ly,
            Ls => Ls,
            Lp => Lp,
            Lc => Lc,
            Lk => Lk,
            Li2 => Li2,
            Ei2 => Ei2,
            Lj2 => Lj2,
            Ej2 => Ej2,
            Lx2 => Lx2,
            Ex2 => Ex2,

            o_wr_mode => o_wr_mode,
            o_load => o_load,
            o_fifo => o_fifo,
            zino => zino,
            zjno => zjno,
            zin => zin,
            zjn => zjn,
            zio2 => zio2,
            zjo2 => zjo2,
            zy => zy,
            zjo => zjo,
            zs => zs,
            zp => zp,
            zk => zk,
            k_init => k_init,
            aes_calc => aes_calc,
            sk_input_ready => sk_input_ready,
            sk_input_valid => sk_input_valid,
            sha_src_read => sha_src_read,
            sha_src_ready => sha_src_ready,
            sha_dst_write => sha_dst_write,
            sha_dst_ready => sha_dst_ready,
            aes_reg_wr => aes_reg_wr,
            aes_ctr_ld => aes_ctr_ld,
            aes_ctr_en => aes_ctr_en,
            aes_rst => aes_rst,
            aes_done => aes_done,
            aes_en => aes_en,
            ssk_wr => ssk_wr,
            spk_wr => spk_wr,
            spk_ld => spk_ld,
            p3_wr => p3_wr,
            pv_load => pv_load,
            lv_load => lv_load,
            pv_mem_load => pv_mem_load,
            pv_wr => pv_wr,
            lv_wr => lv_wr,
            mem_wr => mem_wr,
            l_wr => l_wr,
            m_mode => m_mode,
            l_mode => l_mode,
            po_mode => po_mode,
            vr_calc => vr_calc,
            vr_done => vr_done,
            t_done => t_done,
            seed_done => seed_done,
            done => done
        );

        seed_wr <= ssk_wr;
end structural;
