library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use work.util_pkg.all;
use work.mayo_pkg.all;
use work.AES_pkg.all;

entity esk_decoder_datapath is
    generic (
        w : positive := 8;
        nibble : positive := 4;
        param_m : positive := 64;
        param_n : positive := 66;
        param_o : positive := 8;
        param_d : positive := param_n - param_o;
        salt_bytes : positive := 24;
        digest_bytes : positive := 32;
        pk_seed_bytes : positive := 16;
        digest_addr_width : positive := 4;
        sha_bits : positive := w*w
    );
    port (
        clk : in std_logic;
        reset : in std_logic;
        verify : in std_logic;

        sk : in std_logic_vector(16*nibble-1 downto 0);

        -- read i/o
        seed_wr_data : out std_logic_vector(sha_bits-1 downto 0);
        seed_wr_addr : out std_logic_vector(digest_addr_width-1 downto 0);

        o_data : out std_logic_vector(nibble-1 downto 0);
        p_data : out std_logic_vector(param_m*nibble-1 downto 0);
        p3_data : out std_logic_vector(param_m*nibble-1 downto 0);
        col_idx : out std_logic_vector(clog2(param_n)-1 downto 0);
        row_idx : out std_logic_vector(clog2(param_n)-1 downto 0);
        p3_col_idx : out std_logic_vector(clog2(param_n)-1 downto 0);
        p3_row_idx : out std_logic_vector(clog2(param_n)-1 downto 0);

        sha_din : out std_logic_vector( sha_bits-1 downto 0 );
        sha_dout : in std_logic_vector( sha_bits-1 downto 0 );

        seed_rd_data : in std_logic_vector( sha_bits-1 downto 0 );
        seed_rd_addr : out std_logic_vector( digest_addr_width-1 downto 0 );

        o_wr : out  std_logic_vector(param_o-1 downto 0);
        ssk_wr : in std_logic;
        spk_wr : in std_logic;
        spk_ld : in std_logic;

        aes_calc : in std_logic;
        aes_en : in std_logic;
        aes_rst : in std_logic;
        aes_done : out std_logic;
        aes_ctr_ld : in std_logic;
        aes_ctr_en : in std_logic;
        aes_reg_wr : in std_logic;

        k_init : in  std_logic;
        p3_wr : in  std_logic;
        o_wr_mode : in  std_logic;
        o_load : in  std_logic;
        o_fifo : in  std_logic;
        Li : in std_logic;
        Ei : in std_logic;
        Li2 : in std_logic;
        Lj2 : in std_logic;
        Ei2 : in std_logic;
        Ej2 : in std_logic;
        Lx2 : in std_logic;
        Ex2 : in std_logic;

        Lj : in std_logic;
        Lino : in std_logic;
        Ljno : in std_logic;
        Lij  : in std_logic;
        Lx : in std_logic;
        Ly : in std_logic;
        Ls : in std_logic;
        Lp : in std_logic;
        Lc : in std_logic;
        Lk : in std_logic;
        Ej : in std_logic;
        Ex : in std_logic;
        Ey : in std_logic;
        Es : in std_logic;
        Ek : in std_logic;
        Efifo : in std_logic;
        zino: out std_logic;  
        zjno: out std_logic;    
        zin: out std_logic;    
        zjn: out std_logic; 
        zio2 : out std_logic;
        zjo2 : out std_logic;   
        zy: out std_logic;    
        zjo: out std_logic;
        zs: out std_logic;
        zp: out std_logic;
        zk: out std_logic;
        zac: out std_logic
    );
end esk_decoder_datapath;

architecture structural of esk_decoder_datapath is
    constant nibble_count : positive := 32; 
    constant nibble_count2 : positive := 16; 
    constant word_count : positive := ceil_div(param_m, nibble_count); -- 64/32 ->2, 96/32->3, 128/32->4
    constant x_width : integer := calc_width32(param_m);  -- 78%4=2->4, 64%4=0->3, 108%4=0->3, 142%4=2->4
    constant p3_word_count : positive := ceil_div(param_m, nibble_count2); -- 64/16=4->4, 96/16=6->6, 128/16=8->8
    constant x2_width : integer := calc_width16(param_m);  -- 78%4=2->3, 64%4=0->2, 108%4=0->2, 142%4=2->3

    constant seed_blocks : positive := salt_bytes / w;
    constant pk_blocks : positive := pk_seed_bytes / w;
    constant salt_words: integer := salt_bytes / w;
    constant digest_words: integer := digest_bytes / w;
    constant o_bytes : positive := param_d * param_o / 2;
    constant mode_val : unsigned(3 downto 0) := to_unsigned(14, 4);
    constant p1_bytes : integer := param_m*param_d*(param_d+1)/4;
    constant p2_bytes : integer := param_m*param_d*param_o/2;
    constant p3_bytes : integer := param_m*param_o*(param_o+1)/4;
    constant aes_words : positive := ceil_div(p1_bytes + p2_bytes, 16);

    constant final_out_size : positive := word_size(param_m, word_count, nibble_count) * nibble_count * nibble;
    constant p3_final_out_size : positive := word_size(param_m, p3_word_count, nibble_count2) * nibble_count2 * nibble;
    constant aes_count : positive := word_size(param_m, word_count, nibble_count);

    signal fifo_reg, shifted_fifo : std_logic_vector(final_out_size-1 downto 0);
    signal p3_fifo_reg, p3_shifted_fifo : std_logic_vector(p3_final_out_size-1 downto 0);
    signal p_decoded_vector, p_vector, p_vector2, p3_decoded_vector, p3_vector, p3_vector2 : std_logic_vector(param_m*nibble-1 downto 0);
    signal partial_decoded_vector, spk_data_temp : std_logic_vector(nibble_count2*nibble-1 downto 0);
    signal o_shift_reg : std_logic_vector(nibble_count2*nibble-1 downto 0) := (others => '0');
    
    signal i, j, i2, j2, y : unsigned(clog2(param_n)-1 downto 0);
    signal s : unsigned(clog2(seed_blocks)-1 downto 0);
    signal x, aes_x : unsigned(x_width-1 downto 0);
    signal x2 : unsigned(x2_width-1 downto 0);
    signal seed : unsigned(digest_addr_width-1 downto 0);
    signal aes_ctr, aes_ctr_init: unsigned(32*nibble-1 downto 0);
    signal k, expected_k_limit : unsigned(nibble-1 downto 0);

    signal spk : std_logic_vector(pk_seed_bytes*w-1 downto 0);

    constant shift_rom : shift_rom32_type(0 to 2**x_width-1) := get_shift_rom32(param_m, x_width);
    constant load_rom : shift_rom32_type(0 to 2**x_width-1) := get_load_rom32(param_m, word_count, x_width);
    constant p3_shift_rom : shift_rom16_type(0 to 2**x2_width-1) := get_shift_rom16(param_m, x2_width);
    signal load_val : integer range 0 to word_count;

    signal output_bits : unsigned(27 downto 0);
    signal input_bits  : unsigned(31 downto 0);
    signal command_word : std_logic_vector(sha_bits-1 downto 0);

    signal aes_ok      : std_logic_vector(aes_count-1 downto 0);
    signal shared_rkeys : std_logic_vector(AES_ROUNDS*AES_BLOCK_SIZE-1 downto 0);  -- pipelined round keys from AES instance 0

begin
    output_bits <= to_unsigned((pk_seed_bytes + o_bytes)*w, 28);
    input_bits  <= to_unsigned(salt_bytes*w, 32);
    command_word <= std_logic_vector(mode_val & output_bits & input_bits);

    sha_din <= command_word when Lc = '1' else seed_rd_data;

    spk_data_temp <= sk when verify = '1' else sha_dout;
    seed_wr_data <= sk when ssk_wr = '1' else sha_dout;
    seed_wr_addr <= std_logic_vector(seed);
    seed_rd_addr <= std_logic_vector(seed);

    row_idx <= std_logic_vector(i);
    col_idx <= std_logic_vector(j);
    p3_row_idx <= std_logic_vector(i2);
    p3_col_idx <= std_logic_vector(to_unsigned(param_d,j2'length)+j2);


    gen_shift : if (param_m mod nibble_count) /= 0 generate
        shifted_fifo <= std_logic_vector(shift_right(unsigned(fifo_reg), 4*shift_rom(to_integer(x))));
        p_vector <= shifted_fifo(param_m*nibble-1 downto 0);

        p3_shifted_fifo <= std_logic_vector(shift_right(unsigned(p3_fifo_reg), 4*p3_shift_rom(to_integer(x2))));
        p3_vector <= p3_shifted_fifo(param_m*nibble-1 downto 0);

        expected_k_limit <= to_unsigned(p3_word_count - 1, nibble) when (k_init = '0' and x2 = 0) else to_unsigned(p3_word_count, nibble);

        load_val <= load_rom(to_integer(aes_x+1));

        aes_ctr_init <= (others => '1');

        counterX2: process(clk)
        begin
            if rising_edge(clk) then
                if Lx2 = '1' then
                    x2 <= (others => '0');
                elsif Ex2 = '1' then
                    x2 <= x2 + 1;
                end if;
            end if;
        end process;
    end generate;

    gen_non_shift : if (param_m mod nibble_count) = 0 generate
        p_vector <= fifo_reg;
        p3_vector <= p3_fifo_reg;

        expected_k_limit <= to_unsigned(p3_word_count, nibble);

        load_val <= word_count;

        aes_ctr_init <= (others => '0');
    end generate;

    gen_r2 : if (param_m mod nibble_count) /= 0 or param_n = 81 generate
    begin
        p_decoded_vector <= p_vector;
        p3_decoded_vector <= p3_vector;
    end generate;

    gen_r1 : if (param_m mod nibble_count) = 0 and param_n /= 81 generate
    begin

        bit_sliced_vector_inst: entity work.bit_sliced_vector
            generic map(
                param_m => param_m,
                nibble => nibble
            )
            port map(
                a => p_vector,
                result => p_vector2
            );
        bit_sliced_vector_inst2: entity work.bit_sliced_vector
            generic map(
                param_m => param_m,
                nibble => nibble
            )
            port map(
                a => p3_vector,
                result => p3_vector2
            );
            
        p_decoded_vector <= p_vector2;
        p3_decoded_vector <= p3_vector2;
    end generate;

    o_data  <= o_shift_reg(3 downto 0);

    gen_o_wr : for idx in 0 to param_o-1 generate
        o_wr(idx) <= o_wr_mode when j = to_unsigned(idx, j'length) else '0';
    end generate;

    gen_aes_multiple : for i in 0 to aes_count-1 generate
        signal aes_in, aes_out : std_logic_vector(nibble_count*nibble-1 downto 0);
    begin
        aes_in <= std_logic_vector(aes_ctr + to_unsigned(i, aes_in'length));

        -- Instance 0 is the key schedule master: computes and exposes pipelined round keys.
        -- Instances 1+ are slaves: skip key schedule, saving ~1440 LUTs each.
        g_master : if i = 0 generate
            aes_ctr_inst : entity work.AES128P
                generic map (
                    G_SBOX_LOGIC => False,
                    G_SHARE_KEY  => False
                )
                port map (
                    clk     => clk,
                    rst     => reset or aes_rst,
                    din     => aes_in,
                    key     => spk,
                    dout    => aes_out,
                    rkeys_i => shared_rkeys,
                    rkeys_o => shared_rkeys,
                    start   => aes_calc,
                    en      => aes_en,
                    done    => aes_ok(0)
                );
        end generate;

        g_slave : if i > 0 generate
            aes_ctr_inst : entity work.AES128P
                generic map (
                    G_SBOX_LOGIC => False,
                    G_SHARE_KEY  => True
                )
                port map (
                    clk     => clk,
                    rst     => reset or aes_rst,
                    din     => aes_in,
                    key     => spk,
                    dout    => aes_out,
                    rkeys_i => shared_rkeys,
                    rkeys_o => open,
                    start   => aes_calc,
                    en      => aes_en,
                    done    => aes_ok(i)
                );
        end generate;

        dec_vector_inst : entity work.decode_vector
            generic map(
                nibble_count => nibble_count,
                nibble       => nibble,
                reverse      => true
            )
            port map(
                a      => aes_out,
                result => fifo_reg((i+1)*32*nibble-1 downto i*32*nibble)
            );

    end generate;

    esk_fifo_inst: entity work.SIPO_FIFO
        generic map(LEFT_SHIFT=>false,INPUT_WIDTH=>nibble_count2*nibble,OUTPUT_WIDTH=>p3_final_out_size)
        port map(
            clk => clk,
            reset => reset,
            serial_in => partial_decoded_vector,
            parallel_in => (others=>'0'),
            serial_out => open,
            load => Efifo,
            load_parallel => '0',
            parallel_out => p3_fifo_reg
        );

    spk_fifo: process(clk)
    begin
        if rising_edge(clk) then
            if spk_ld = '1' then
                spk <= (others => '0');
            elsif spk_wr = '1' then
                spk <= spk(pk_seed_bytes*w-sha_bits-1 downto 0) & spk_data_temp;
            end if;
        end if;
    end process;

    aes_reg: process(clk)
    begin
        if rising_edge(clk) then
            if aes_reg_wr = '1' then
                p_data <= p_decoded_vector;
            end if;
            if p3_wr = '1' then
                p3_data <= p3_decoded_vector;
            end if;
        end if;
    end process;

    decode_vector_inst: entity work.decode_vector
        generic map(
            nibble_count => nibble_count2,
            nibble => nibble,
            reverse => true
        )
        port map(
            a => spk_data_temp,
            result => partial_decoded_vector
        );

    o_fifo_inst: process(clk)
    begin
        if rising_edge(clk) then
            if o_load = '1' then
                o_shift_reg <= partial_decoded_vector;
            elsif o_fifo = '1' then
                o_shift_reg <= std_logic_vector(shift_right(unsigned(o_shift_reg), nibble));
            end if;
        end if;
    end process;

    counterI: process(clk)
    begin
        if rising_edge(clk) then
            if Li = '1' then
                i <= (others => '0');
            elsif Lino = '1' then
                i <= to_unsigned(param_d,i'length);
            elsif Ei = '1' then
                i <= i + 1;
            end if;          
        end if;
    end process;

    counterJ: process(clk)
    begin
        if rising_edge(clk) then
            if Lj = '1' then
                j <= (others => '0');
            elsif Lij = '1' then
                j <= i;
            elsif Ljno = '1' then
                j <= to_unsigned(param_d,j'length);
            elsif Ej = '1' then
                j <= j + 1;
            end if;
        end if;
    end process;

    counterI2: process(clk)
    begin
        if rising_edge(clk) then
            if Li2 = '1' then
                i2 <= (others=>'0');
            elsif Ei2 = '1' then
                i2 <= i2 + 1;
            end if;
        end if;
    end process;

    counterJ2: process(clk)
    begin
        if rising_edge(clk) then
            if Lj2 = '1' then
                j2 <= i2;
            elsif Ej2 = '1' then
                j2 <= j2 + 1;
            end if;
        end if;
    end process;

    counterY: process(clk)
    begin
        if rising_edge(clk) then
            if Ly = '1' then
                y <= (others => '0');
            elsif Ey = '1' then
                y <= y + 1;
            end if;
        end if;
    end process;

    counterX: process(clk)
    begin
        if rising_edge(clk) then
            if Lx = '1' then
                x <= (others => '0');
            elsif Ex = '1' then
                x <= x + 1;
            end if;
        end if;
    end process;

    counterK: process(clk)
    begin
        if rising_edge(clk) then
            if Lk = '1' then
                k <= (others => '0');
            elsif Ek = '1' then
                k <= k + 1;
            end if;
        end if;
    end process;

    -- aes input Counter -> (0 to p1+p2 words - 1)
    counterAES : process(clk)
    begin
        if rising_edge(clk) then
            if aes_ctr_ld = '1' then
                aes_ctr <= aes_ctr_init;
                aes_x <= (others=>'0');
            elsif aes_ctr_en = '1' then
                aes_ctr <= aes_ctr + to_unsigned(load_val,aes_ctr'length);
                aes_x <= aes_x+1;
            end if;    
        end if;
    end process;

    counterS: process(clk)
    begin
        if rising_edge(clk) then
            if Ls = '1' then
                seed <= to_unsigned(digest_words+salt_words,digest_addr_width);
                s <= (others => '0');
            elsif Lp = '1' then
                seed <= to_unsigned(digest_words+salt_words+salt_words,digest_addr_width);
                s <= (others=>'0');
            elsif Es = '1' then
                seed <= seed + 1;
                s <= s + 1;
            end if;
        end if;
    end process;

    zino <= '1' when i = to_unsigned(param_d-1, clog2(param_n)) else '0';
    zjno <= '1' when j = to_unsigned(param_d-1, clog2(param_n)) else '0';
    zin <= '1' when i = to_unsigned(param_n-1, clog2(param_n)) else '0';
    zjn <= '1' when j = to_unsigned(param_n-1, clog2(param_n)) else '0';
    zio2 <= '1' when i2 = to_unsigned(param_o-1, clog2(param_n)) else '0';
    zjo2 <= '1' when j2 = to_unsigned(param_o-1, clog2(param_n)) else '0';
    zy <= '1' when y = to_unsigned(nibble_count2-1, clog2(param_n)) else '0';
    zjo <= '1' when j = to_unsigned(param_o-1, clog2(param_n)) else '0';
    zs <= '1' when s = to_unsigned(seed_blocks - 1, clog2(seed_blocks)) else '0';
    zp <= '1' when s = to_unsigned(pk_blocks - 1, clog2(seed_blocks)) else '0';
    zk <= '1' when k = expected_k_limit else '0';

    aes_done <= '1' when aes_ok = (aes_count-1 downto 0 => '1') else '0';
    zac <= '1' when aes_ctr = to_unsigned(aes_words-1, aes_ctr'length) else '0';

end structural;
