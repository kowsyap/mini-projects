library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use work.util_pkg.all;

entity column_fifo_loader is
  generic (
    nibble  : positive := 4;
    parallel_factor : positive := 8;
    param_m : positive := 64;
    param_o : positive := 8;
    param_k : positive := 9;
    addr_width : positive := 3;
    rows : positive := 78;
    NUM_GROUPS : positive := 10
  );
  port (
    clk      : in  std_logic;
    reset      : in  std_logic;
    calc     : in  std_logic;
    done     : out std_logic;

    addr_out : out std_logic_vector(addr_width-1 downto 0);
    a_addr_out : out std_logic_vector(clog2(param_k*param_o)-1 downto 0);
    cfl_grp : out std_logic_vector(clog2(NUM_GROUPS)-1 downto 0);
    cfl_idx : out std_logic_vector(clog2(parallel_factor)-1 downto 0);
    cfl_load : out std_logic;
    extra : out std_logic;
    out_valid : out std_logic

  );
end column_fifo_loader;

architecture behavioral of column_fifo_loader is

    constant REM_COLS   : integer := param_m mod parallel_factor;
    constant I_WIDTH    : integer := clog2(NUM_GROUPS);
    constant J_WIDTH    : integer := clog2(param_o);
    constant A_WIDTH    : integer := clog2(param_k*param_o);
    constant L_WIDTH    : integer := clog2(parallel_factor);

    signal i : unsigned(I_WIDTH-1 downto 0);
    signal j : unsigned(J_WIDTH-1 downto 0);
    signal a : unsigned(A_WIDTH-1 downto 0);
    signal l : unsigned(L_WIDTH-1 downto 0);
    signal Ei,Ej,El,Ea,EK : std_logic;
    signal Li,Lj,Ll,La,Lk : std_logic;
    signal zi,zj,zl,zri,zk  : std_logic; 

    signal limit_l    : unsigned(L_WIDTH-1 downto 0);

    type state_type is (IDLE, S1, S2, S3, S4, OK);
    signal state, next_state : state_type;

begin

    cfl_grp <= std_logic_vector(i);
    cfl_idx <= std_logic_vector(l);

    -- Counter i
    counter_i : process(clk)
    begin
        if rising_edge(clk) then
            if Li = '1' then
                i <= (others => '0');
            elsif Ei = '1' then
                i <= i + 1;
            end if;
        end if;
    end process counter_i;

    -- Counter j
    counter_j : process(clk)
    begin
        if rising_edge(clk) then
            if Lj = '1' then
                j <= (others => '0');
            elsif Ej = '1' then
                j <= j + 1;
            end if;
        end if;
    end process counter_j;

    -- Counter l
    counter_l : process(clk)
    begin
        if rising_edge(clk) then
            if Ll = '1' then
                l <= (others => '0');
            elsif El = '1' then
                l <= l + 1;
            end if;
        end if;
    end process counter_l;

    -- Counter a
    counter_a : process(clk)
    begin
        if rising_edge(clk) then
            if La = '1' then
                a <= (others => '0');
            elsif Ea = '1' then
                a <= a + 1;
            end if;
        end if;
    end process counter_a;

    fsm_proc : process(clk, reset)
    begin
        if reset = '1' then
            state <= IDLE;
        elsif rising_edge(clk) then
            state <= next_state;
        end if;
    end process;

    control_proc : process(state, zi, zj, zl, zri, calc)
    begin
        Li <= '0'; 
        Ei <= '0';
        Lj <= '0'; 
        Ej <= '0';
        Ll <= '0'; 
        El <= '0';
        La <= '0';
        Ea <= '0';
        extra <= '0';
        cfl_load <= '0';
        done <= '0';
        out_valid <= '0';
        next_state <= state;
        case state is
            when IDLE =>
                if calc = '1' then
                    Li <= '1';
                    Lj <= '1';
                    La <= '1';
                    Ll <= '1';
                    next_state <= S1;
                end if;

            when S1 =>
                cfl_load <= '1';
                next_state <= S2;

            when S2 =>
                if zj = '0' then
                    Ej <= '1';
                    next_state <= S1;
                else
                    Lj <= '1';
                    Ll <= '1';
                    cfl_load <= '1'; 
                    next_state <= S3;
                end if;
            
            when S3 =>
                out_valid <= '1';
                if zl = '0' then
                    El <= '1';
                    Ea <= '1';
                elsif zi = '0' then
                    Ei <= '1';
                    Ea <= '1';
                    next_state <= S1;
                else
                    if zri = '1' then
                        next_state <= OK;
                    else
                        next_state <= S4;
                        Ea <= '1';
                    end if;
                end if;

            when S4 =>
                extra <= '1';
                out_valid <= '1';
                next_state <= OK;
            
            when OK =>
                done <= '1';
                if calc = '0' then
                    next_state <= IDLE;
                end if;
        end case;
    end process;

    zi <= '1' when i = to_unsigned(NUM_GROUPS - 1, I_WIDTH) else '0';
    zj <= '1' when j = to_unsigned(param_o-1, J_WIDTH) else '0';
    zri <= '1' when rows = param_m else '0';

    limit_l <= to_unsigned(parallel_factor - 1, L_WIDTH) when (zi = '0') or (REM_COLS = 0) else
               to_unsigned(REM_COLS - 1, L_WIDTH);

    zl <= '1' when l = limit_l else '0';

    addr_out <= std_logic_vector(resize(j, addr_width));
    a_addr_out <= std_logic_vector(resize(to_unsigned(rows,a_addr_out'length)-a-1, a_addr_out'length));

end behavioral;
