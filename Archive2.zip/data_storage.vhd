library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use work.util_pkg.all;
use work.mayo_pkg.all;

entity data_storage is
    generic (
        w : positive := 8;
        nibble : positive := 4;
        param_m : positive := 78;
        param_n : positive := 86;
        param_o : positive := 8;
        param_k : positive := 10;
        param_d : positive := param_n - param_o;
        m_read_bits  : positive := param_m * nibble;
        r_bytes : positive := (param_k*param_o)/2;
        parallel_factor : positive := 8;
        NUM_GROUPS : positive := 10
    );
    port (
        clk : in std_logic;
        reset : in std_logic;
        calc : in std_logic;
        signing : in std_logic;

        v_wr : in std_logic;
        v_in : in  std_logic_vector(param_n*nibble-1 downto 0);
        v_out : out std_logic_vector(param_d*nibble-1 downto 0);
        v_wr_addr : in std_logic_vector(nibble-1 downto 0);
        v_addr : in std_logic_vector(nibble-1 downto 0);
        
        o_in : in  std_logic_vector(nibble-1 downto 0);
        o_out : out std_logic_vector(param_d*nibble-1 downto 0);
        o_addr : in std_logic_vector(clog2(param_o)-1 downto 0);
        o_wr : in std_logic_vector(param_o-1 downto 0);
        
        a_addr   : in  std_logic_vector(clog2(param_o)-1 downto 0);
        a_wr     : in  std_logic;
        a_reduce : in std_logic;
        a_reduce_calc : in std_logic;
        a_reduce_done : out std_logic;
        a_cfl : in std_logic;

        m_mem_init   : in  std_logic;
        a_mem_init   : in  std_logic;
        mem_init_addr : in std_logic_vector(clog2(param_n)-1 downto 0);

        cfl_load : in std_logic;
        cfl_extra : in std_logic;
        cfl_grp : in std_logic_vector(clog2(NUM_GROUPS)-1 downto 0);
        cfl_idx : in std_logic_vector(clog2(parallel_factor)-1 downto 0);
        
        m_mode : in std_logic;
        l_mode : in std_logic;
        pv_load : in std_logic;
        lv_load : in std_logic;
        pv_mem_load : in std_logic;
        pv_wr : in std_logic;
        lv_wr : in std_logic;
        mem_wr : in std_logic;
        l_wr : in std_logic;
        po_mode : in std_logic;
        a_decode : in std_logic;
        duo : in std_logic;

        input_data : in  std_logic_vector(m_read_bits-1 downto 0);
        input_data2 : in  std_logic_vector(m_read_bits-1 downto 0);
        col_idx : in std_logic_vector(clog2(param_n)-1 downto 0);
        row_idx : in std_logic_vector(clog2(param_n)-1 downto 0);
        col_idx2 : in std_logic_vector(clog2(param_n)-1 downto 0);
        row_idx2 : in std_logic_vector(clog2(param_n)-1 downto 0);
        pv_addr : in std_logic_vector(clog2(param_n)-1 downto 0);

        u_out : out std_logic_vector((param_m+param_k-1)*nibble-1 downto 0);
        cfl_out : out std_logic_vector(r_bytes*w-1 downto 0)
    );
end data_storage;

architecture behavioral of data_storage is

    constant max_param : positive := max(param_o, param_k);
    constant REM_BITS   : integer := (NUM_GROUPS*parallel_factor*nibble) - (param_m*nibble);
    constant U_XOR_M_MAX_SHIFT_BITS : natural := ((param_k * (param_k + 1)) / 2 - 1)* nibble;
    constant U_XOR_M_LOW_BITS : natural := m_read_bits - U_XOR_M_MAX_SHIFT_BITS;
    constant U_XOR_WIDTH : positive := m_read_bits + U_XOR_M_MAX_SHIFT_BITS;

    type N_K_STORE_TYPE is array (0 to param_k-1) of std_logic_vector(param_n*nibble-1 downto 0);
    type M_K_STORE_TYPE is array (0 to param_k-1) of std_logic_vector(param_m*nibble-1 downto 0);
    type D_O_STORE_TYPE is array (0 to param_o-1) of std_logic_vector(param_d*nibble-1 downto 0);
    type M2_K_STORE_TYPE is array (0 to param_k-1) of std_logic_vector(U_XOR_WIDTH-1 downto 0);
    type M_MP_STORE_TYPE is array (0 to max_param-1) of std_logic_vector(param_m*nibble-1 downto 0);
    signal v_store : N_K_STORE_TYPE := ( others => ( others => '0' ) );
    signal pv_partial_arr : M_K_STORE_TYPE := ( others => ( others => '0' ) );
    signal l_partial_arr : M_MP_STORE_TYPE := ( others => ( others => '0' ) );
    signal l_arr : M_MP_STORE_TYPE := ( others => ( others => '0' ) );
    signal u_arr : M2_K_STORE_TYPE := ( others => ( others => '0' ) );
    signal m_arr : M2_K_STORE_TYPE := ( others => ( others => '0' ) );
    signal pv_arr : M_K_STORE_TYPE := ( others => ( others => '0' ) );
    signal o_store : D_O_STORE_TYPE := ( others => ( others => '0' ) );
    type sipo_arr_t is array (0 to parallel_factor-1) of std_logic_vector(param_k*param_o*nibble-1 downto 0);
    signal sipo_out  : sipo_arr_t;

    signal col_idx_i : integer range 0 to param_n-1;
    signal col_idx2_i : integer range 0 to param_n-1;
    signal row_idx_i : integer range 0 to param_n-1;
    signal pv_idx : integer range 0 to param_n-1;
    signal v_wr_idx : integer range 0 to param_k-1;
    signal rd_idx : integer range 0 to param_k-1;
    signal o_addr_i : integer range 0 to param_o-1;
    signal l_col_idx : integer range 0 to param_o-1;
    signal cfl_grp_i : integer range 0 to NUM_GROUPS-1;

    signal v_sel_i, v_addr_d : std_logic_vector(nibble-1 downto 0);
    signal wr_addr, pv_mem_rd_addr, l_mem_rd_addr, pv_mem_wr_addr, l_mem_wr_addr, l_mem_wr_addr_d, m_mem_addr, a_local_addr, pv_addr_d, l_row_wr_addr, l_col_wr_addr : std_logic_vector(clog2(param_n)-1 downto 0);
    signal aligned_mj : std_logic_vector(U_XOR_WIDTH-1 downto 0);
    signal rdc_done : std_logic_vector(param_k-1 downto 0);

    constant U_XOR_STAGES : integer := clog2(param_k); -- 4,2,4,4
    constant U_XOR_POW2 : integer := 2**U_XOR_STAGES; -- 16,4,16,16

    type U_XOR_LEVEL_T is array (0 to U_XOR_POW2-1) of std_logic_vector(U_XOR_WIDTH-1 downto 0);
    type U_XOR_TREE_T is array (0 to U_XOR_STAGES) of U_XOR_LEVEL_T;
    signal u_xor_tree : U_XOR_TREE_T;
    signal u_xor_input_reg : U_XOR_LEVEL_T := (others => (others => '0'));

    constant TRI_LUT : int_lut_t(0 to param_k-1) := make_tri_lut(param_k);

    signal mem_init : std_logic;
    signal l_wr_d, a_wr_d, po_mode_d, mem_init_d : std_logic;
    signal a_addr_d : std_logic_vector(clog2(param_o)-1 downto 0);
    signal partial_inp_shared : std_logic_vector(param_m*nibble-1 downto 0);

    signal pv_rd_sel        : std_logic_vector(param_m*nibble-1 downto 0);
    signal v_rd_sel         : std_logic_vector(param_n*nibble-1 downto 0);
    signal partial_l_shared : std_logic_vector(param_m*nibble-1 downto 0);
    attribute keep : string;
    attribute keep of pv_rd_sel        : signal is "true";
    attribute keep of v_rd_sel         : signal is "true";
    attribute keep of partial_l_shared : signal is "true";

begin

    col_idx_i <= to_integer(unsigned(col_idx));
    col_idx2_i <= to_integer(unsigned(col_idx2));
    row_idx_i <= to_integer(unsigned(row_idx));
    v_wr_idx <= to_integer(unsigned(v_wr_addr));
    pv_idx <= to_integer(unsigned(pv_addr_d));
    l_col_idx <= to_integer(unsigned(col_idx)) when unsigned(col_idx) < to_unsigned(param_o, col_idx'length) else 0;
    rd_idx <= to_integer(unsigned(v_addr_d));
    o_addr_i <= to_integer(unsigned(o_addr));
    cfl_grp_i <= to_integer(unsigned(cfl_grp));
    partial_inp_shared <= input_data when signing = '1' else input_data2;

    pv_mem_rd_addr <= mem_init_addr when m_mem_init='1' 
        else std_logic_vector(to_unsigned(param_d+col_idx_i, pv_mem_rd_addr'length)) when m_mode = '1' 
        else row_idx when calc = '1' 
        else pv_addr;
    pv_mem_wr_addr <= mem_init_addr when m_mem_init='1' 
        else std_logic_vector(to_unsigned(param_d+col_idx_i, pv_mem_rd_addr'length)) when m_mode = '1' 
        else row_idx;

    a_local_addr <= std_logic_vector(resize(unsigned(a_addr_d),a_local_addr'length)) when a_decode = '1' else std_logic_vector(resize(unsigned(a_addr),a_local_addr'length));

    l_row_wr_addr <= row_idx when signing = '1' else row_idx2;
    l_col_wr_addr <= col_idx when signing = '1' else (others=>'0');
    
    l_mem_rd_addr <= a_local_addr(a_local_addr'length-2 downto 0) & duo when (a_decode = '1' or a_reduce = '1' or a_cfl = '1')
        else l_row_wr_addr when po_mode = '1' or m_mode = '1' 
        else l_col_wr_addr;
    
    l_mem_wr_addr <= mem_init_addr when mem_init = '1' and unsigned(mem_init_addr) < to_unsigned(param_d, mem_init_addr'length)
        else a_local_addr(a_local_addr'length-2 downto 0) & duo when (a_decode = '1' or a_reduce = '1')
        else l_row_wr_addr when po_mode = '1' or m_mode = '1'
        else l_col_wr_addr;

    wr_addr <= l_mem_wr_addr_d;

    mem_init <= m_mem_init or a_mem_init;

    pv_rd_sel <= pv_arr(rd_idx);
    v_rd_sel  <= v_store(rd_idx);
    partial_l_shared <= input_data xor l_arr(l_col_idx) when m_mode = '1' else input_data;


    delayed_regs: process(clk)
    begin
        if rising_edge(clk) then
            l_wr_d <= l_wr;
            a_wr_d <= a_wr;
            po_mode_d <= po_mode;
            mem_init_d <= mem_init;
            l_mem_wr_addr_d <= l_mem_wr_addr;
            pv_addr_d <= pv_addr;
            v_addr_d <= v_addr;
            a_addr_d <= a_addr;
        end if;
    end process;

    v_store_proc : process(clk)
    begin
        if rising_edge(clk) then
            if v_wr = '1' then
                v_store(v_wr_idx) <= v_in;
            end if;
        end if;
    end process;

    gen_o : for o in 0 to param_o-1 generate
    begin
        o_reg_fifo_inst: entity work.SIPO_FIFO
            generic map(INPUT_WIDTH=>nibble,OUTPUT_WIDTH=>param_d*nibble)
            port map(
                clk => clk,
                reset => reset,
                serial_in => o_in,
                parallel_in => (others=>'0'),
                serial_out => open,
                load => o_wr(o),
                load_parallel => '0',
                parallel_out => o_store(o)
            );
    end generate;

    gen_l : for o in 0 to max_param-1 generate
        signal po_mul, pto_mul, l_wr_data_temp, l_wr_data, l_rd_data, wr_data_po, wr_data_temp, wr_data_temp_d, wr_data_a_half : std_logic_vector(param_m*nibble-1 downto 0);
        signal v_sel_j_esk, v_sel_j_acc, o_sel_j, partial_j : std_logic_vector(nibble-1 downto 0);
        signal memory_wr : std_logic;
    begin

        gen_o : if o < param_o generate
            signal o_sel_i : std_logic_vector(nibble-1 downto 0);
            signal col_idx_ii : integer range 0 to param_n-1;
            signal row_idx_ii : integer range 0 to param_n-1;
        begin
            row_idx_ii <= row_idx_i when row_idx_i<param_d else 0;
            col_idx_ii <= col_idx_i when col_idx_i<param_d else 0;

            mul_array_inst_i : entity work.mul_gf16_array
                generic map(
                    m => param_m,
                    nibble => nibble
                )
                port map(
                    input_data => input_data,
                    a => o_sel_i,
                    result => pto_mul
                );

            o_sel_i <= o_store(o)((param_d-row_idx_ii)*nibble-1 downto (param_d-row_idx_ii-1)*nibble);
            o_sel_j <= o_store(o)((param_d-col_idx_ii)*nibble-1 downto (param_d-col_idx_ii-1)*nibble);

        end generate;

        gen_k : if o < param_k generate
            signal mk_rev, mk_rev2 : std_logic_vector(m_read_bits-1 downto 0);
            signal wr_data_a_hi, wr_data_a_lo : std_logic_vector(m_read_bits-1 downto 0);
            signal aligned_mi, wr_data_a : std_logic_vector(U_XOR_WIDTH-1 downto 0);
            signal reduce_dout : std_logic_vector(m_read_bits-1 downto 0);
            signal reduce_din : std_logic_vector(U_XOR_WIDTH-1 downto 0);
            signal data_chunk : std_logic_vector((parallel_factor*nibble)-1 downto 0);
            signal data_temp  : std_logic_vector(NUM_GROUPS*parallel_factor*nibble-1 downto 0);
            constant hi : integer := (o+1)*param_o*nibble-1;
            constant lo : integer := o*param_o*nibble;
        begin
            mreg_reverse_inst1 : entity work.reverse_reg
            generic map(
                nibble => nibble,
                nibble_count => param_m
            )
            port map(
                din => pv_arr(o),
                dout => mk_rev
            );

            mreg_reverse_inst2 : entity work.reverse_reg
            generic map(
                nibble => nibble,
                nibble_count => param_m
            )
            port map(
                din => pv_rd_sel,
                dout => mk_rev2
            );

            reduce_din <= l_arr(o) & l_rd_data(m_read_bits-1 downto U_XOR_M_LOW_BITS);

            mod_fx_inst: entity work.reduce_mod_fx(Ctrl)
            generic map(param_m=>param_m,param_k=>param_k,nibble=>nibble)
            port map(
                clk => clk,
                reset => reset,
                a => reduce_din,
                result => reduce_dout,
                start => a_reduce_calc,
                done => rdc_done(o)
            ); 

            gen_pad0 : if REM_BITS = 0 generate
                data_temp <= l_rd_data;
            end generate;
            gen_pad : if REM_BITS /= 0 generate
                data_temp <= (l_rd_data & std_logic_vector(to_unsigned(0, REM_BITS)));
            end generate;

            data_chunk <= data_temp(((NUM_GROUPS-cfl_grp_i)*parallel_factor*nibble)-1 downto ((NUM_GROUPS-cfl_grp_i-1)*parallel_factor*nibble));

            gen_cfl : for idx in 0 to parallel_factor-1 generate
                inst_sipo : entity work.SIPO_FIFO
                generic map(
                    LEFT_SHIFT   => false,
                    INPUT_WIDTH  => nibble,
                    OUTPUT_WIDTH => param_o*nibble
                )
                port map(
                    clk          => clk,
                    reset        => reset,
                    serial_in    => data_chunk((parallel_factor-idx)*nibble-1 downto (parallel_factor-idx-1)*nibble),
                    parallel_in  => (others => '0'),
                    load         => cfl_load,
                    load_parallel=> '0',
                    parallel_out => sipo_out(idx)(hi downto lo),
                    serial_out   => open
                );
            end generate;

            v_sel_j_esk <= v_store(o)((param_n-col_idx2_i)*nibble-1 downto (param_n-col_idx2_i-1)*nibble);

            process(rd_idx, mk_rev, mk_rev2)
                constant mk_nibbles : integer := param_k - 1 - o;
                variable shift_bits : natural;
                variable shifted_m : std_logic_vector(U_XOR_WIDTH-1 downto 0);
            begin
                m_arr(o)   <= (others => '0');
                aligned_mi <= (others => '0');
                for j in 0 to param_k-1 loop
                    if rd_idx = j then
                        shift_bits := (TRI_LUT(j) + mk_nibbles) * nibble;
                        if j <= o then
                            shifted_m := (others => '0');
                            shifted_m(U_XOR_WIDTH-shift_bits-1 downto U_XOR_M_MAX_SHIFT_BITS-shift_bits) := mk_rev;
                            m_arr(o) <= shifted_m;
                        end if;
                        if j < o then
                            shifted_m := (others => '0');
                            shifted_m(U_XOR_WIDTH-shift_bits-1 downto U_XOR_M_MAX_SHIFT_BITS-shift_bits) := mk_rev2;
                            aligned_mi <= shifted_m;
                        end if;
                    end if;
                end loop;
            end process;

            wr_data_a <= aligned_mj when o = rd_idx else aligned_mi;
            wr_data_a_hi <= wr_data_a(U_XOR_WIDTH-1 downto U_XOR_M_MAX_SHIFT_BITS);
            wr_data_a_lo <= wr_data_a(U_XOR_M_MAX_SHIFT_BITS-1 downto 0) & std_logic_vector(to_unsigned(0, U_XOR_M_LOW_BITS));

            wr_data_a_half <= reduce_dout when a_reduce = '1' else wr_data_a_lo when duo='1' else wr_data_a_hi;

        end generate;

        partial_j <= o_sel_j when signing = '1' else v_sel_j_esk;
  
        mul_array_inst_j : entity work.mul_gf16_array
        generic map(
            m => param_m,
            nibble => nibble
        )
        port map(
            input_data => partial_inp_shared,
            a => partial_j,
            result => po_mul
        );

        l_partial_proc : process(clk)
        begin
            if rising_edge(clk) then
                if lv_load = '1' then
                    l_partial_arr(o) <= (others => '0');
                elsif lv_wr = '1' then
                    l_partial_arr(o) <= l_partial_arr(o) xor po_mul;
                end if;
            end if;
        end process;
        
        wr_data_po <= l_partial_arr(o) when po_mode = '1' else pto_mul;
        wr_data_temp <= wr_data_a_half when a_decode = '1' else wr_data_po;

        delayed_reg: process(clk)
        begin
            if rising_edge(clk) then
                wr_data_temp_d <= wr_data_temp;
                l_arr(o) <= l_rd_data;
            end if;     
        end process;

        l_wr_data <= (others=>'0') when mem_init_d = '1' else wr_data_a_half when a_reduce = '1' else (wr_data_temp_d xor l_rd_data) when signing='1' else wr_data_temp_d;

        memory_wr <= mem_init_d or l_wr_d or a_wr_d;

        sdp_ram_inst_l : entity work.sdp_ram
            generic map(
                DATA_WIDTH => param_m*nibble,
                RAM_DEPTH => param_d,
                ADDR_WIDTH => clog2(param_n)
            )
            port map(
                clk_i => clk,
                ena_i => '1',
                enb_i => '1',
                wea_i => memory_wr,
                addra_i => wr_addr,
                addrb_i => l_mem_rd_addr,
                da_i => l_wr_data,
                db_o => l_rd_data
            );

    end generate;


    gen_pv : for k in 0 to param_k-1 generate
        signal v_sel, v_sel_pv, v_sel_l, v_sel_esk : std_logic_vector(nibble-1 downto 0);
        signal partial_mul, mul_input_data : std_logic_vector(param_m*nibble-1 downto 0);
        signal wr_data, rd_data, wr_data_lv : std_logic_vector(param_m*nibble-1 downto 0);
    begin 
        v_sel_pv <= v_store(k)((param_n-col_idx_i)*nibble-1 downto (param_n-col_idx_i-1)*nibble);
        v_sel_l <= v_store(k)((param_n-row_idx_i)*nibble-1 downto (param_n-row_idx_i-1)*nibble);
        v_sel_esk <= v_sel_l when m_mode = '1' else v_sel_pv;
        v_sel <= v_sel_esk when calc = '1' else v_sel_i;

        mul_input_data <= partial_l_shared when calc = '1' else rd_data;

        wr_data_lv <= rd_data xor partial_mul;

        wr_data <= (others=>'0') when m_mem_init = '1' else wr_data_lv when m_mode = '1' else pv_partial_arr(k) when l_mode = '0' else l_arr(k);
        
        mul_array_inst : entity work.mul_gf16_array
            generic map(
                m => param_m,
                nibble => nibble
            )
            port map(
                input_data => mul_input_data,
                a => v_sel,
                result => partial_mul
            );

        pv_partial_proc : process(clk)
        begin
            if rising_edge(clk) then
                if pv_load = '1' then
                    pv_partial_arr(k) <= (others => '0');
                elsif pv_mem_load = '1' then
                    pv_partial_arr(k) <= rd_data;
                elsif pv_wr = '1' then
                    pv_partial_arr(k) <= pv_partial_arr(k) xor partial_mul;
                end if;
            end if;
        end process;

        sdp_ram_inst_pv : entity work.sdp_ram
            generic map(
                DATA_WIDTH => param_m*nibble,
                RAM_DEPTH => param_n,
                ADDR_WIDTH => clog2(param_n)
            )
            port map(
                clk_i => clk,
                ena_i => '1',
                enb_i => '1',
                wea_i => m_mem_init or mem_wr,
                addra_i => pv_mem_wr_addr,
                addrb_i => pv_mem_rd_addr,
                da_i => wr_data,
                db_o => rd_data
            );

        pv_arr(k) <= rd_data;

    end generate;

    v_sel_i <= v_rd_sel((param_n-pv_idx)*nibble-1 downto (param_n-pv_idx-1)*nibble);

    gen_u : for k in 0 to param_k-1 generate
        signal v_sel_j : std_logic_vector(nibble-1 downto 0);
        signal i_partial_mul_out, j_partial_mul_out : std_logic_vector(param_m*nibble-1 downto 0);
        signal u_temp : std_logic_vector(param_m*nibble-1 downto 0);
        signal uk_temp : std_logic_vector(U_XOR_WIDTH-1 downto 0);
        constant uk_idx : integer := param_k-1-k;
    begin
        v_sel_j <= v_store(k)((param_n-pv_idx)*nibble-1 downto (param_n-pv_idx-1)*nibble);

        partial_mul_inst1 : entity work.mul_gf16_array
        generic map(
            m => param_m,
            nibble => nibble
        )
        port map(
            input_data => pv_arr(k),
            a => v_sel_i,
            result => i_partial_mul_out
        );

        partial_mul_inst2 : entity work.mul_gf16_array
        generic map(
            m => param_m,
            nibble => nibble
        )
        port map(
            input_data => pv_rd_sel,
            a => v_sel_j,
            result => j_partial_mul_out
        );

        u_temp <= (others => '0') when rd_idx > k else i_partial_mul_out when rd_idx = k else i_partial_mul_out xor j_partial_mul_out;
        uk_temp <= std_logic_vector(resize(unsigned(u_temp), uk_temp'length));

        u_arr(k) <= std_logic_vector(shift_left(unsigned(uk_temp), uk_idx * nibble));

    end generate;

    u_xor_input_reg_proc : process(clk)
    begin
        if rising_edge(clk) then
            for i in 0 to U_XOR_POW2-1 loop
                if i < param_k then
                    if a_decode = '1' then
                        u_xor_input_reg(i) <= m_arr(i);
                    else
                        u_xor_input_reg(i) <= u_arr(i);
                    end if;
                else
                    u_xor_input_reg(i) <= (others => '0');
                end if;
            end loop;
        end if;
    end process;

    gen_u_xor_init : for i in 0 to U_XOR_POW2-1 generate
    begin
        u_xor_tree(0)(i) <= u_xor_input_reg(i);
    end generate;

    gen_u_xor_tree : if U_XOR_STAGES > 0 generate
        gen_u_xor_stage : for s in 0 to U_XOR_STAGES-1 generate
            constant STAGE_COUNT : integer := U_XOR_POW2 / (2**(s+1));
        begin
            gen_u_xor_nodes : for i in 0 to U_XOR_POW2-1 generate
            begin
                gen_u_xor_pair : if i < STAGE_COUNT generate
                    u_xor_tree(s+1)(i) <= u_xor_tree(s)(2*i) xor u_xor_tree(s)(2*i+1);
                end generate;
                gen_u_xor_zero : if i >= STAGE_COUNT generate
                    u_xor_tree(s+1)(i) <= (others => '0');
                end generate;
            end generate;
        end generate;
    end generate;

    aligned_mj <= u_xor_tree(U_XOR_STAGES)(0);

    v_out <= v_rd_sel(param_n*nibble-1 downto param_o*nibble);
    u_out <= u_xor_tree(U_XOR_STAGES)(0)(u_out'range);
    o_out <= o_store(o_addr_i);

    a_reduce_done <= '1' when rdc_done = (param_k-1 downto 0 => '1') else '0';

    cfl_out  <= sipo_out(to_integer(unsigned(cfl_idx))) when cfl_extra='0' else (others=>'0');

end behavioral;
