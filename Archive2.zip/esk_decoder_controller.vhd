library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity esk_decoder_controller is
    port (
        clk : in std_logic;
        reset : in std_logic;
        calc : in std_logic;
        vcalc : in std_logic;
        verify : in std_logic;
        m_mode : out std_logic;
        l_mode : out std_logic;
        po_mode : out std_logic;
        o_wr_mode : out  std_logic;
        o_load : out  std_logic;
        o_fifo : out  std_logic;
        Li : out std_logic;
        Lj : out std_logic;
        Li2 : out std_logic;
        Lj2 : out std_logic;
        Lino : out std_logic;
        Ljno : out std_logic;
        Lij : out std_logic;
        Lx : out std_logic;
        Lx2 : out std_logic;
        Ly : out std_logic;
        Ls : out std_logic;
        Lp : out std_logic;
        Lc : out std_logic;
        Lk : out std_logic;
        Ei : out std_logic;
        Ej : out std_logic;
        Ei2 : out std_logic;
        Ej2 : out std_logic;
        Ex : out std_logic;
        Ex2 : out std_logic;
        Ey : out std_logic;
        Es : out std_logic;
        Ek : out std_logic;
        Efifo : out std_logic;
        ssk_wr : out std_logic;
        spk_wr : out std_logic;
        spk_ld : out std_logic;
        p3_wr : out std_logic;
        zino : in std_logic;
        zjno : in std_logic;
        zin : in std_logic;
        zjn : in std_logic;
        zio2 : in std_logic;
        zjo2 : in std_logic;
        zy  : in std_logic;
        zjo : in std_logic;
        zs : in std_logic;
        zp : in std_logic;
        zk : in std_logic;
        sha_src_read : in std_logic;
        sha_src_ready : out std_logic;
        sha_dst_write : in std_logic;
        sha_dst_ready : out std_logic;
        aes_ctr_ld : out std_logic;
        aes_ctr_en : out std_logic;
        aes_en : out std_logic;
        aes_reg_wr : out std_logic;
        aes_rst : out std_logic;
        aes_done : in std_logic;
        t_done : in std_logic;
        vr_calc : out std_logic;
        vr_done : in std_logic;
        aes_calc : out std_logic;
        sk_input_ready : out std_logic;
        sk_input_valid : in std_logic;
        pv_load : out std_logic;
        lv_load : out std_logic;
        pv_mem_load : out std_logic;
        pv_wr : out std_logic;
        lv_wr : out std_logic;
        mem_wr : out std_logic;
        l_wr : out std_logic;
        k_init : out std_logic;
        done : out std_logic;
        seed_done : out std_logic
    );
end esk_decoder_controller;

architecture behavioral of esk_decoder_controller is
    type state_type is (
        Idle, 
        P1_start, P1_fetch, P1_wait, P1_write, P1_running, P1T_write, P1_flush,
        AES_init, AES_load,
        M_start, M_running, M_fetch, M_wait, M_write, 
        P2_start, P2_running, P2_load, P2_fetch, P2_write,
        P3_start, P3_fetch, P3_wait, P3_write, 
        seed_start, seed_fetch, seed_pk_fetch, seed_ok,
        vr_write,
        O_fetch, O_write, O_shake_cmd, O_shake_msg, O_pk_write,
        Ok
        );
    signal current_state, next_state : state_type := Idle;

    type p3f_state_t is (P3F_IDLE, P3F_RUNNING, P3F_FETCH, P3F_WAIT, P3F_WR, P3F_DONE);
    signal p3f_state, p3f_next : p3f_state_t := P3F_IDLE;
    signal p3_fill_start : std_logic;

    signal k_set, k_reset, k_init_reg : std_logic := '0';
    signal sk_input_ready1, sk_input_ready2 : std_logic;
    signal lv_load1, lv_load2 : std_logic;
    signal lv_wr1, lv_wr2 : std_logic;
    signal l_wr1, l_wr2 : std_logic;
    signal po_mode1, po_mode2 : std_logic;
    signal Li2_1, Li2_2 : std_logic;
    signal Ei2_1, Ei2_2 : std_logic;

begin

    process(clk, reset)
    begin
        if reset = '1' then
            current_state <= Idle;
        elsif rising_edge(clk) then
            current_state <= next_state;
        end if;
    end process;

    process(clk, reset)
    begin
        if reset = '1' then
            k_init_reg <= '0';
        elsif rising_edge(clk) then
            if k_reset = '1' then
                k_init_reg <= '0';
            elsif k_set = '1' then
                k_init_reg <= '1';
            end if;
        end if;
    end process;

    process(current_state, calc, vcalc, zino, zjno, zin, zjn, zy, zjo, zs, sha_dst_write, sha_src_read, zp, vr_done, t_done, aes_done, verify, sk_input_valid)
    begin

        o_wr_mode <= '0';
        o_load <= '0';
        o_fifo <= '0';
        m_mode <= '0';
        l_mode <= '0';
        po_mode1 <= '0';
        Li <= '0'; 
        Lj <= '0'; 
        Lino <= '0'; 
        Ljno <= '0'; 
        Lij <= '0';
        Lx <= '0'; 
        Ly <= '0'; 
        Ls <= '0'; 
        Lp <= '0'; 
        Lc <= '0';
        Ei <= '0'; 
        Ej <= '0'; 
        Ex <= '0';
        Ey <= '0';
        Es <= '0';
        Li2_2 <= '0'; 
        Ei2_2 <= '0';
        ssk_wr <= '0';
        spk_wr <= '0';
        spk_ld <= '0';
        vr_calc <= '0';
        aes_calc <= '0';
        sk_input_ready1 <= '0';
        sha_src_ready <= '1';
        sha_dst_ready <= '1';
        aes_ctr_ld <= '0';
        aes_ctr_en <= '0';
        aes_reg_wr <= '0';
        aes_rst <= '0';
        aes_en <= '0';
        pv_load <= '0';
        lv_load1 <= '0';
        pv_mem_load <= '0';
        pv_wr <= '0';
        lv_wr1 <= '0';
        mem_wr <= '0';
        l_wr1 <= '0';
        p3_fill_start <= '0';

        seed_done <= '0';
        done <= '0';
        next_state <= current_state;

        case current_state is
            when Idle =>
                Lx <= '1';
                aes_ctr_ld <= '1';
                aes_rst <= '1';
                Li <= '1';
                Lj <= '1';
                Ly <= '1';
                pv_load <= '1';
                lv_load1 <= '1';
                if calc = '1' then
                    spk_ld <= '1';
                    next_state <= seed_start;
                elsif vcalc = '1' then
                    next_state <= vr_write;
                end if;

            when seed_start =>
                Li <= '1';
                if verify = '1' then
                    Lp <= '1';
                    next_state <= seed_pk_fetch;
                else
                    Ls <= '1';
                    next_state <= seed_fetch;
                end if;
            when seed_fetch =>
                sk_input_ready1 <= '1';
                if sk_input_valid = '1' then
                    ssk_wr <= '1';
                    if zs = '0' then
                        Es <= '1';
                    else
                        Li <= '1';
                        Lj <= '1';
                        seed_done <= '1';
                        next_state <= seed_ok;
                    end if;
                end if;
            when seed_pk_fetch =>
                sk_input_ready1 <= '1';
                if sk_input_valid = '1' then
                    spk_wr <= '1';
                    if zp = '0' then
                        Es <= '1';
                    else
                        seed_done <= '1';
                        next_state <= AES_load;
                    end if;
                end if;
            when seed_ok =>
                if t_done = '1' then
                    next_state <= O_shake_cmd;
                end if;
            
            when O_shake_cmd =>
                Lc <= '1';
                Ls <= '1';
                sha_src_ready <= '0';
                next_state <= O_shake_msg;
            when O_shake_msg =>
                sha_src_ready <= '0';
                if sha_src_read = '1' then
                    if zs = '0' then
                        Es <= '1';
                    else
                        Lp <= '1';
                        next_state <= O_pk_write;
                    end if;
                end if;
            when O_pk_write =>
                sha_dst_ready <= '0';
                if sha_dst_write = '1' then
                    spk_wr <= '1';
                    if zp = '0' then
                        Es <= '1';
                    else
                        Lp <= '1';
                        next_state <= O_fetch;
                    end if;
                end if;
            when O_fetch =>
                sha_dst_ready <= '0';
                if sha_dst_write = '1' then
                    o_load <= '1';
                    Ly <= '1';
                    next_state <= O_write;
                end if;
            when O_write =>
                o_fifo <= '1';
                o_wr_mode <= '1';
                if zjo = '0' then
                    Ej <= '1';
                    Ey <= '1';
                    if zy = '0' then
                        next_state <= O_write;
                    else
                        next_state <= O_fetch;
                    end if;
                elsif zino = '0' then
                    Ei <= '1';
                    Ey <= '1';
                    if zy = '0' then
                        Lj <= '1';
                        next_state <= O_write;
                    else
                        Lj <= '1';
                        next_state <= O_fetch;
                    end if;
                else
                    next_state <= vr_write;
                end if;

            when vr_write =>
                vr_calc <= '1';
                if vr_done = '1' then
                    next_state <= AES_load;
                end if;

            when AES_load =>
                aes_calc <= '1';
                aes_en <= '1';
                if verify = '1' then
                    p3_fill_start <= '1';
                end if;
                next_state <= AES_init;
            when AES_init =>
                aes_ctr_en <= '1';
                aes_calc <= '1';
                aes_en <= '1';
                if aes_done = '1' then
                    next_state <= P1_start;
                end if;

            when P1_start =>
                Li <= '1';
                next_state <= P1_running;
            when P1_running =>
                Lij <= '1';
                pv_load <= '1';
                if verify = '0' then
                    lv_load1 <= '1';
                end if;
                next_state <= P1_fetch;
            when P1_fetch =>
                aes_calc <= '1';
                aes_ctr_en <= '1';
                aes_en <= '1';
                aes_reg_wr <= '1';
                Ex <= '1';
                next_state <= P1_write;
            when P1_write =>
                pv_wr <= '1';
                if verify = '0' then
                    lv_wr1 <= '1';
                    l_wr1 <= '1';
                end if;
                if zjno = '0' then
                    Ej <= '1';
                    aes_calc <= '1';
                    aes_ctr_en <= '1';
                    aes_en <= '1';
                    aes_reg_wr <= '1';
                    Ex <= '1';
                    next_state <= P1_write;
                else
                    if verify = '1' then
                        next_state <= P1T_write;
                    else
                        next_state <= P1_flush;
                    end if;
                end if;
            when P1_flush =>
                -- next_state <= P1_wait;
            -- when P1_wait =>
            --     po_mode1 <= '1';
                next_state <= P1T_write;
            when P1T_write =>
                mem_wr <= '1';
                if verify = '0' then
                    po_mode1 <= '1';
                    l_wr1 <= '1';
                end if;
            --     next_state <= P1_wait;
            -- when P1_wait =>
                if zino = '0' then
                    Ei <= '1';
                    next_state <= P1_running;
                else
                    if verify = '1' then
                        next_state <= P2_start;
                    else
                        next_state <= M_start;
                    end if;
                end if;

            when M_start =>
                Li <= '1';
                Lj <= '1';
                next_state <= M_fetch;
            when M_fetch =>
                m_mode <= '1';
                aes_calc <= '1';
                aes_ctr_en <= '1';
                aes_en <= '1';
                aes_reg_wr <= '1';
                next_state <= M_wait;
            when M_wait =>
                m_mode <= '1';
                next_state <= M_write;
            when M_write =>
                mem_wr <= '1';
                Ex <= '1';
                m_mode <= '1';
                if zjo = '0' then
                    Ej <= '1';
                    next_state <= M_fetch;
                elsif zino = '0' then
                    Ei <= '1';
                    Lj <= '1';
                    next_state <= M_fetch;
                else
                    next_state <= Ok;
                end if;

            when P2_start =>
                Li <= '1';
                Ljno <= '1';
                next_state <= P2_running;
            when P2_running =>
                Ljno <= '1';
                next_state <= P2_load;
            when P2_load =>
                pv_mem_load <= '1';
                aes_calc <= '1';
                aes_ctr_en <= '1';
                aes_en <= '1';
                aes_reg_wr <= '1';
                Ex <= '1';
                next_state <= P2_fetch;
            when P2_fetch =>
                pv_wr <= '1';
                if zjn = '0' then
                    Ej <= '1';
                    aes_calc <= '1';
                    aes_ctr_en <= '1';
                    aes_en <= '1';
                    aes_reg_wr <= '1';
                    Ex <= '1';
                else
                    next_state <= P2_write;
                end if;
            when P2_write =>
                mem_wr <= '1';
                if zino = '0' then
                    Ei <= '1';
                    Ljno <= '1';
                    next_state <= P2_running;
                else
                    next_state <= P3_start;
                end if;
            
            when P3_start =>
                Lino <= '1';
                Li2_2 <= '1'; 
                next_state <= P3_fetch;
            when P3_fetch =>
                po_mode1 <= '1';
                next_state <= P3_wait;
            when P3_wait =>
                po_mode1 <= '1';
                next_state <= P3_write;
            when P3_write =>
                mem_wr <= '1';
                l_mode <= '1';
                po_mode1 <= '1';
                if zin = '0' then
                    Ei <= '1';
                    Ei2_2 <= '1';
                    next_state <= P3_fetch;
                else
                    next_state <= OK;
                end if;

            when Ok =>
                done <= '1';
                if calc = '1' or vcalc = '1' then
                    next_state <= Ok;
                else
                    next_state <= Idle;
                end if;
            when others =>
                next_state <= Idle;
        end case;
    end process;

    process(clk, reset)
    begin
        if reset = '1' then
            p3f_state <= P3F_IDLE;
        elsif rising_edge(clk) then
            p3f_state <= p3f_next;
        end if;
    end process;

    process(p3f_state, p3_fill_start, k_init_reg, zio2, zjo2, zk, sk_input_valid)
    begin
        p3f_next    <= p3f_state;

        Li2_1 <= '0'; 
        Ei2_1 <= '0';
        Lj2 <= '0'; 
        Ej2 <= '0';
        Lx2 <= '0'; 
        Ex2 <= '0';

        k_init <= '0';
        k_set <= '0';
        k_reset <= '0';

        Ek <= '0';
        Efifo <= '0';
        Lk <= '0'; 
        p3_wr <= '0';
        sk_input_ready2 <= '0';

        lv_wr2   <= '0';
        lv_load2   <= '0';
        l_wr2   <= '0';
        po_mode2   <= '0';

        case p3f_state is
            when P3F_IDLE =>
                if p3_fill_start = '1' then
                    Li2_1 <= '1'; 
                    Lx2 <= '1';
                    Lk <= '1';
                    k_reset <= '1';
                    p3f_next <= P3F_RUNNING;
                end if;
            
            when P3F_RUNNING =>
                Lj2 <= '1'; 
                lv_load2 <= '1';
                p3f_next <= P3F_FETCH;

            when P3F_FETCH =>
                if k_init_reg = '0' then
                    k_init <= '1';
                end if;
                if zk = '0' then
                    sk_input_ready2 <= '1';
                    if sk_input_valid = '1' then
                        Efifo <= '1';
                        Ek <= '1';
                    end if;
                else
                    Lk <= '1';
                    p3_wr <= '1';
                    k_set <= '1';
                    p3f_next <= P3F_WAIT;
                end if;

            when P3F_WAIT =>
                lv_wr2 <= '1';
                Ex2 <= '1';
                if zjo2 = '0' then
                    Ej2 <= '1';
                    p3f_next <= P3F_FETCH;
                else
                    p3f_next <= P3F_WR;
                end if;

            when P3F_WR =>
                po_mode2 <= '1';
                l_wr2 <= '1';
                if zio2 = '0' then
                    Ei2_1 <= '1';
                    p3f_next <= P3F_RUNNING;
                else
                    p3f_next <= P3F_DONE;
                end if;

            when P3F_DONE =>
                p3f_next <= P3F_IDLE;

            when others =>
                p3f_next <= P3F_IDLE;
        end case;
    end process;

    sk_input_ready <= sk_input_ready1 or sk_input_ready2;
    l_wr <= l_wr1 or l_wr2;
    lv_wr <= lv_wr1 or lv_wr2;
    lv_load <= lv_load1 or lv_load2;
    po_mode <= po_mode1 or po_mode2;
    Li2 <= Li2_1 or Li2_2;
    Ei2 <= Ei2_1 or Ei2_2;

end behavioral;
