library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

use work.util_pkg.all;
use work.mayo_pkg.all;

entity sample_solution is
  generic (
    nibble : positive := 4;
    w      : positive := 8;
    param_k : positive := 9;
    param_o : positive := 8;
    param_m : positive := 64;
    addr_width : positive := 7;
    INPUT_WIDTH : positive := param_k * param_o + 1
  );
  port (
    clk  : in  std_logic;
    reset  : in  std_logic;
    calc : in  std_logic;
    done : out std_logic;
    valid : out std_logic;

    addr_out : out std_logic_vector(addr_width-1 downto 0);
    data_in  : in  std_logic_vector(nibble-1 downto 0);
    pivot_col_list : in std_logic_vector(INPUT_WIDTH-2 downto 0);
    r : in std_logic_vector((INPUT_WIDTH-1)*nibble-1 downto 0);
    x : out std_logic_vector((INPUT_WIDTH-1)*nibble-1 downto 0)
  );
end sample_solution;

architecture behavioral of sample_solution is

    signal i  : unsigned(clog2(INPUT_WIDTH)-1 downto 0);
    signal j  : unsigned(addr_width-1 downto 0);
    signal Ei : std_logic;
    signal Li : std_logic;
    signal Ej : std_logic;
    signal Lj : std_logic;
    signal zi : std_logic;
    signal done_s : std_logic;

    signal sipo_load : std_logic;
    signal sipo_out  : std_logic_vector((INPUT_WIDTH-1)*nibble-1 downto 0);
    signal sipo_in : std_logic_vector(nibble-1 downto 0);
    signal pivot : std_logic;
    signal pivot_d : std_logic;
    signal pivot_cap_en : std_logic;


    type state_type is (IDLE, S1, S2, S3, OK);
    signal state, next_state : state_type := IDLE;

begin
    pivot <= pivot_col_list(to_integer(i));

    -- Use delayed pivot bit so BRAM data aligns with the selected column.
    sipo_in <= data_in when pivot_d = '1' else (others => '0');

    inst_sipo : entity work.SIPO_FIFO
        generic map(
            LEFT_SHIFT   => true,
            INPUT_WIDTH  => nibble,
            OUTPUT_WIDTH => (INPUT_WIDTH-1)*nibble
        )
        port map(
            clk          => clk,
            reset        => reset,
            serial_in    => sipo_in,
            parallel_in  => (others => '0'),
            load         => sipo_load,
            load_parallel=> '0',
            parallel_out => sipo_out,
            serial_out   => open
        );

    -- Counter i
    process(clk)
    begin
        if rising_edge(clk) then
            if Li = '1' then
                i <= (others => '0');
            elsif Ei = '1' then
                i <= i + 1;
            end if;
        end if;
    end process;

    -- Counter j
    process(clk)
    begin
        if rising_edge(clk) then
            if Lj = '1' then
                j <= (others => '0');
            elsif Ej = '1' then
                j <= j + 1;
            end if;
        end if;
    end process;

    -- Pipeline pivot decision by 1 cycle to match BRAM read latency.
    process(clk)
    begin
        if rising_edge(clk) then
            if reset = '1' then
                pivot_d <= '0';
            elsif pivot_cap_en = '1' then
                pivot_d <= pivot;
            end if;
        end if;
    end process;

    fsm_proc : process(clk, reset)
    begin
        if reset = '1' then
            state <= IDLE;
        elsif rising_edge(clk) then
            state <= next_state;
        end if;
    end process;

    control_proc : process(state, zi, calc, pivot)
    begin
        Li <= '0';
        Ei <= '0';
        Lj <= '0';
        Ej <= '0';
        sipo_load <= '0';
        pivot_cap_en <= '0';
        done_s <= '0';
        next_state <= state;
        case state is
            when IDLE =>
                if calc = '1' then
                    Li <= '1';
                    Lj <= '1';
                    next_state <= S1;
                end if;

            when S1 =>
                pivot_cap_en <= '1';
                if pivot = '1' then
                    Ej <= '1';
                end if;
                if zi = '0' then
                    Ei <= '1';
                    next_state <= S2;
                else
                    next_state <= S3;
                end if;

            when S2 =>
                sipo_load <= '1';
                pivot_cap_en <= '1';
                if pivot = '1' then
                    Ej <= '1';
                end if;
                if zi = '0' then
                    Ei <= '1';
                else
                    next_state <= S3;
                end if;

            when S3 =>
                sipo_load <= '1';
                next_state <= OK;

            when OK =>
                done_s <= '1';
                if calc = '0' then
                    next_state <= IDLE;
                end if;

            when others =>
                next_state <= IDLE;
        end case;
    end process;

    zi <= '1' when i = to_unsigned(INPUT_WIDTH-2, i'length) else '0';

    addr_out <= std_logic_vector(resize(j, addr_width));

    valid <= '1' when (done_s = '1') and (count_ones(pivot_col_list) = param_m) else '0';

    x <= sipo_out xor r;

    done <= done_s;

end behavioral;
