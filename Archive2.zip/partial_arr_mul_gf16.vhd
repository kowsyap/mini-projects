library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

use work.util_pkg.all;

entity partial_arr_mul_gf16 is
    generic (
        n : positive := 86
    );
    Port (
        a : in  STD_LOGIC_VECTOR (n*4-1 downto 0);
        s : in  STD_LOGIC_VECTOR (n*4-1 downto 0);
        result : out  STD_LOGIC_VECTOR (3 downto 0)
    );
end partial_arr_mul_gf16;

architecture parallel of partial_arr_mul_gf16 is

    type arr_type is array (0 to n-1) of std_logic_vector(3 downto 0);
    signal intermediate_results: arr_type;

    constant XOR_STAGES : integer := clog2(n);
    constant XOR_POW2   : integer := 2**XOR_STAGES;
    type xor_level_t is array (0 to XOR_POW2-1) of std_logic_vector(3 downto 0);
    type xor_tree_t  is array (0 to XOR_STAGES) of xor_level_t;
    signal xor_tree : xor_tree_t;

begin

    gen_mul: for i in 0 to n-1 generate
        mul_inst: entity work.mul_gf16
            port map (
                a      => a(4*i+3 downto 4*i),
                b      => s(4*i+3 downto 4*i),
                result => intermediate_results(i)
            );
    end generate;

    -- Level 0: load multiplier outputs, pad remaining slots with zero
    gen_xor_init: for i in 0 to XOR_POW2-1 generate
        gen_load: if i < n generate
            xor_tree(0)(i) <= intermediate_results(i);
        end generate;
        gen_zero: if i >= n generate
            xor_tree(0)(i) <= (others => '0');
        end generate;
    end generate;

    -- Levels 1..XOR_STAGES: pairwise XOR reduction
    gen_xor_stages: for s in 0 to XOR_STAGES-1 generate
        constant nodes : integer := XOR_POW2 / (2**(s+1));
    begin
        gen_xor_nodes: for i in 0 to XOR_POW2-1 generate
            gen_pair: if i < nodes generate
                xor_tree(s+1)(i) <= xor_tree(s)(2*i) xor xor_tree(s)(2*i+1);
            end generate;
            gen_unused: if i >= nodes generate
                xor_tree(s+1)(i) <= (others => '0');
            end generate;
        end generate;
    end generate;

    result <= xor_tree(XOR_STAGES)(0);

end parallel;
