library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.all;

use work.util_pkg.all;

entity t_decoder is
  Generic(
    w : positive := 8;
    nibble : positive := 4;
    param_m : positive := 64;
    digest_bytes : positive := 32;
    salt_bytes : positive := 24;
    sha_bits : positive := w*w;
    digest_addr_width : positive := 5
  );
  Port( 
    clk : in std_logic;
    reset : in std_logic;
    calc  : in std_logic;
    verify : in std_logic;
    t_run  : out std_logic;
    vector_input_ready : out std_logic;
    vector_input_valid : in std_logic;
    msg : in  std_logic_vector(16*nibble-1 downto 0);

    salt_read_data : in std_logic_vector( sha_bits-1 downto 0 );
    salt_read_addr : out std_logic_vector( digest_addr_width-1 downto 0 );
    salt_wr : out std_logic;
    salt_wr_addr : out std_logic_vector( digest_addr_width-1 downto 0 );
    salt_wr_data : out std_logic_vector( sha_bits-1 downto 0 );

    sha_src_ready : out std_logic;
    sha_src_read : in std_logic;
    sha_dst_ready : out std_logic;
    sha_dst_write : in std_logic;
    sha_din : out std_logic_vector( sha_bits-1 downto 0 );
    sha_dout : in std_logic_vector( sha_bits-1 downto 0 );

    target : out std_logic_vector( param_m*nibble-1 downto 0);
    salt : out std_logic_vector( salt_bytes*w-1 downto 0);
    msg_bytes : in std_logic_vector(2*w-1 downto 0);
    done : out std_logic
  );
end t_decoder;

architecture Behavioral of t_decoder is

constant salt_words: integer := salt_bytes/w;
constant digest_words: integer := digest_bytes/w;
--constant msg_word_width: integer := w - clog2(w);
constant final_out_size: integer := ceil_div(param_m,16)*sha_bits;
constant mode_val : unsigned(3 downto 0) := to_unsigned(14, 4);
constant count_width : positive := 2*w;

signal command_word : std_logic_vector(sha_bits-1 downto 0);

signal final_out: std_logic_vector(final_out_size-1 downto 0);
signal concat_data, t_reg: std_logic_vector(param_m*nibble-1 downto 0);
signal fifo_in: std_logic_vector(sha_bits-1 downto 0);
signal msg_words: unsigned(count_width-1 downto 0);
signal salt_reg : std_logic_vector(salt_bytes*w-1 downto 0);

type state_type is (IDLE, START, LOADCMD, LOADMSG, LOADDIGEST, WORDREAD, WAITER, OK);
signal state, next_state : state_type;

signal i: unsigned(count_width - 1 downto 0);
signal Lc, Ls, Lm, Ei, zm, zd, salt_we, t_set, t_reset, t_run_reg, t_we : std_logic;
signal pass_number : std_logic_vector(1 downto 0) := "00";
signal pass_number_temp : std_logic_vector(1 downto 0) := "00";
signal output_bits : unsigned(27 downto 0);
signal input_bits  : unsigned(31 downto 0);
signal inp_count : unsigned(count_width-1 downto 0);

begin
    msg_words <= to_unsigned(ceil_div(to_integer(unsigned(msg_bytes)), w), msg_words'length);

    output_bits <= to_unsigned(digest_bytes*w, 28) when pass_number="00" else to_unsigned((salt_bytes)*w, 28) when pass_number="01" else to_unsigned((param_m)*nibble, 28);
    input_bits  <= resize(unsigned(msg_bytes)*w, 32) when pass_number="00" else  to_unsigned((digest_bytes+salt_bytes+salt_bytes)*w, 32) when pass_number="01" else to_unsigned((digest_bytes+salt_bytes)* w, 32);
    command_word <= std_logic_vector(mode_val & output_bits & input_bits);

    salt_read_addr <= std_logic_vector(resize(i, digest_addr_width));
    salt_wr_addr <= std_logic_vector(resize(i, digest_addr_width));
    salt_wr_data <= sha_dout;
    salt_wr <= sha_dst_write when (pass_number="00" or pass_number="01") else '0';

    fifo_in <= sha_dout when sha_dst_write='1' else (others => '0'); 

    inp_count <= to_unsigned(digest_words+salt_words+salt_words-1, inp_count'length) when pass_number="01" else to_unsigned(digest_words+salt_words-1, inp_count'length);  
    zm <= '1' when i = (msg_words - 1) else '0';
    zd <= '1' when i = inp_count else '0';

    sha_din <= command_word when Lc = '1' else msg when pass_number = "00" else salt_read_data;
    
    target <= t_reg;

    t_run <= t_run_reg;

    salt <= salt_reg;

    fifo_out_inst: entity work.SIPO_FIFO
        generic map(INPUT_WIDTH=>sha_bits,OUTPUT_WIDTH=>final_out_size)
        port map(
            clk => clk,
            reset => reset,
            serial_in => fifo_in,
            parallel_in => (others=>'0'),
            serial_out => open,
            load => sha_dst_write,
            parallel_out => final_out
        );
    
    salt_reg_proc: process(clk, reset)
    begin
        if reset = '1' then
            salt_reg <= (others=>'0');
            t_reg <= (others=>'0');
        elsif rising_edge(clk) then
            if salt_we = '1' then
                salt_reg <= final_out(salt_bytes*w-1 downto 0);
            end if;
            if t_we = '1' then
                t_reg <= concat_data;
            end if;
        end if;
    end process;

    i_counter_proc : process(clk, reset)
    begin
        if reset = '1' then
            i <= (others=>'0');
        elsif rising_edge(clk) then
            if Lm = '1' then
                i <= (others=>'0');
            elsif Ls = '1' then
                i <= to_unsigned(digest_words,i'length);
            elsif Ei = '1' then
                i <= i + 1;
            end if;
        end if;
    end process;

    fsm_proc : process(clk, reset)
    begin
        if reset = '1' then
            state <= IDLE;
            pass_number <= "00";
            t_run_reg <= '0';
        elsif rising_edge(clk) then
            if pass_number_temp = "01" then
                pass_number <= "01";
            elsif pass_number_temp = "10" then
                pass_number <= "10";
            end if;
            if t_reset = '1' then
                t_run_reg <= '0';
                pass_number <= "00";
            elsif t_set = '1' then
                t_run_reg <= '1';
            end if;
            state <= next_state;
        end if;
    end process;

    fsm_next : process(state, calc, sha_src_read, zm, zd, sha_dst_write, pass_number, verify, vector_input_valid)
    begin
        Ls <= '0';
        Lm <= '0';
        Ei <= '0';
        Lc <= '0';
        sha_src_ready <= '1';
        sha_dst_ready <= '1';
        pass_number_temp <= "00";
        vector_input_ready <= '0';
        salt_we <= '0';
        t_set <= '0';
        t_reset <= '0';
        t_we <= '0';
        done <= '0';
        next_state <= state;
        case state is
            when IDLE =>
                t_reset <= '1';
                if calc = '1' then
                    next_state <= START;
                end if;

            when START =>
                Lm <= '1';
                t_set <= '1';
                next_state <= LOADCMD;

            when LOADCMD =>
                Lc <= '1';
                sha_src_ready <= '0';
                if(pass_number = "00") then
                    next_state <= LOADMSG;
                else
                    next_state <= LOADDIGEST;
                end if;

            when LOADMSG =>
                sha_src_ready <= '0';
                if sha_src_read = '1' then
                    vector_input_ready <= '1';
                    if vector_input_valid = '1' then
                        if zm = '0' then
                            Ei <= '1';
                        else
                            Lm <= '1';
                            next_state <= WAITER;
                        end if;
                    end if;
                end if;

            when LOADDIGEST =>
                sha_src_ready <= '0';
                if sha_src_read = '1' then
                    if zd = '0' then
                        Ei <= '1';
                    else
                        Ls <= '1';
                        next_state <= WAITER;
                    end if;
                end if;
            
            when WAITER =>
                sha_dst_ready <= '0';
                if sha_dst_write = '1' then
                    Ei <= '1';
                    next_state <= WORDREAD;
                end if;

            when WORDREAD =>
                sha_dst_ready <= '0';
                if sha_dst_write = '0' then
                    if(pass_number="00" and verify='1') then
                        pass_number_temp<="10";
                        next_state<=START;
                    elsif(pass_number="00") then
                        pass_number_temp<="01";
                        next_state<=START;
                    elsif(pass_number="01") then
                        salt_we <= '1';
                        pass_number_temp<="10";
                        next_state<=START;
                    else
                        t_we <= '1';
                        next_state <= OK;
                    end if;
                else
                    Ei <= '1';
                    next_state <= WORDREAD;
                end if;

            when OK =>
                done <= '1';
                if( calc='0') then
                    t_reset <= '1';
                    next_state <= IDLE;
                end if;
        end case;
    end process;

    decode_vec_inst: entity work.decode_vector
        generic map(
            nibble_count => param_m,
            nibble       => nibble,
            reverse      => false
        )
        port map(
            a      => final_out(final_out_size-1 downto final_out_size - param_m*nibble),
            result => concat_data
        );

end Behavioral;
