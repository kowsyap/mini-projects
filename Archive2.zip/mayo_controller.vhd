library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity mayo_controller is
    port (
        clk : in std_logic;
        reset : in std_logic;
        calc : in std_logic;
        mode : in std_logic;
        sig_ready : in std_logic;
        seq_input : in std_logic := '0';

        -- datapath status
        t_done : in std_logic;
        cfl_done : in std_logic;
        store_done : in std_logic;
        init_done : in std_logic;
        qa_done : in std_logic;
        rref_done : in std_logic;
        solution_done : in std_logic;
        sig_done : in std_logic;
        sig_dec_done : in std_logic;
        solution_valid : in std_logic;
        
        zc : in std_logic;
        zi : in std_logic;
        zr : in std_logic;

        -- datapath controls
        esk_calc : out std_logic;
        esk_vcalc : out std_logic;
        m_init_calc : out std_logic;
        a_init_calc : out std_logic;
        qa_calc : out std_logic;
        cfl_calc : out std_logic;
        solution_calc : out std_logic;
        sig_calc : out std_logic;
        t_calc : out std_logic;
        sig_dec_calc : out std_logic;
        rref_calc : out std_logic;
        rref_reset : out std_logic;

        Lc : out std_logic;
        Li : out std_logic;
        Lr : out std_logic;
        Ec : out std_logic;
        Ei : out std_logic;
        Er : out std_logic;
        wr_perm : out std_logic;
        rd_en : out std_logic;
        reg_load : out std_logic;

        verify : out std_logic;
        signing : out std_logic;

        -- top-level status
        sig_valid : out std_logic;
        sig_last : out std_logic;
        done : out std_logic
    );
end mayo_controller;

architecture behavioral of mayo_controller is

    -- State flow (sign path):  IDLE -> WR -> AI -> QA -> CFL -> RREF -> SOL -> GEN -> OP -> OK
    -- State flow (verify path): IDLE -> SD -> [TD ->] WR -> QA -> OK
    -- State flow (sign retry):  SOL -> VWR -> AI -> QA -> ...
    --
    -- IDLE : wait for calc='1'; capture mode, start M init; sign->WR, verify->SD
    -- SD   : decode incoming signature (sig_dec_calc); on done start T, seq->TD else ->WR
    -- TD   : wait for T decode to complete (t_calc/t_done) before proceeding to WR
    -- WR   : expand secret key, load PV/M, hash message (esk_calc/store_done); sign->AI, verify->QA
    -- VWR  : reload PV/M on sign retry (esk_vcalc/store_done) -> AI
    -- AI   : zero-initialise A matrix (a_init_calc/init_done) -> QA
    -- QA   : quadratic accumulation: compute y and A using v, P, M (qa_calc/qa_done); verify->OK, sign->CFL
    -- CFL  : convert A columns to row format for RREF input (cfl_calc/cfl_done) -> RREF
    -- RREF : row-reduce [A | y-A*r] (rref_calc/rref_done) -> SOL
    -- SOL  : extract solution x from RREF (solution_calc/solution_done); valid->GEN, invalid->VWR retry
    -- GEN  : assemble signature from x, O, v (sig_calc/sig_done) -> OP
    -- OP   : stream signature words out one per sig_ready handshake (sig_valid/sig_last); last word->OK
    -- OK   : hold done='1' until calc deasserts -> IDLE
    signal perm_calc : std_logic;
    type state_type is (IDLE, SD, TD, WR, VWR, AI, QA, CFL, RREF, SOL, GEN, OP, OK);
    signal state, next_state : state_type := IDLE;
    type perm_state_type is (T0, T1);
    signal perm_state, perm_state_next : perm_state_type := T0;

    signal mode_reg : std_logic;
    signal mode_wr : std_logic;
begin

    signing <= not mode_reg;
    verify  <= mode_reg;

    reg: process(clk, reset)
    begin
        if reset = '1' then
            state <= IDLE;
        elsif rising_edge(clk) then
            state <= next_state;
            if mode_wr = '1' then
                mode_reg <= mode;
            end if;
        end if;
    end process;

    logic: process(state, calc, store_done, init_done, qa_done, cfl_done, rref_done, solution_done, sig_dec_done, solution_valid, zc, zi, sig_done, sig_ready, mode_reg, mode, seq_input, t_done)
    begin
        mode_wr <= '0';
        esk_calc <= '0';
        esk_vcalc <= '0';
        m_init_calc <= '0';
        a_init_calc <= '0';
        qa_calc <= '0';
        cfl_calc <= '0';
        solution_calc <= '0';
        sig_calc <= '0';
        t_calc <= '0';
        sig_dec_calc <= '0';
        rref_calc <= '0';
        rref_reset <= '0';
        reg_load <= '0';
        sig_valid <= '0';
        sig_last <= '0';
        done <= '0';
        Lc <= '0';
        Ec <= '0';
        Li <= '0';
        Ei <= '0';
        perm_calc <= '0';
        rd_en <= '0';
        next_state <= state;
        case state is
            when IDLE =>
                Lc <= '1';
                Li <= '1';
                if calc = '1' then
                    mode_wr <= '1';
                    m_init_calc <= '1';
                    reg_load <= '1';
                    if mode = '1' then
                        next_state <= SD;
                    else
                        esk_calc <= '1';
                        perm_calc <= '1';
                        next_state <= WR;
                    end if;
                end if;

            when SD =>
                sig_dec_calc <= '1';
                if sig_dec_done = '1' then
                    t_calc <= '1';
                    if seq_input = '1' then
                        next_state <= TD;
                    else
                        next_state <= WR;
                    end if;
                end if;

            when TD =>
                t_calc <= '1';
                if t_done = '1' then
                    next_state <= WR;
                end if;

            when WR =>
                esk_calc <= '1';
                if store_done = '1' then
                    if mode_reg = '1' then
                        next_state <= QA;
                    else
                        next_state <= AI;
                    end if;
                end if;

            when VWR =>
                esk_vcalc <= '1';
                if store_done = '1' then
                    next_state <= AI;
                end if;

            when AI =>
                a_init_calc <= '1';
                if init_done = '1' then
                    next_state <= QA;
                end if;

            when QA =>
                qa_calc <= '1';
                if qa_done = '1' then
                    if mode_reg = '1' then
                        next_state <= OK;
                    else
                        next_state <= CFL;
                        rref_reset <= '1';
                    end if;
                end if;

            when CFL =>
                cfl_calc <= '1';
                if cfl_done = '1' then
                    next_state <= RREF;
                end if;

            when RREF =>
                rref_calc <= '1';
                if rref_done = '1' then
                    next_state <= SOL;
                end if;

            when SOL =>
                solution_calc <= '1';
                rd_en <= '1';
                if solution_done = '1' then
                    if solution_valid = '1' or zc = '1' then
                        next_state <= GEN;
                    else
                        Ec <= '1';
                        m_init_calc <= '1';
                        next_state <= VWR;
                    end if;
                end if;

            when GEN =>
                sig_calc <= '1';
                if sig_done = '1' then
                    next_state <= OP;
                end if;

            when OP =>
                done <= '1';
                sig_valid <= '1';
                sig_last <= zi;
                if sig_ready = '1' then
                    if zi = '0' then
                        Ei <= '1';
                    else
                        next_state <= OK;
                    end if;
                end if;
                if calc = '0' then
                    next_state <= IDLE;
                end if;
            
            when OK =>
                done <= '1';
                if calc = '0' then
                    next_state <= IDLE;
                end if;

            when others =>
                next_state <= IDLE;

        end case;
    end process;

    perm_reg: process(clk, reset)
    begin
        if reset = '1' then
            perm_state <= T0;
        elsif rising_edge(clk) then
            perm_state <= perm_state_next;
        end if;
    end process;

    perm: process(perm_state, perm_calc, zr)
    begin
        Lr <= '0';
        Er <= '0';
        wr_perm <= '0';
        perm_state_next <= perm_state;
        case perm_state is
            when T0 =>
                Lr <= '1';
                if perm_calc = '1' then
                    wr_perm <= '1';
                    perm_state_next <= T1;
                end if;
            when T1 =>
                if zr = '0' then
                    wr_perm <= '1';
                    Er <= '1';
                else
                    wr_perm <= '1';
                    perm_state_next <= T0;
                end if;

            when others =>
                perm_state_next <= T0;
        end case;
    end process;

end behavioral;
